            function autocomplet() {
                var min_length = 0; // min caracters to display the autocomplete
                var keyword = $('#feild_search').val();
                if (keyword.length >= min_length) {
                    $.ajax({
                        url: 'search_attach.php',
                        type: 'POST',
                        data: {q:keyword},
                        success:function(data){
                            $('#view_search').show();
                            $('#view_search').html(data);
                        }
                    });
                } else {
                    $('#view_search').hide();
                }
            }

            // set_item : this function will be executed when we select an item
            function set_item(item) {
                // change input value
                $('#feild_search').val(item);
                // hide proposition list
                $('#view_search').hide();
            }
			
			
			 function autoplaque() {
                var min_length = 0; // min caracters to display the autocomplete
                var keyword = $('#plaque_search').val();
                if (keyword.length >= min_length) {
                    $.ajax({
                        url: 'search_attach.php',
                        type: 'POST',
                        data: {pla:keyword},
                        success:function(data){
                            $('#view_plaque').show();
                            $('#view_plaque').html(data);
                        }
                    });
                } else {
                    $('#view_plaque').hide();
                }
            }

            // set_item : this function will be executed when we select an item
            function set_item(item) {
                // change input value
                $('#plaque_search').val(item);
                // hide proposition list
                $('#view_plaque').hide();
            }
			
			
    
       
   