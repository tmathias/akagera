<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <body>

<style>
#snackbar {
    visibility: hidden;
    min-width: 250px;
    margin-left: -125px;
    background-color: #333;
    color: #fff;
    text-align: center;
    border-radius: 2px;
    padding: 16px;
    position: fixed;
    z-index: 1;
    left: 50%;
    bottom: 30px;
    font-size: 17px;
}

#snackbar.show {
    visibility: visible;
    -webkit-animation: fadein 0.5s, fadeout 0.5s 2.5s;
    animation: fadein 0.5s, fadeout 0.5s 2.5s;
}

@-webkit-keyframes fadein {
    from {bottom: 0; opacity: 0;} 
    to {bottom: 30px; opacity: 1;}
}

@keyframes fadein {
    from {bottom: 0; opacity: 0;}
    to {bottom: 30px; opacity: 1;}
}

@-webkit-keyframes fadeout {
    from {bottom: 30px; opacity: 1;} 
    to {bottom: 0; opacity: 0;}
}

@keyframes fadeout {
    from {bottom: 30px; opacity: 1;}
    to {bottom: 0; opacity: 0;}
}
</style>
<?php

Class fetch extends CI_Model {

// Insert registration data in database
public function registration_insert($data) {
// Query to insert data in database
$this->db->insert('login_test', $data);
if ($this->db->affected_rows() > 0) {
return true;
}

}



public function model_insert($data) {

$dat=$data['file_name'];$medical=$data['medical'];$recurency=$data['recurency'];$proficiency=$data['proficiency'];$crm=$data['crm'];$dgs=$data['dgs'];$instructor=$data['instructor'];$license=$data['license'];$sim109=$data['sim109'];$sim139=$data['sim139'];

$firstname=$data['firstname'];$lastname=$data['lastname'];$license_number=$data['license_number'];$password=$data['password'];$department=$data['department'];

$data = array(
'tel'=>$data['tel'],'instructor'=>$data['instructor_hour'],'instrument'=>$data['instrument'],'night'=>$data['night'],'R44'=>$data['R44'],'R44_solo'=>$data['R44_solo'],'A109'=>$data['A109'],'A109_solo'=>$data['A109_solo'],'SIM_109'=>$data['SIM_109'],'A139'=>$data['A139'],'A139_solo'=>$data['A139_solo'],'SIM_139'=>$data['SIM_139'],'others'=>$data['others'],'others_solo'=>$data['others_solo'],'others_sim'=>$data['others_sim'],'others_turbine'=>$data['others_turbine'],'others_multiengine'=>$data['others_multiengine']);


$data2 = array(
'tel'=>$data['tel'],'medical'=>$medical,'recurency'=>$recurency,'proficiency'=>$proficiency,'crm'=>$crm,'dgs'=>$dgs,'instructor'=>$instructor,'license'=>$license,'sim109'=>$sim109,'sim139'=>$sim139);

$license_number="";

$data3 = array(
'picture'=>$dat,'tel'=>$data['tel'],'firstname'=>$firstname,'lastname'=>$lastname,'license_number'=>$license_number,'password'=>$password,'department'=>$department);

if(!empty($data['R44']))$this->db->insert('initial', $data);
if(!empty($medical))$this->db->insert('expirations', $data2);
$this->db->insert('workers', $data3);
			
if ($this->db->affected_rows() > 0) {?>
<div id="snackbar" >Well saved;<u>Use your Phone Number as Username</u></div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}
}

// Read data using username and password
public function fetch_login($data) {
	
$sql = "SELECT * FROM workers WHERE tel = ? AND password = ? ";
$query=$this->db->query($sql, array($data['user'],$data['pass']));


if ($query->num_rows() == 1) {

return $query ->result();
} else {
return false;
}
}

// Read data
public function fetch_f() {
	
$sql = "SELECT * from (SELECT * FROM inspection ORDER by _id desc limit 100) as h group by call_sign";
$query=$this->db->query($sql);
return $query ->result();

// $bindings = array($this->user_id, '%'.$item_name.'%');

/*$records = $this->db->query($sql, $bindings)->result();

return array(
    'records' => $records,
    'count' => count($records),
);
Then, in your controller:

$query = $this->item_model->searchItem($item_name);

$data['records'] = $query['records'];
$data['count'] = $query['count']; $return array('categories' => $query1, 'count' => $query2);
*/
}
public function fetch_($data) {
	
$da=$data['section'];
$para=$data['para'];
	
$sql = "SELECT * FROM status_tb where crew_type='$para' order by $da asc ";
$query=$this->db->query($sql);

return $query ->result();

}

public function fetch_all($data) {
	
$da=$data['section'];
	
$sql = "SELECT * FROM status_tb order by $da asc ";
$query=$this->db->query($sql);

return $query ->result();

}

public function fetch_section($data) {
	
$da=$data['section'];
	
$sql = "SELECT * FROM status_tb where crew_type='$da' order by ranking,service_n asc ";
$query=$this->db->query($sql);

return $query ->result();

}

public function fetch_edit($tel) {
	
$sql = "select * from initial, expirations, workers where initial.tel= ? and workers.tel= ? and expirations.tel= ?";
$query=$this->db->query($sql, array($tel,$tel,$tel));

return $query ->result();
print_r($query);

}
public function fetch_update($data) {

require(APPPATH.'include/link_database.php');


$dat=$data['file_name'];$medical=$data['medical'];$recurency=$data['recurency'];$proficiency=$data['proficiency'];$crm=$data['crm'];$dgs=$data['dgs'];$instructor=$data['instructor'];$license=$data['license'];$sim109=$data['sim109'];$sim139=$data['sim139'];

$firstname=$data['firstname'];$lastname=$data['lastname'];$license_number=$data['license_number'];$password=$data['password'];$department=$data['department'];

$data = array(
'tel'=>$data['tel'],'instructor'=>$data['instructor_hour'],'instrument'=>$data['instrument'],'night'=>$data['night'],'R44'=>$data['R44'],'R44_solo'=>$data['R44_solo'],'A109'=>$data['A109'],'A109_solo'=>$data['A109_solo'],'SIM_109'=>$data['SIM_109'],'A139'=>$data['A139'],'A139_solo'=>$data['A139_solo'],'SIM_139'=>$data['SIM_139'],'others'=>$data['others'],'others_solo'=>$data['others_solo'],'others_sim'=>$data['others_sim'],'others_turbine'=>$data['others_turbine'],'others_multiengine'=>$data['others_multiengine']);



$data2 = array(
'tel'=>$data['tel'],'medical'=>$medical,'recurency'=>$recurency,'proficiency'=>$proficiency,'crm'=>$crm,'dgs'=>$dgs,'instructor'=>$instructor,'license'=>$license,'sim109'=>$sim109,'sim139'=>$sim139);


$data3 = array(
'picture'=>$dat,'tel'=>$data['tel'],'firstname'=>$firstname,'lastname'=>$lastname,'license_number'=>$license_number,'password'=>$password,'department'=>$department);


$tel=$data['tel'];

$where="tel=$tel";

$query = $this->db->update_string('initial',$data,$where );mysqli_query($conn,$query);
$query2 = $this->db->update_string('expirations',$data2,$where );mysqli_query($conn,$query2);
$query3 = $this->db->update_string('workers',$data3,$where );mysqli_query($conn,$query3);
if($query){?>
	<div id="snackbar" >Updated Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script>
<?PHP return true;
}
else{
	
	echo "no";
}
}


// Read data from database to show data in admin page
public function read_user_information($username) {

$condition = "user_name =" . "'" . $username . "'";
$this->db->select('*');
$this->db->from('user_login');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();

if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}
public function fetch_hours($data)
{  
	$call_sign=$data['call_sign'];
	$from=$data['from'];
	$to=$data['to'];
	$tel=$data['pilot'];
	
if(($call_sign=="--Select a/c--")&&(empty($tel))){

$sql="select * from flights where date_time between '$from' and '$to' order by date_time desc ";
}
else if(($call_sign=="--Select a/c--")&&(!empty($tel))){
echo "yes";
$sql="select * from flights where date_time between '$from' and '$to' and(pic_instr='$tel' or copilot_instr='$tel')order by date_time desc ";
}
else if(($call_sign!="--Select a/c--")&&(!empty($tel))){
$sql="select * from flights where date_time between '$from' and '$to' and(pic_instr='$tel' or copilot_instr='$tel') and call_sign='$call_sign' order by date_time desc ";}

else if(($call_sign!="--Select a/c--")&&(empty($tel))){
$sql="select * from flights where date_time between '$from' and '$to' and call_sign='$call_sign' order by date_time desc ";}
$query=$this->db->query($sql);

return $query ->result();
     
}
public function fetch_term($data)
{
	$year=date("y");
	$year1="20".$year;
	if($data['term']=="term1")
	{$date1=$year1."-01-01";$date2=$year1."-03-31";}
	if($data['term']=="term2")
	{$date1=$year1."-04-01";$date2=$year1."-06-30";}
	if($data['term']=="term3")
	{$date1=$year1."-07-01";$date2=$year1."-09-30";}
	if($data['term']=="term4")
	{$date1=$year1."-10-01";$date2=$year1."-12-31";}
	if($data['term']=="annual")
	{$date1=$year1."-01-01";$date2=$year1."-12-31";}
	
/*$sql="SELECT rank,firstname,lastname,ranking,status_tb.service_n,aircraft_type,amount,flight_date,hours.service_n FROM hours
JOIN status_tb
ON hours.service_n=status_tb.service_n where flight_date between '$date1' and '$date2' 
GROUP BY hours.service_n order by ranking,status_tb.service_n asc ";*/

$sql="SELECT pilot co_pilot FROM hours UNION SELECT co_pilot FROM hours where flight_date between '$date1' and '$date2'";

$query=$this->db->query($sql);

return $query ->result();

}
public function fetch_inserth($data)
{
require(APPPATH.'include/link_database.php');

$tel=$_SESSION['user'];
$landing_hours=$data['landing_hours'];
$call_sign=$data['call_sign'];
$amount=$data['amount'];

/*$queryy=mysqli_query($conn,"select engine_hobs from flights where call_sign='$call_sign' order by _id desc limit 1 ");
if (mysqli_num_rows($queryy)==0) {
$queryw=mysqli_query($conn,"select engine_time from aircraft where call_sign='$call_sign' order by aircraft_id desc limit 1 ");
while ($roww = mysqli_fetch_array($queryw)){$sumw=$roww[0];
}}
else{
while ($roww = mysqli_fetch_array($queryy)){$sumw=$roww[0];}
}
$neww=$amount+$sumw;
$newx=$landing_hours-$sumx;*/

if(empty($data['problem'])){$st="no";}
else {$st="yes";}
$data = array(
'pic_instr'=>$data['pilot'],'copilot_instr'=>$data['co_pilot'],'start_time'=>$data['start_time'],'stop_time'=>$data['stop_time'],'call_sign'=>$data['call_sign'],'auth_flighttime'=>$data['auth_flighttime'],'flight_date'=>$data['flight_date'],'flight_exercise'=>$data['flight_nature'],'fuel_main'=>$data['fuel_main'],'fuel_aux'=>$data['fuel_aux'],'landing_hours'=>$data['landing_hours'],'weight'=>$data['weight'],'engine_hobs'=>$amount,'logged'=>$tel,'flight_from'=>$data['from'],'flight_to'=>$data['to'],'problem'=>$data['problem'],'status'=>$st);

$queryx=mysqli_query($conn,"select * from aircraft where call_sign='$call_sign' ");
while ($row2 = mysqli_fetch_array($queryx)){
$engine_hobs=$row2['engine_time']; }

$engine_hobs2=$engine_hobs+$amount;
$data2=array('aircraft_time'=>$data['landing_hours'],'engine_time'=>$engine_hobs2);
$call_sign=$data['call_sign'];
$where="call_sign='$call_sign'";

$today=date("y-m-d");	
echo $today1="20".$today; echo "end"; echo $data['flight_date'];

if($data['flight_date']==$today1){
$query = $this->db->update_string('aircraft',$data2,$where );
mysqli_query($conn,$query);
}
$queryx=mysqli_query($conn,"select landing_hours from flights where call_sign='$call_sign' and landing_hours='$landing_hours'");
if (mysqli_num_rows($queryx) ==0) {
$this->db->insert('flights', $data);
}
else {echo '<script type="text/javascript">alert("Check out your landing hours it seems to be duplicate into database,or this flight is already logged by another pilot");</script>';
}
 			
if ($this->db->affected_rows() > 0) {?>
<div id="snackbar" >inserted Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}
	
}
public function fetch_pilot($data)
{
$today=date("y-m-d");	
$tel=$_SESSION['user'];	
$sql="select * from flights where logged='$tel' and DATE( SUBSTRING(date_time
FROM 1 
FOR 10 ) )='$today' order by date_time desc ";

$query=$this->db->query($sql);
return $query ->result();

}
public function fetch_pilot2()
{
$today=date("y-m-d");	
$tel=$_SESSION['user'];	
$sql="select * from flights order by date_time desc ";

$query=$this->db->query($sql);
return $query ->result();

}

public function fetch_edithours($_id) {
	
$sql = "SELECT * FROM flights WHERE _id = ?";
$query=$this->db->query($sql,$_id);

return $query ->result();


}
public function fetch_updatehours($data) {

require(APPPATH.'include/link_database.php');



$tel=$_SESSION['user'];
$landing_hours=$data['landing_hours'];
$amount=$data['amount'];
$call_sign=$data['call_sign'];
$_id=$data['_id'];


$data2 = array(
'pic_instr'=>$data['pilot'],'copilot_instr'=>$data['co_pilot'],'start_time'=>$data['start_time'],'stop_time'=>$data['stop_time'],'call_sign'=>$data['call_sign'],'auth_flighttime'=>$data['auth_flighttime'],'flight_date'=>$data['flight_date'],'flight_exercise'=>$data['flight_exercise'],'fuel_main'=>$data['fuel_main'],'fuel_aux'=>$data['fuel_aux'],'landing_hours'=>$data['landing_hours'],'weight'=>$data['weight'],'logged'=>$tel,'flight_from'=>$data['flight_from'],'flight_to'=>$data['flight_to'],'engine_hobs'=>$amount,'problem'=>$data['problem']);

$where="_id=$_id";


$query = $this->db->update_string('flights',$data2,$where );

mysqli_query($conn,$query);

if($query){?>
	<div id="snackbar" >Updated Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script>
<?PHP return true;
}
else{
	
	echo "no";
}



}

public function fetch_hours2($data)
{
	$tel=$data['user'];
	$call_sign=$data['call_sign'];
	$from=$data['from'];
	$to=$data['to'];
	
if($call_sign=="--Select a/c--"){

$sql="select * from flights where (pic_instr='$tel' or copilot_instr='$tel') and date_time between '$from' and '$to' order by date_time desc ";
}
else{
$sql="select * from flights where (pic_instr='$tel' or copilot_instr='$tel') and call_sign='$call_sign' and date_time between '$from' and '$to' order by date_time desc ";
	}
$query=$this->db->query($sql);

return $query ->result();
     
}
public function load_hours(){
$today=date("y-m-d");
$sql="select hours._id,rank,firstname,lastname,flight_date,aircraft_type,amount,initial_r44,initial_mi17,initial_mi24,initial_sim17,initial_sim24,status_tb.MI_17,status_tb.MI_24,status_tb.SIM_17,status_tb.SIM_24,start_time,stop_time,call_sign,pilot,co_pilot,flight_nature from hours join status_tb on hours.service_n=status_tb.service_n where flight_date='$today' order by flight_date desc";

$query=$this->db->query($sql);

return $query ->result();

}
public function fetch_tec()
{
$today=date("y-m-d");	
$tel=$_SESSION['user'];	
$sql="select * from morning_check where done_by='$tel' and DATE( SUBSTRING(date_time
FROM 1 
FOR 10 ) )='$today' order by date_time desc ";

$query=$this->db->query($sql);
return $query ->result();

}
public function fetch_tec2()
{
$sql="select * from morning_check  order by date_time desc ";

$query=$this->db->query($sql);
return $query ->result();

}
public function fetch_technician($data)
{
$tel=$_SESSION['user'];	
$from=$data["from"];
$to=$data["to"];
$aircraft=$data['aircraft'];

if($aircraft=="--Select a/c--"){$sql="select * from morning_check where done_by='$tel' and check_date between '$from' and '$to' order by date_time desc ";
} else{
$sql="select * from morning_check where done_by='$tel' and call_sign='$aircraft' and check_date between '$from' and '$to' order by date_time desc ";}

$query=$this->db->query($sql);
return $query ->result();

}

public function fetch_technician2($data)
{
$tel=$_SESSION['user'];	
$from=$data["from"];
$to=$data["to"];
$aircraft=$data['aircraft'];

if($aircraft=="--Select a/c--"){$sql="select * from morning_check where  check_date between '$from' and '$to' order by date_time desc ";
} else{
$sql="select * from morning_check where call_sign='$aircraft' and check_date between '$from' and '$to' order by date_time desc ";}

$query=$this->db->query($sql);
return $query ->result();

}

public function inserthm($data)
{
require(APPPATH.'include/link_database.php');

$tel=$data['tel'];
$check_date=$data['check_date'];
$approved=$data['approved'];
$aircraft=$data['aircraft'];
$remarks=$data['remarks'];

$data = array(
'done_by'=>$data['tel'],'check_date'=>$data['check_date'],'approved'=>$data['approved'],'call_sign'=>$data['aircraft'],'remarks'=>$data['remarks']);

$queryx=mysqli_query($conn,"select * from morning_check where call_sign='$aircraft' and check_date='$check_date'");
if (mysqli_num_rows($queryx) ==0) {
$this->db->insert('morning_check', $data);
}
if ($this->db->affected_rows() > 0) {?>
<div id="snackbar" >inserted Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}

}
public function summary()
{
$service_n=$_SESSION['user'];	
$sql="select * from initial join workers on initial.tel=workers.tel where initial.tel='$service_n'  ";
$query=$this->db->query($sql);

$query1=$this->db->query("select sum(engine_hobs) as sum44 from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$service_n' or copilot_instr='$service_n') and type='R44'");
$query2=$this->db->query("select sum(engine_hobs) as instrument from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$service_n' or copilot_instr='$service_n') and flight_exercise='instrument'  ");
$query3=$this->db->query("select sum(engine_hobs) as solo44 from flights join aircraft on flights.call_sign=aircraft.call_sign where copilot_instr='solo' and pic_instr='$service_n' and type='R44'  ");
$query4=$this->db->query("select sum(engine_hobs) as night from flights join aircraft on flights.call_sign=aircraft.call_sign where start_time >= '17:00:00' and (pic_instr='$service_n' or copilot_instr='$service_n') ");
$query5=$this->db->query("select sum(engine_hobs) as instructor from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$service_n' or copilot_instr='$service_n') and flight_exercise='instructor'  ");

$query1b=$this->db->query("select sum(engine_hobs) as sum109 from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$service_n' or copilot_instr='$service_n') and type='A109'");
$query3b=$this->db->query("select sum(engine_hobs) as solo109 from flights join aircraft on flights.call_sign=aircraft.call_sign where copilot_instr='solo' and pic_instr='$service_n' and type='A109'  ");
$query5b=$this->db->query("select sum(engine_hobs) as sim_109 from flights where call_sign='SIM_109' and (pic_instr='$service_n' or copilot_instr='$service_n')");

$query1c=$this->db->query("select sum(engine_hobs) as sum139 from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$service_n' or copilot_instr='$service_n') and type='A139'");
$query3c=$this->db->query("select sum(engine_hobs) as solo139 from flights join aircraft on flights.call_sign=aircraft.call_sign where copilot_instr='solo' and pic_instr='$service_n' and type='A139'  ");
$query5c=$this->db->query("select sum(engine_hobs) as sim_139 from flights where call_sign='SIM_139' and (pic_instr='$service_n' or copilot_instr='$service_n')");

$data['initial']=$query ->result();
$data['instrument']=$query2 ->result();
$data['night']=$query4 ->result();
$data['instructor']=$query5 ->result();
$data['R44']=$query1 ->result();
$data['solo_44']=$query3 ->result();
$data['A109']=$query1b ->result();
$data['solo_109']=$query3b ->result();
$data['sim_109']=$query5b ->result();
$data['A139']=$query1c ->result();
$data['solo_139']=$query3c ->result();
$data['sim_139']=$query5c ->result();

return $data;

}
public function initial($data) {
	
$sql = "SELECT * FROM initial WHERE tel = ?  ";
$query=$this->db->query($sql, array($data['user']));


return $query ->result();
} 
public function insert_initial($data) {
$tel=$_SESSION['user'];	
$data = array(
'tel'=>$data['tel'],'instructor'=>$data['instructor_hours'],'instrument'=>$data['instrument'],'night'=>$data['night'],'R44'=>$data['R44'],'R44_solo'=>$data['R44_solo'],'A109'=>$data['A109'],'A109_solo'=>$data['A109_solo'],'SIM_109'=>$data['SIM_109'],'A139'=>$data['A139'],'A139_solo'=>$data['A139_solo'],'SIM_139'=>$data['SIM_139'],'others'=>$data['others'],'others_solo'=>$data['others_solo'],'others_sim'=>$data['others_sim'],'others_turbine'=>$data['others_turbine'],'others_multiengine'=>$data['others_multiengine']);


$this->db->insert('initial', $data);
 			
if ($this->db->affected_rows() > 0) {?>
<div id="snackbar" >inserted Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}

}
public function edit_technician($_id) {
	
$sql = "SELECT * FROM morning_check WHERE _id = ?";
$query=$this->db->query($sql,$_id);

return $query ->result();
}
public function edit_inspection($_id) {
	
$sql = "SELECT * FROM inspection WHERE _id = ?";
$query=$this->db->query($sql,$_id);

return $query ->result();
}

public function update_technician($data){

require(APPPATH.'include/link_database.php');

$data2 = array('check_date'=>$data['check_date'],'call_sign'=>$data['call_sign'],'remarks'=>$data['remarks'],'approved'=>$data['approved']); 

$_id=$data['_id'];

$where="_id=$_id";


$query = $this->db->update_string('morning_check',$data2,$where );
mysqli_query($conn,$query);
if($query){?>
	<div id="snackbar" >Updated Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script>
<?PHP return true;
}
else{
	
	echo "no";
}}
public function update_inspection($data){

require(APPPATH.'include/link_database.php');

$data2 = array('date'=>$data['date'],'call_sign'=>$data['call_sign'],'ondate'=>$data['ondate'],'athours'=>$data['athours'],'next_inspection'=>$data['next_inspection']); 

$_id=$data['_id'];

$where="_id=$_id";


$query = $this->db->update_string('inspection',$data2,$where );
mysqli_query($conn,$query);
if($query){?>
	<div id="snackbar" >Updated Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script>
<?PHP return true;
}
else{
	
	echo "no";
}
}
public function insert_insp($data)
{

$tel=$_SESSION['user'];

$data = array(
'superviser'=>$tel,'date'=>$data['maintenance'],'next_inspection'=>$data['next_inspection'],'call_sign'=>$data['call_sign'],'ondate'=>$data['ondate'],'athours'=>$data['athours']);

$data['next_inspection'];

$this->db->insert('inspection', $data);
		

if ($this->db->affected_rows() > 0) {?>
<div id="snackbar" >inserted Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}

}
public function problem() {
	
$sql = "SELECT * FROM flights WHERE status = ?";
$status="yes";
$query=$this->db->query($sql,$status);

return $query ->result();
}
public function fetch_corrected($data){
$today=date("y-m-d");
require(APPPATH.'include/link_database.php');
$rectifier=$_SESSION['tel'];
$data2 = array('status'=>"corrected",'rectifier'=>"$rectifier",'date_time'=>"$today"); 

$_id=$data['_id'];

$where="_id=$_id";


$query = $this->db->update_string('flights',$data2,$where );
mysqli_query($conn,$query);
if($query){?>
	<div id="snackbar" >Rectified</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script>
<?PHP return true;
}
else{
	
	echo "no";
}}
public function expirations(){
$sql="select firstname,lastname,department,license_number,workers.tel,workers._id,medical,crm,dgs,sim109,sim139,recurency,proficiency,instructor,license from expirations join workers on expirations.tel=workers.tel order by firstname";

$query=$this->db->query($sql);

return $query ->result();

}

public function insert_time($data)
{
require(APPPATH.'include/link_database.php');

$aircraft=$data['aircraft'];
$time=$data['time'];

$data2 = array(
'aircraft_time'=>$time);

$where="call_sign='$aircraft'";

$query = $this->db->update_string('aircraft',$data2,$where );mysqli_query($conn,$query);
if (mysqli_query($conn,$query)) {?>
<div id="snackbar" >Updated Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}
}

public function insert_time2($data)
{
require(APPPATH.'include/link_database.php');

$aircraft=$data['aircraft'];
$time=$data['time'];

$data2 = array(
'engine_time'=>$time);

$where="call_sign='$aircraft'";

$query = $this->db->update_string('aircraft',$data2,$where );mysqli_query($conn,$query);
if (mysqli_query($conn,$query)) {?>
<div id="snackbar" >Updated Successfully</div>
<script>
function myFunction() {
    var x = document.getElementById("snackbar")
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}
myFunction()
</script><?PHP 
} else {
    echo "Error: " ;
}
}

public function fetch_rectified() {
	
$sql = "SELECT * FROM flights WHERE status ='corrected' order by date_time desc";
$query=$this->db->query($sql);

return $query ->result();

}

}
?>
</body>
</html>


