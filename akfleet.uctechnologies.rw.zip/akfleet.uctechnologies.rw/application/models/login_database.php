<?php

Class Login_Database extends CI_Model {

// Insert registration data in database
public function registration_insert($data) {
// Query to insert data in database
$this->db->insert('login_test', $data);
if ($this->db->affected_rows() > 0) {
return true;
}

}

// Read data using username and password
public function login($data) {
	
$sql = "SELECT * FROM login_test WHERE username = ? AND password = ? ";
$query=$this->db->query($sql, array($data['username'],$data['password']));


if ($query->num_rows() == 1) {

return $query ->result();
} else {
return false;
}
}

// Read data from database to show data in admin page
public function read_user_information($username) {

$condition = "user_name =" . "'" . $username . "'";
$this->db->select('*');
$this->db->from('user_login');
$this->db->where($condition);
$this->db->limit(1);
$query = $this->db->get();

if ($query->num_rows() == 1) {
return $query->result();
} else {
return false;
}
}

}

?>