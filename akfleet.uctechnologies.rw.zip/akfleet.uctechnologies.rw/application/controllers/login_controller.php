<?

class Login_controller extends CI_Controller{
	
	
public function __construct() {
parent::__construct();

$this->load->helper('security');

// Load form helper library
$this->load->helper('form');

$this->load->helper('url');

// Load form validation library
$this->load->library('form_validation');



// Load database
$this->load->model('login_database');
}

// Show login page
public function index() {
$this->load->view('login_view');
}

// Check for user login process
public function insert() {
	
	// Check validation for user input in SignUp form
$this->form_validation->set_rules('username', 'username', 'required|xss_clean');
$this->form_validation->set_rules('password', 'password', 'required|xss_clean');
if ($this->form_validation->run() == FALSE) {
$this->load->view('login_view');
}

else{

$data['username']= $this->input->post('username');
$data['password']= $this->input->post('password');

$result = $this->login_database->registration_insert($data);

$res=$this->login_database->login($data);


foreach ($res as $row)
{

$usern=$row->username;
$passw=$row->password;	
	
}
$data2=array
(

'userna'=>$usern,
'passwo'=>$passw

);
$this->load->view('success',$data2);
}
}
public function display() {

echo print_r($query_database);
//$this->load->view('success');
}

}



?>