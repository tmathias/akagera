<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	public function __construct() {
parent::__construct();

// Load form validation library
$this->load->library('form_validation');


$this->load->helper('security');

// Load form helper library
$this->load->helper('form');

// Load database
$this->load->model('fetch');

}


	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
$res['res']=$this->fetch->fetch_f();

$this->load->view('welcome_message',$res);

	}
	
	public function edit_f()
	{
	
	$this->load->view('login_view');	
		
	}
	/*
	public function test()
	{
	
	$this->load->view('insert');	
		
	}
	
	
	public function edit()
	{
		
	// Check validation for user input in SignUp form
/*$this->form_validation->set_rules('names', 'names', 'required|xss_clean');
$this->form_validation->set_rules('_id', '_id', 'required|xss_clean');
$this->form_validation->set_rules('sex', 'sex', 'required|xss_clean');
$this->form_validation->set_rules('dob', 'dob', 'required|xss_clean');
$this->form_validation->set_rules('medical_date', 'medical_date', 'required|xss_clean');
$this->form_validation->set_rules('exp_date', 'exp_date', 'required|xss_clean');
if ($this->form_validation->run() == FALSE) {
$this->load->view('edit');
echo "false";
}

else{
echo "true";
$data['names']= $this->input->post('names');
$data['_id']= $this->input->post('_id');
$data['sex']= $this->input->post('sex');
$data['dob']= $this->input->post('dob');
$data['medical_date']= $this->input->post('medical_date');
$data['exp_date']= $this->input->post('exp_date');

$result = $this->fetch->fetch_update($data);

$res['res']=$this->fetch->fetch_f();

$this->load->view('welcome_message',$res);}
	
	
	/*public function edit_f2($_id)
	{
		 
	$res=$this->fetch->fetch_edit($_id);
	

foreach ($res as $row)
{
$_id=$row->_id;
$names=$row->names;
$dob=$row->dob;
$sex=$row->sex;
$medical_date=$row->medical_date;	
$exp_date=$row->exp_date;	

}
$data2=array
(

'_id'=>$_id,'names'=>$names,'dob'=>$dob,'sex'=>$sex,'medical_date'=>$medical_date,'exp_date'=>$exp_date

);
	
$this->load->view('edit',$data2);	
		
}

	public function insert()	
	{
		$data['i']= $this->input->post('i');
		
		echo "data";echo $data['i'];
		
		for ($j=0;$j<=$i;$j++) {			
			
			$names1="test1".$j;
			$names2="test2".$j;
			$names3="test3".$j;
			
			$data[$names1]= $this->input->post($names1);
			$data[$names2]= $this->input->post($names2);
			$data[$names3]= $this->input->post($names3);
			
			
		}
		$res['res']=$this->fetch->fetch_f();
		$this->load->view('welcome_message',$res);
				
	}
	
	*/
}
