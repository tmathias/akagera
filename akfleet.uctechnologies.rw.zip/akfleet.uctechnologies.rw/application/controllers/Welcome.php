<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	
	public function __construct() {
parent::__construct();

$this->load->library('session');
// Load form validation library
$this->load->library('form_validation');


$this->load->helper('security');

// Load form helper library
$this->load->helper('form');


// Load database
$this->load->model('fetch');

$this->load->library('upload');



$this->load->helper(array('form', 'url'));

}


	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 public function home()
	{
$res['res']=$this->fetch->expirations();
$this->load->view('ops',$res);	
	}
public function home_ops()
	{
if(($_SESSION['deploy']=="pilot")||($_SESSION['deploy']=="pilot_ops")){
$data['user1']=$_SESSION['user'];
$res0['res0']=$this->fetch->fetch_pilot($data);
$res0['res1']=$this->fetch->summary();	
$this->load->view('pilot',$res0);}
else if($_SESSION['deploy']=="ops"){
$res0['res0']=$this->fetch->fetch_pilot2();
$this->load->view('pilot2',$res0);}


	}
public function home_inspection()
	{
if($_SESSION['deploy']=="technician"){
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);}
	else if($_SESSION['deploy']=="ops"){
$res0['res0']=$this->fetch->fetch_tec2();
$this->load->view('technician2',$res0);}
	}
	public function home_technician()
	{
if(($_SESSION['deploy']=="technician")||($_SESSION['deploy']=="technician_ops")){
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);}
	else if($_SESSION['deploy']=="ops"){
$res0['res0']=$this->fetch->fetch_tec2();
$this->load->view('technician2',$res0);}
}

	public function index()
	{
	$res['res']=$this->fetch->fetch_f();	
    $this->load->view('login',$res);

	}
	public function login()
	{
$data['user']= $this->input->post('user');
$data['pass']= $this->input->post('pass');
$res2=$this->fetch->fetch_login($data);
$res3['res3']=$this->fetch->fetch_login($data);
if(empty($res2)){
echo '<script type="text/javascript">alert("username or password incorrect");</script>';
$res['res']=$this->fetch->fetch_f();	
$this->load->view('login',$res);

}else{

foreach ($res2 as $row)
{
$_SESSION['tel']=$row->tel;
$_SESSION['deploy']=$deploy=$row->department;
$data['user1']=$_SESSION['user']=$data['user'];

if($deploy=="ops")
{
//$res['res']=$this->fetch->fetch_f();
$res['res']=$this->fetch->expirations();
$this->load->view('ops',$res);}
}
if(($deploy=="pilot")||($deploy=="pilot_ops"))
{	
	$res0['res0']=$this->fetch->fetch_pilot($data);
	$res0['res1']=$this->fetch->summary();
	
		 
	$res0['data']=$this->fetch->fetch_edit($_SESSION['tel']);
	



	$this->load->view('pilot',$res0);
}
if(($deploy=="technician")||($deploy=="technician_ops"))
{
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);
}

}}
	public function insert_f(){$this->load->view('insert');}	public function insert_others(){$this->load->view('insert_others');}

	
	
	
	public function edit_technician($_id)
	{
$res=$this->fetch->edit_technician($_id);
	

foreach ($res as $row)
{
$data['_id']=$row->_id;
$data['check_date']=$row->check_date;
$data['call_sign']=$row->call_sign;	
$data['remarks']=$row->remarks;
$data['approved']=$row->approved;

}
	
$this->load->view('edit_technician',$data);	
		
}
public function update_technician()
	{
$data['_id']= $this->input->post('_id');
$data['check_date']=$this->input->post('check_date');
$data['call_sign']=$this->input->post('call_sign');	
$data['remarks']=$this->input->post('remarks');
$data['approved']=$this->input->post('approved');
$res=$this->fetch->update_technician($data);

	if(($_SESSION['deploy']=="technician")||($_SESSION['deploy']=="technician_ops")){
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);}
	else if($_SESSION['deploy']=="ops"){
$res0['res0']=$this->fetch->fetch_tec2();
$this->load->view('technician2',$res0);}
}


public function edit_f2($tel)
	{
		 
	$res=$this->fetch->fetch_edit($tel);
	

foreach ($res as $row)
{
$firstname=$row->firstname;
$lastname=$row->lastname;	
$department=$row->department;
$tel=$row->tel;	
$medical=$row->medical;
$instructor=$row->instructor;	
$proficiency=$row->proficiency;
$crm=$row->crm;	
$dgs=$row->dgs;	
$sim109=$row->sim109;	
$picture=$row->picture;	
$license_number=$row->license_number;	
$proficiency=$row->proficiency;	
$sim139=$row->sim139;	
$recurency=$row->recurency;	
$license=$row->license;	
$password=$row->password;	

$instructor_hours=$row->instructor;
$night=$row->night;
$instrument=$row->instrument;
$R44=$row->R44;
$R44_solo=$row->R44_solo;
$A109=$row->A109;
$A109_solo=$row->A109_solo;
$SIM_109=$row->SIM_109;
$A139=$row->A139;
$A139_solo=$row->A139_solo;
$SIM_139=$row->SIM_139;
$others=$row->others;
$others_solo=$row->others_solo;
$others_SIM=$row->others_SIM;
$others_turbine=$row->others_turbine;
$others_multiengine=$row->others_multiengine;

}
$data2=array
(

'password'=>$password,'firstname'=>$firstname,'lastname'=>$lastname,'department'=>$department,'tel'=>$tel,'medical'=>$medical,'proficiency'=>$proficiency,'instructor'=>$instructor,'sim109'=>$sim109,'picture'=>$picture,'license_number'=>$license_number,'recurency'=>$recurency,'instructor_hours'=>$instructor_hours,'night'=>$night,'instrument'=>$instrument,'R44'=>$R44,'R44_solo'=>$R44_solo,'A109'=>$A109,'A109_solo'=>$A109_solo,'SIM_109'=>$SIM_109,'A139'=>$A139,'A139_solo'=>$A139_solo,'SIM_139'=>$SIM_139,'others'=>$others,'others_solo'=>$others_solo,'others_SIM'=>$others_SIM,'others_turbine'=>$others_turbine,'others_multiengine'=>$others_multiengine,'license'=>$license,'proficiency'=>$proficiency,'sim139'=>$sim139,'crm'=>$crm,'dgs'=>$dgs

);
	
$this->load->view('edit',$data2);	
		
}

public function ci_profile($tel)
	{
		 
	$res=$this->fetch->fetch_edit($tel);
	

foreach ($res as $row)
{
$_id=$row->_id;
$firstname=$row->firstname;
$lastname=$row->lastname;	
$department=$row->department;
$tel=$row->tel;	
$medical=$row->medical;
$instructor=$row->instructor;	
$proficiency=$row->proficiency;
$crm=$row->crm;	
$dgs=$row->dgs;	
$sim109=$row->sim109;	
$picture=$row->picture;	
$license_number=$row->license_number;
$proficiency=$row->proficiency;	
$sim139=$row->sim139;	
$recurency=$row->recurency;	
$license=$row->license;	

}
$data2=array
(

'_id'=>$_id,'firstname'=>$firstname,'lastname'=>$lastname,'department'=>$department,'tel'=>$tel,'medical'=>$medical,'proficiency'=>$proficiency,'instructor'=>$instructor,'sim109'=>$sim109,'picture'=>$picture,'license_number'=>$license_number,'recurency'=>$recurency,'license'=>$license,'proficiency'=>$proficiency,'sim139'=>$sim139,'crm'=>$crm,'dgs'=>$dgs

);
	
$this->load->view('profile',$data2);	
		
}

	public function insert()	
	{
		$config['upload_path']          ='./uploads/';
                $config['allowed_types']        = 'gif|jpg|jpeg|png|pdf';
                $config['max_size']             = 2000;
                $config['max_width']            = 5000;
                $config['max_height']           = 3000;
				
				$this->upload->initialize($config);


                $this->load->library('upload', $config);
		
		if (empty($_FILES['userfile']['name']))
{
	$data['file_name']="default.png";
	
}
else{

                if ( ! $this->upload->do_upload('userfile'))
				
                {
					    $error=" ";
                        $error = array('error' => $this->upload->display_errors());

                                        }
                else
                {
                        $data2 = array('upload_data' => $this->upload->data());
						$data['file_name']=$this->upload->data('file_name'); 
				}
} 

if(!empty($error)){
print_r($error);
}

else{

$data['sim109']= $this->input->post('sim109');
$data['sim139']= $this->input->post('sim139');
$data['instructor']= $this->input->post('instructor');
$data['recurency']= $this->input->post('recurency');
$data['proficiency']= $this->input->post('proficiency');
$data['crm']= $this->input->post('crm');
$data['dgs']= $this->input->post('dgs');
$data['medical']= $this->input->post('medical');
$data['license']= $this->input->post('license');

$data['firstname']= $this->input->post('firstname');
$data['lastname']= $this->input->post('lastname');
$data['department']= $this->input->post('department');
$data['tel']= $this->input->post('tel');
$data['license_number']= $this->input->post('license_number');
$data['password']= $this->input->post('password');

$data['instructor_hour']= $this->input->post('instructor_hour');
$data['night']= $this->input->post('night');
$data['instrument']= $this->input->post('instrument');
$data['R44']= $this->input->post('R44');
$data['R44_solo']= $this->input->post('R44_solo');
$data['A109']= $this->input->post('A109');
$data['A109_solo']= $this->input->post('A109_solo');
$data['SIM_109']= $this->input->post('SIM_109');
$data['A139']= $this->input->post('A139');
$data['A139_solo']= $this->input->post('A139_solo');
$data['SIM_139']= $this->input->post('SIM_139');
$data['others']= $this->input->post('others');
$data['others_solo']= $this->input->post('others_solo');
$data['others_sim']= $this->input->post('others_sim');
$data['others_turbine']= $this->input->post('others_turbine');
$data['others_multiengine']= $this->input->post('others_multiengine');

if(empty($data['tel'])){$this->logout();}else{$this->fetch->model_insert($data);}
$res['res']=$this->fetch->fetch_f();	
$this->load->view('insert',$res);

}
      
        
	}
	
	public function edit()
	{
		
// Check validation for user input in SignUp form
/*$this->form_validation->set_rules('names', 'names', 'required|xss_clean');
$this->form_validation->set_rules('_id', '_id', 'required|xss_clean');
$this->form_validation->set_rules('sex', 'sex', 'required|xss_clean');
$this->form_validation->set_rules('dob', 'dob', 'required|xss_clean');
$this->form_validation->set_rules('medical_date', 'medical_date', 'required|xss_clean');
$this->form_validation->set_rules('exp_date', 'exp_date', 'required|xss_clean');
if ($this->form_validation->run() == FALSE) {
$this->load->view('edit');
echo "false";
}

else{*/


$data['sim109']= $this->input->post('sim109');
$data['sim139']= $this->input->post('sim139');
$data['instructor']= $this->input->post('instructor');
$data['recurency']= $this->input->post('recurency');
$data['proficiency']= $this->input->post('proficiency');
$data['crm']= $this->input->post('crm');
$data['dgs']= $this->input->post('dgs');
$data['medical']= $this->input->post('medical');
$data['license']= $this->input->post('license');

$data['firstname']= $this->input->post('firstname');
$data['lastname']= $this->input->post('lastname');
$data['department']= $this->input->post('department');
$data['tel']= $this->input->post('tel');
$data['license_number']= $this->input->post('license_number');
$data['password']= $this->input->post('password');

$data['instructor_hour']= $this->input->post('instructor_hour');
$data['night']= $this->input->post('night');
$data['instrument']= $this->input->post('instrument');
$data['R44']= $this->input->post('R44');
$data['R44_solo']= $this->input->post('R44_solo');
$data['A109']= $this->input->post('A109');
$data['A109_solo']= $this->input->post('A109_solo');
$data['SIM_109']= $this->input->post('SIM_109');
$data['A139']= $this->input->post('A139');
$data['A139_solo']= $this->input->post('A139_solo');
$data['SIM_139']= $this->input->post('SIM_139');
$data['others']= $this->input->post('others');
$data['others_solo']= $this->input->post('others_solo');
$data['others_sim']= $this->input->post('others_sim');
$data['others_turbine']= $this->input->post('others_turbine');
$data['others_multiengine']= $this->input->post('others_multiengine');

$config['upload_path']          ='./uploads/';
                $config['allowed_types']        = 'gif|jpg|jpeg|png|pdf';
                
				$this->upload->initialize($config);


                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('userfile'))
				
                {
					    $error=" ";
                        $error = array('error' => $this->upload->display_errors());
						$data['file_name']=""; 

                }
                else
                {
                        $data2 = array('upload_data' => $this->upload->data());
						$data['file_name']=$this->upload->data('file_name'); 
				}
				
				
				 if ( ! $this->upload->do_upload('passport'))
				
                {
					
					    $error=" ";
                        $error = array('error' => $this->upload->display_errors());
						$this->upload->data('file_size'); 

                }
                else
                {
                        $data2 = array('upload_data' => $this->upload->data());
						$data['passport_name']=$this->upload->data('file_name'); 
				}
				 if ( ! $this->upload->do_upload('proficiency'))
				
                {
					    $error=" ";
                        $error = array('error' => $this->upload->display_errors());

                }
                else
                {
                        $data2 = array('upload_data' => $this->upload->data());
						$data['proficiency_name']=$this->upload->data('file_name'); 
				}
				if ( ! $this->upload->do_upload('license'))
				
                {
					    $error=" ";
                        $error = array('error' => $this->upload->display_errors());

                }
                else
                {
                        $data2 = array('upload_data' => $this->upload->data());
						$data['license_name']=$this->upload->data('file_name'); 
				}
$result = $this->fetch->fetch_update($data);
$res['section']=0;	

$res['res']=$this->fetch->fetch_f();

$this->ci_profile($_SESSION['tel']);

}
		public function list_by($section,$para)
	{
		 
$data['section']=$section;
$data['para']=$para;

$res['res']=$this->fetch->fetch_($data);

$this->load->view('welcome_message',$res);
	
	}
		public function list_by_all($section)
	{
		 
$data['section']=$section;

$res['res']=$this->fetch->fetch_all($data);

$this->load->view('welcome_message',$res);
	
	}
	
	public function sort_by($section)
	{
		 
$data['section']=$section;

$res['res']=$this->fetch->fetch_section($data);

$this->load->view('welcome_message',$res);
	
	}
	public function files($file,$_id){
	$res=$this->fetch->fetch_edit($_id);
	

foreach ($res as $row)
{
$_id=$row->_id;
$service_n=$row->service_n;
$rank=$row->rank;
$firstname=$row->firstname;
$lastname=$row->lastname;	
$crew_type=$row->crew_type;
$dob=$row->dob;
$sex=$row->sex;
$marital_status=$row->marital_status;	
$address=$row->address;
$social_security_n=$row->social_security_n;	
$telephone=$row->telephone;	
$exp_date=$row->exp_date;
$crm_exp=$row->crm_exp;	
$dgs_exp=$row->dgs_exp;	
$passport_exp=$row->passport_exp;	
$english_exp=$row->english_exp;	
$extension_time=$row->extension_time;	
$picture=$row->picture;	
$license=$row->license;	
$proficiency=$row->proficiency;	
$passport=$row->passport;	

}
$data2=array
(
'_id'=>$_id,'service_n'=>$service_n,'rank'=>$rank,'firstname'=>$firstname,'lastname'=>$lastname,'crew_type'=>$crew_type,'dob'=>$dob,'sex'=>$sex,'marital_status'=>$marital_status,'address'=>$address,'social_security_n'=>$social_security_n,'telephone'=>$telephone,'exp_date'=>$exp_date,'english_exp'=>$english_exp,'passport_exp'=>$passport_exp,'extension_time'=>$extension_time,'picture'=>$picture,'license'=>$license,'proficiency'=>$proficiency,'passport'=>$passport,'crm_exp'=>$crm_exp,'dgs_exp'=>$dgs_exp

);
	$data2['file']=$file;
	$this->load->view('profile',$data2);	
	}
	
	public function hours()
	{
//$re['re']=$this->fetch->load_hours();
$this->load->view('hours');
	}
	public function hours_f()
	{
$_SESSION['service_n2']=$data['service_n']= $this->input->post('service_n');
$_SESSION['from']=$data['from']= $this->input->post('from');
$_SESSION['to']=$data['to']= $this->input->post('to');
$_SESSION['aircraft_type']=$data['aircraft_type']= $this->input->post('aircraft_type');
$_SESSION['flight_nature']=$data['flight_nature']= $this->input->post('flight_nature');

        $res['res']=$this->fetch->fetch_hours($data);
		$this->load->view('hours',$res);
	}
	public function hours_f2($term)
	{
        $_SESSION['term']=$data['term']= $term;

        $res2['res2']=$this->fetch->fetch_term($data);
		$this->load->view('hours',$res2);
	}
	public function insert_hours()
	{
$data['type']= $this->input->post('type');

if($data['type']=="PIC/INSTR"){
$data['pilot']=$this->input->post('pilot');
$data['co_pilot']=$_SESSION['user'];}
else if($data['type']=="copilot/student"){
$data['pilot']=$_SESSION['user'];
$data['co_pilot']=$this->input->post('pilot');}
else{
$data['pilot']=$_SESSION['user'];
$data['co_pilot']="solo";}

$data['start_time']= $this->input->post('start_time');
$data['stop_time']= $this->input->post('stop_time');
$data['flight_nature']= $this->input->post('flight_nature');
$data['call_sign']= $this->input->post('call_sign');
$data['flight_date']= $this->input->post('flight_date');
$data['from']= $this->input->post('from');
$data['to']= $this->input->post('to');
$data['weight']= $this->input->post('weight');
$data['landing_hours']= $this->input->post('landing_hours');
$data['fuel_main']= $this->input->post('fuel_main');
$data['fuel_aux']= $this->input->post('fuel_aux');
$data['auth_flighttime']= $this->input->post('auth_flighttime');
$data['problem']= $this->input->post('problem');



  $time1=date_create($data['start_time']);
  $time2=date_create($data['stop_time']);

  $diff=date_diff($time1,$time2);
  $diffz=$diff->format("%H:%I");
  
  $hms = explode(":", $diffz);
  $hours=($hms[0] + ($hms[1]/60));

  $data['amount']=$hours;

    $res3['res3']=$this->fetch->fetch_inserth($data);
	$res0['res0']=$this->fetch->fetch_pilot($data);
	$res0['res1']=$this->fetch->summary();
	$this->load->view('pilot',$res0);
	}
	
	public function logout()
	{
        $res['res']=$this->fetch->fetch_f();	
        $this->load->view('login',$res);
	session_unset(); 
	//session_destroy();	
	

	}
	
	public function edit_hours($_id)
	{
		 
	$res=$this->fetch->fetch_edithours($_id);
	

foreach ($res as $row)
{
$data['_id']=$row->_id;
$data['flight_date']=$row->flight_date;
$data['flight_exercise']=$row->flight_exercise;
$data['call_sign']=$row->call_sign;	
$data['pic_instr']=$row->pic_instr;
$data['copilot_instr']=$row->copilot_instr;
$data['start_time']=$row->start_time;
$data['stop_time']=$row->stop_time;	
$data['flight_from']=$row->flight_from;
$data['flight_to']=$row->flight_to;
$data['weight']=$row->weight;
$data['start_time']=$row->start_time;
$data['stop_time']=$row->stop_time;
 $data['landing_hours']=$row->landing_hours;
 $data['fuel_main']=$row->fuel_main;
 $data['fuel_aux']=$row->fuel_aux;
 $data['auth_flighttime']=$row->auth_flighttime;
 $data['problem']=$row->problem;
}
	
$this->load->view('edit_hours',$data);	
		
}
public function update_hours()
	{
$data['_id']= $this->input->post('_id');
$data['flight_date']=$this->input->post('flight_date');
$data['flight_exercise']=$this->input->post('flight_exercise');
$data['call_sign']=$this->input->post('call_sign');	
$data['pic_instr']=$this->input->post('pic_instr');
$data['copilot_instr']=$this->input->post('copilot_instr');
$data['start_time']=$this->input->post('start_time');
$data['stop_time']=$this->input->post('stop_time');	
$data['flight_from']=$this->input->post('flight_from');
$data['flight_to']=$this->input->post('flight_to');
 $data['weight']=$this->input->post('weight');
 $data['start_time']=$this->input->post('start_time');
 $data['stop_time']=$this->input->post('stop_time');
 $data['landing_hours']=$this->input->post('landing_hours');
 $data['fuel_main']=$this->input->post('fuel_main');
 $data['fuel_aux']=$this->input->post('fuel_aux');
 $data['type']=$this->input->post('type');
 $data['auth_flighttime']=$this->input->post('auth_flighttime');
 $data['problem']=$this->input->post('problem');

if($_SESSION['deploy']=="pilot" or $_SESSION['deploy']=="pilot_ops"){ 
if($data['type']=="PIC/INSTR"){
$data['pilot']=$this->input->post('pilot');
$data['co_pilot']=$_SESSION['user'];}
else if($data['type']=="copilot/student"){
$data['pilot']=$_SESSION['user'];
$data['co_pilot']=$this->input->post('pilot');}
else{
$data['pilot']=$_SESSION['user'];
$data['co_pilot']="solo";}}

else if($_SESSION['deploy']=="ops"){ 

$data['pilot']=$this->input->post('pic_instr');
$data['co_pilot']=$this->input->post('copilot_instr');}


 $time1=date_create($data['start_time']);
  $time2=date_create($data['stop_time']);

  $diff=date_diff($time1,$time2);
  $diffz=$diff->format("%H:%I");
  
  $hms = explode(":", $diffz);
  $hours=($hms[0] + ($hms[1]/60));

  $data['amount']=$hours;
 
 $res=$this->fetch->fetch_updatehours($data);
 $res0['res0']=$this->fetch->fetch_pilot($data);
 $res0['res1']=$this->fetch->summary();
	if($_SESSION['deploy']=="pilot" or "pilot_ops"){
	$this->load->view('pilot',$res0);}
	else if($_SESSION['deploy']=="ops"){
$res0['res0']=$this->fetch->fetch_pilot2();
$this->load->view('pilot2',$res0);}
}

public function hours_pilot()
	{
$data['user']=$_SESSION['user'];
$_SESSION['from']=$data['from']= $this->input->post('from');
$_SESSION['to']=$data['to']= $this->input->post('to');
$_SESSION['call_sign']=$data['call_sign']= $this->input->post('call_sign');
$res2['res0']=$this->fetch->fetch_pilot($data);

if($data['call_sign']=="--Select a/c--")
$_SESSION['call_sign']="all";
else
$_SESSION['call_sign']= $this->input->post('call_sign');

$res2['res2']=$this->fetch->fetch_hours2($data);
if(empty($res2)){
echo '<script type="text/javascript">alert("username or password incorrect");</script>';
}
$res2['res1']=$this->fetch->summary();
$this->load->view('pilot',$res2);
	}
	public function hours_pilot2()
	{
$_SESSION['pilot']=$data['pilot']= $this->input->post('pilot');
$_SESSION['from']=$data['from']= $this->input->post('from');
$_SESSION['to']=$data['to']= $this->input->post('to');
$_SESSION['call_sign']=$data['call_sign']= $this->input->post('call_sign');
$res2['res0']=$this->fetch->fetch_pilot($data);

if($data['call_sign']=="--Select a/c--")
$_SESSION['call_sign']="all";
else
$_SESSION['call_sign']= $this->input->post('call_sign');

$res2['res2']=$this->fetch->fetch_hours($data);
if(empty($res2)){
echo '<script type="text/javascript">alert("username or password incorrect");</script>';
}
$this->load->view('pilot2',$res2);
	}
public function insert_morning()
	{	
$data['check_date']= $this->input->post('check_date');
$data['aircraft']= $this->input->post('aircraft');
$data['remarks']= $this->input->post('remarks');
$data['approved']= $this->input->post('approved');
$data['tel']= $this->input->post('tel');

$res3['res3']=$this->fetch->inserthm($data);
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);
	}
	
	public function hours_tec()
	{
$_SESSION['from']=$data['from']= $this->input->post('from');
$_SESSION['to']=$data['to']= $this->input->post('to');
$data['aircraft']= $this->input->post('aircraft');
if($data['aircraft']=="--Select a/c--")
$_SESSION['aircraft']="all";
else
$_SESSION['aircraft']= $this->input->post('aircraft');
$res2['res4']=$this->fetch->problem();
$res2['res2']=$this->fetch->fetch_technician($data);
$res2['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res2);
	}
	
	public function hours_tec2()
	{
$_SESSION['from']=$data['from']= $this->input->post('from');
$_SESSION['to']=$data['to']= $this->input->post('to');
$data['aircraft']= $this->input->post('aircraft');
if($data['aircraft']=="--Select a/c--")
$_SESSION['aircraft']="all";
else
$_SESSION['aircraft']= $this->input->post('aircraft');
$res2['res2']=$this->fetch->fetch_technician2($data);
$this->load->view('technician2',$res2);
	}
	
	public function technicians()
	{
		$res0['res0']=$this->fetch->fetch_tec2();
		$this->load->view('technician2',$res0);

	}
	public function pilots()
	{
$res0['res0']=$this->fetch->fetch_pilot2();
$this->load->view('pilot2',$res0);
	
	}
	public function initial()	
	{

$data['instructor_hour']= $this->input->post('instructor_hour');
$data['night']= $this->input->post('night');
$data['instrument']= $this->input->post('instrument');
$data['R44']= $this->input->post('R44');
$data['R44_solo']= $this->input->post('R44_solo');
$data['A109']= $this->input->post('A109');
$data['A109_solo']= $this->input->post('A109_solo');
$data['SIM_109']= $this->input->post('SIM_109');
$data['A139']= $this->input->post('A139');
$data['A139_solo']= $this->input->post('A139_solo');
$data['SIM_139']= $this->input->post('SIM_139');
$data['others']= $this->input->post('others');
$data['others_solo']= $this->input->post('others_solo');
$data['others_sim']= $this->input->post('others_sim');
$data['others_turbine']= $this->input->post('others_turbine');
$data['others_multiengine']= $this->input->post('others_multiengine');


$this->fetch->insert_initial($data);
$res0['res0']=$this->fetch->fetch_pilot($data);
$res0['res1']=$this->fetch->summary();
	
	$this->load->view('pilot',$res0);
}

public function insert_inspection()
	{	

$data['maintenance']= $this->input->post('maintenance');
$data['call_sign']= $this->input->post('call_sign');
$data['next_inspection']= $this->input->post('next_inspection');
$data['ondate']= $this->input->post('ondate');
$data['athours']= $this->input->post('athours');

$res3['res3']=$this->fetch->insert_insp($data);
$res0['res4']=$this->fetch->problem();
$res0['res1']=$this->fetch->fetch_f();
$res0['res0']=$this->fetch->fetch_tec();

$this->load->view('technician',$res0);
	}
	
public function edit_inspection($_id)
{
$res=$this->fetch->edit_inspection($_id);	

foreach ($res as $row)
{
$data['_id']=$row->_id;
$data['date']=$row->date;
$data['call_sign']=$row->call_sign;	
$data['ondate']=$row->ondate;
$data['athours']=$row->athours;
$data['next_inspection']=$row->next_inspection;

}
	
$this->load->view('edit_inspection',$data);	
		
}

public function update_inspection()
	{
$data['_id']= $this->input->post('_id');
$data['date']=$this->input->post('date');
$data['call_sign']=$this->input->post('call_sign');	
$data['ondate']=$this->input->post('ondate');
$data['athours']=$this->input->post('athours');
$data['next_inspection']=$this->input->post('next_inspection');
$res=$this->fetch->update_inspection($data);

	if(($_SESSION['deploy']=="technician")||($_SESSION['deploy']=="technician_ops")){
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);}
	else if($_SESSION['deploy']=="ops"){
$res0['res0']=$this->fetch->fetch_tec2();
$this->load->view('technician2',$res0);}
}
public function corrected($_id)
	{
$data['_id']= $_id;
$this->fetch->fetch_corrected($data);
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);


}
public function resume($d)
	{
		$data['tel']=$d;
$res0['res1']=$this->fetch->summary2($data);	
$res0['res0']=$this->fetch->fetch_pilot2();
$this->load->view('pilot2',$res0);
	}
	
public function aircraft_time()
	{	
$data['aircraft']= $this->input->post('aircraft');
$data['time']= $this->input->post('time');


$res3['res3']=$this->fetch->insert_time($data);
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);
	}
	
	public function engine_time()
	{	

$data['aircraft']= $this->input->post('aircraft');
$data['time']= $this->input->post('time');


$res3['res3']=$this->fetch->insert_time2($data);
$res0['res4']=$this->fetch->problem();
$res0['res0']=$this->fetch->fetch_tec();
$res0['res1']=$this->fetch->fetch_f();
$this->load->view('technician',$res0);
	}
	
	public function reported()
	{
$res0['res3']=$this->fetch->fetch_rectified();
$res0['res4']=$this->fetch->problem();
$this->load->view('reported',$res0);
	}
}
