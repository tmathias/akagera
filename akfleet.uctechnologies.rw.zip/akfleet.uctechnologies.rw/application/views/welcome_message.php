<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Ops</title>    
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">

function printDiv(print_content){
 
 var printContents = document.getElementById("print_content").innerHTML;
 w=window.open();
 w.document.write(printContents);
 w.print();
 w.close();
}

 </script>
<style>
ul.nav li a, ul.nav li a:visited {
    color: #ffffff !important;
}

ul.nav li a:hover, ul.nav li a:active {
    color: #00ff00 !important;
}

ul.nav li.active a {
    color: #0000ff !important;
	background:inherit;
}
</style>

</head>
<body>
 <div id="container">
 <div class="page-header">
 <center><img height="100px" border="5px" src="<?php echo base_url('images/base.JPG');?>">
 <h2><strong><font face="comic sans MT" color="#06748B">Crew's Data Status</font></center></strong></h2>
 
 <?PHP 
      //echo uri_string();
	$para=$this->uri->segment(3);
	$para2=$this->uri->segment(4); 
	if(!empty($para2)){
		$para3=$para2;
		}else{$para3=$para;}
	?>

 <ul class="nav nav-pills nav-justified">
   
  <li <?PHP if((empty($para))&&($para3=="Sensor_Operator")){?>class="active" <?PHP } ?>style="background:#535050"><a style="color:#ffffff" <?PHP if(empty($para)){?> class="current" <?PHP } ?> href="<?php echo base_url() ?>index.php/welcome/home">All</a></li>
  <li <?PHP if((!empty($para))&&($para3=="15_Wing_Pilot")){?>class="active" <?PHP } ?>style="color:#ffffff;background:#F93D60"><a  href="<?php echo base_url() ?>index.php/welcome/sort_by/15_Wing_Pilot">15 Wing Pilots</a></li>
  <li <?PHP if((!empty($para))&&($para3=="Flight_Enginier")){?>class="active" <?PHP } ?> style="background:#0390C3"><a style="color:#ffffff" href="<?php echo base_url() ?>index.php/welcome/sort_by/Flight_Enginier">Flight Enginiers</a></li>
  <li <?PHP if((!empty($para))&&($para3=="24_Wing_Pilot")){?>class="active" <?PHP } ?> style="background:#F57D7F"><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/sort_by/24_Wing_Pilot">24 Wing Pilots</a></li>
  <li <?PHP if((!empty($para))&&($para3=="Sensor_Operator")){?>class="active" <?PHP } ?> style="background:#FBDD86"><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/sort_by/Sensor_Operator">Sensor Operators</a></li>
  </ul>
  </div>
  <div class="col-sm-4">
  </div>
  <div class="col-sm-4">
<center><ul class="nav navbar-nav">
</center></ul>
</div>
<div class="col-sm-4">
  </div>
</div>

</div>
<div class="col-sm-4">
</div><div class="col-sm-4">
<ul class="nav nav-pills nav-justified"><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/logout" class="btn btn-info btn-lg">Logout</a></li><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/hours" class="btn btn-warning btn-lg">Hours</a></li><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/insert_f" class="btn btn-success btn-lg">Insert New</a></li></ul></div>
<div class="col-sm-4">
</div>
<div class="col-sm-12" style="overflow-y:scroll; height:350px;" id="print_content">

<table class="table table-condensed table-hover" >
                                    <thead>
                                    <?PHP if((!empty($para))&&(($para3=="15_Wing_Pilot")||($para3=="Flight_Enginier")||$para3=="24_Wing_Pilot")||($para3=="Sensor_Operator")){
										$para=$this->uri->segment(3);
	                                    $para2=$this->uri->segment(4); 
										?>
										<tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/sort_by/<?PHP  if(!empty($para2)){echo $para2;}else {echo $para;}?>">Names</a></strong></h5></th>
                                            <th><h5><strong><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/list_by/exp_date/<?PHP if(!empty($para2)){echo $para2;}else {echo $para;}?>">Exp_Medical</a></strong></h5></th>
                                            <th><h5><strong><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/list_by/english_exp/<?PHP if(!empty($para2)){echo $para2;}else {echo $para;}?>">Exp_Proficiency</a></strong></h5></th>
                                            <th><h5><strong><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/list_by/passport_exp/<?PHP if(!empty($para2)){echo $para2;}else {echo $para;}?>">Exp_Passport</strong></h5></th>
                                            <th><h5><strong><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/list_by/crm_exp/<?PHP if(!empty($para2)){echo $para2;}else {echo $para;}?>">Exp_CRM</strong></h5></th>
                                            <th><h5><strong><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/list_by/dgs_exp/<?PHP if(!empty($para2)){echo $para2;}else {echo $para;}?>">Exp_DGs</strong></h5></th>
                                            <th><h5><strong>Edit</strong></h5></th>

                                        </tr><?PHP 
										
									} else{ ?>
                                        <tr class="info">
                                            <th><h5><strong>INDEX</strong></h5></th>
                                            <th><h5><strong><a style="color:#3F3E3E" href="<?php echo base_url() ?>index.php/welcome/home">NAMES</a></strong></h5></th>
                                            <th><h5><strong><a style="color:#3F3E3E" href="<?php echo base_url() ?>index.php/welcome/list_by_all/exp_date">EXP-MEDICAL</a></strong></h5></th>
                                            <th><h5><strong><a style="color:#3F3E3E" href="<?php echo base_url() ?>index.php/welcome/list_by_all/english_exp">EXP-PROFICIENCY</a></strong></h5></th>
                                            <th><h5><strong><a style="color:#3F3E3E" href="<?php echo base_url() ?>index.php/welcome/list_by_all/passport_exp">EXP-PASSPORT</strong></h5></th>
                                             <th><h5><strong><a style="color:#3F3E3E" href="<?php echo base_url() ?>index.php/welcome/list_by_all/crm_exp">EXP_CRM</strong></h5></th>
                                            <th><h5><strong><a style="color:#3F3E3E" href="<?php echo base_url() ?>index.php/welcome/list_by_all/dgs_exp">EXP_DGs</strong></h5></th>
                                            <th><h5><strong>EDIT</strong></h5></th>

                                        </tr>
                                        <?PHP }?>
                                    </thead>



<?PHP
$index=1;
foreach ($res as $row)
{
$d1=date("y-m-d");
$d="20".$d1;
$exp_date=$row->exp_date;
$ext=$row->extension_time;
   	$date1=date_create($exp_date);
	$date2=date_create($d);
	$diff=date_diff($date2,$date1);
	$diff2=$diff->format("%R%a");
	
	$date1x=date_create($row->english_exp);
	$diffx=date_diff($date2,$date1x);
	$diff2x=$diffx->format("%R%a");
	
	$date1y=date_create($row->passport_exp);
	$diffy=date_diff($date2,$date1y);
	$diff2y=$diffy->format("%R%a");
	
	$date1a=date_create($row->crm_exp);
	$diffa=date_diff($date2,$date1a);
	$diff2a=$diffa->format("%R%a");
	
	$date1z=date_create($row->dgs_exp);
	$diffz=date_diff($date2,$date1z);
	$diff2z=$diffz->format("%R%a");
	
	$date3=date_create($ext);
	$diff3=date_diff($date1,$date3);
	$diff32=$diff3->format("%R%a");
	
	$diff4=date_diff($date2,$date3);
	$diff42=$diff4->format("%R%a");
$dob=$row->dob;
$d1 = new DateTime(date('y-m-d'));
$d2 = new DateTime($dob);
$years = $d2->diff($d1);
$years->y;

$exp_date=$row->exp_date;
echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';?><p data-toggle="popover" title="Crucial Info" data-trigger="hover"  data-content='<?PHP echo $row->crew_type;echo "  ";echo "S/N: ";echo $row->service_n;echo "    ";echo "SSN: ";echo $row->social_security_n;echo "    ";echo "Tel: ";echo $row->telephone;echo "    ";echo "Age: ";echo $years->y;?>' </p><a href="<?php echo base_url() ?>index.php/welcome/ci_profile/<?php echo $_id=$row->_id ;?>"><?PHP echo $row->rank;echo ' ';echo $row->firstname;echo ' ';echo $names=$row->lastname;echo '</a>';
echo '</td>';
//$exp_date2=str_replace(array('-','-'), '',$exp_date);

     if(($date1<=$date2)&&($diff32<40)&&($ext=="0000-00-00"))
	 {		
	 echo '<td bgcolor="#F57D7F">';
		 
	 }
	 else if(($diff2<=60)&&($diff2>0))
	 {
	 echo '<td bgcolor="#FBDD86">';
	 }
	 
	 else if(($diff32>40)&&(($diff42>0)))
	 {

	 echo '<td bgcolor="#0390C3">';
	 }
	  else if(($diff42<=0)&&($ext!="0000-00-00"))
	 {
	 echo '<td bgcolor="#F83F42">';
	 }
	 
	 else if($diff2>60)
	 {
		echo '<td bgcolor="#4CFB91">';
 
	 }
	 else
	 {
		echo '<td bgcolor="#000000">';
 
	 }
	 echo $exp_date=$row->exp_date;echo '</td>';
	 
	  if(($date1x<=$date2))
	 {		
	 echo '<td bgcolor="#F57D7F">';
		 
	 }
	 else if(($diff2x<=60)&&($diff2x>0))
	 {
	 echo '<td bgcolor="#FBDD86">';
	 }
	 	 
	 else if($diff2x>60)
	 {
		echo '<td bgcolor="#4CFB91">';
 
	 }
	 else
	 {
		echo '<td bgcolor="#000000">';
 
	 }	 	
	 echo $row->english_exp;echo '</td>';	
	 
	  if(($date1y<=$date2))
	 {		
	 echo '<td bgcolor="#F57D7F">';
		 
	 }
	 else if(($diff2y<=60)&&($diff2y>0))
	 {
	 echo '<td bgcolor="#FBDD86">';
	 }
	 	 
	 else if($diff2y>60)
	 {
		echo '<td bgcolor="#4CFB91">';
 
	 }
	 else
	 {
		echo '<td bgcolor="#000000">';
 
	 }
	 
	 echo $row->passport_exp;echo '</td>';
	 
	 
	  if(($date1a<=$date2))
	 {		
	 echo '<td bgcolor="#F57D7F">';
		 
	 }
	 else if(($diff2a<=60)&&($diff2a>0))
	 {
	 echo '<td bgcolor="#FBDD86">';
	 }
	 	 
	 else if($diff2a>60)
	 {
		echo '<td bgcolor="#4CFB91">';
 
	 }
	 else
	 {
		echo '<td bgcolor="#000000">';
 
	 }
	 
	 echo $row->crm_exp;echo '</td>';
	 
	  if(($date1z<=$date2))
	 {		
	 echo '<td bgcolor="#F57D7F">';
		 
	 }
	 else if(($diff2z<=60)&&($diff2z>0))
	 {
	 echo '<td bgcolor="#FBDD86">';
	 }
	 	 
	 else if($diff2z>60)
	 {
		echo '<td bgcolor="#4CFB91">';
 
	 }
	 else
	 {
		echo '<td bgcolor="#000000">';
 
	 }
	 
	 echo $row->dgs_exp;echo '</td>';	
	 
	 echo '<td>';
	?>
     <a href="<?php echo base_url() ?>index.php/welcome/edit_f2/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';
     echo '</tr>';
	 $index++;
}?>
   </tbody>
  </table>
 </div>
 </div>
</body>
<script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

</script>

</html>

