<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Edit Info</title> 
       <style type="text/css">
.form-style-7{
    max-width:80%;
    margin:50px auto;
    background:#fff;
    border-radius:2px;
    padding:20px;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 h1{
    display: block;
    text-align: center;
    padding: 0;
    margin: 0px 0px 20px 0px;
    color: #5C5C5C;
    font-size:x-large;
}
.form-style-7 ul{
    list-style:none;
    padding:0;
    margin:0;   
}
.form-style-7 li{
    display: block;
    padding: 9px;
    border:1px solid #DDDDDD;
	    margin-right: 20px;

    margin-bottom: 30px;
    border-radius: 3px;
}
.form-style-7 li:last-child{
    border:none;
    margin-bottom: 0px;
    text-align: center;
}
.form-style-7 li > label{
    display: block;
    float: left;
    margin-top: -19px;
    background: #FFFFFF;
    height: 14px;
    padding: 2px 5px 2px 5px;
    color: #B9B9B9;
    font-size: 14px;
    overflow: hidden;
    font-family: Arial, Helvetica, sans-serif;
}
.form-style-7 input[type="text"],
.form-style-7 input[type="date"],
.form-style-7 input[type="datetime"],
.form-style-7 input[type="email"],
.form-style-7 input[type="number"],
.form-style-7 input[type="search"],
.form-style-7 input[type="time"],
.form-style-7 input[type="url"],
.form-style-7 input[type="password"],
.form-style-7 textarea,
.form-style-7 select 
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    display: block;
    outline: none;
    border: none;
    height: 25px;
    line-height: 25px;
    font-size: 16px;
    padding: 0;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 input[type="text"]:focus,
.form-style-7 input[type="date"]:focus,
.form-style-7 input[type="datetime"]:focus,
.form-style-7 input[type="email"]:focus,
.form-style-7 input[type="number"]:focus,
.form-style-7 input[type="search"]:focus,
.form-style-7 input[type="time"]:focus,
.form-style-7 input[type="url"]:focus,
.form-style-7 input[type="password"]:focus,
.form-style-7 textarea:focus,
.form-style-7 select:focus 
{
}
.form-style-7 li > span{
    background: #F3F3F3;
    display: block;
    padding: 3px;
    margin: 0 -9px -9px -9px;
    text-align: center;
    color: #C0C0C0;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
}
.form-style-7 textarea{
    resize:none;
}
.form-style-7 input[type="submit"],
.form-style-7 input[type="button"]{
    background: #2471FF;
    border: none;
    padding: 10px 20px 10px 20px;
    border-bottom: 3px solid #5994FF;
    border-radius: 3px;
    color: #D2E2FF;
}
.form-style-7 input[type="submit"]:hover,
.form-style-7 input[type="button"]:hover{
    background: #6B9FFF;
    color:#fff;
}
</style>
    
<!--<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" href="</head>/?php echo base_url('js/jquery.min.js');?>"></script>

<script type="text/javascript" href="<?//php echo base_url('bootstrap/js/bootstrap.min.js');?>"></script>-->


</head>
<body>

 <div id="container">
  <div class="page-header">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center><br/>
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="<?php echo base_url() ?>index.php/welcome/home_ops">Edit Logged Data</a></font></center></strong></h2>
    
 </div>
 
<?PHP

$form1 = array(
'class' => 'form-style-7'
);

echo form_open('Welcome/update_hours',$form1);
echo validation_errors();?>
 <table align="center"><tr>
 <td width="30%">
</td>    
<td width="30%">
<?PHP 

require(APPPATH.'include/link_database.php');

$today=date("y-m-d");	

echo '<ul>';
echo form_hidden('_id',$_id);

echo '<li>';
echo form_label('Date');
$date1 = array(
'type' => 'date',
'required' =>'required',
'name' =>'flight_date',
'value' =>$flight_date,
);
echo form_input($date1);
echo '<span>Flight Date</span>';
echo '</li>';
echo '<li>';
echo form_label('From');

 $from= array(
'type' => 'text',
'required' =>'required',
'name' =>'flight_from',
'value' =>$flight_from);
echo form_input($from);

echo '<span>Flight From</span>';
echo '</li>';

echo '<li>';
echo form_label('To');

 $to= array(
'type' => 'text',
'required' =>'required',
'name' =>'flight_to',
'value' =>$flight_to,);
echo form_input($to);

echo '<span>Flight To</span>';
echo '</li>';

echo '<li>';
echo form_label('Call Sign');

if($_SESSION['deploy']=="pilot" or "pilot_ops"){
$query=mysqli_query($conn,"SELECT * from morning_check where approved='yes' and DATE( SUBSTRING(date_time
FROM 1 
FOR 10 ) )='$today' ");
}else if($_SESSION['deploy']=="ops"){
$query=mysqli_query($conn,"SELECT * from aircraft ");	
}
?>
 <select name="call_sign" class="form-control input-sm">
 
 <?PHP

 while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"];?>"<?PHP if ($row["call_sign"]==$call_sign){?>selected="selected"<?PHP } ?>> <?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo '<span>Select</span>';
echo '</li>';
$query=mysqli_query($conn,"SELECT * from flights  where _id='$_id'");
while ($rown = mysqli_fetch_array($query)){
if(($rown['pic_instr']==$rown['logged'])&&$rown['copilot_instr']!="solo"){
$ch="copilot/student";	
$c=$rown['copilot_instr'];
}
else if ($rown['copilot_instr']==$rown['logged']){$ch="PIC/INSTR";$c=$rown['pic_instr'];
}
else{$ch="solo";	
$c=$rown['copilot_instr'];}	

} 
if($_SESSION['deploy']=="pilot" or "pilot_ops"){
echo '<li>';
echo form_label('Other pilot duties if any');
$type = array(
'PIC/INSTR' => 'PIC/INSTR',
'copilot/student' => 'copilot/student',
'solo' => 'solo');
echo form_dropdown('type',$type,$ch,'class="form-control input-sm"');
echo '<span>Select </span>';
echo '</li>';

echo '<li>';
echo form_label('Other Pilot Names');

$query=mysqli_query($conn,"SELECT * from workers  where department='pilot' or department='pilot_ops' or department='Student'");
echo '<select name="pilot">';
while ($rown = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $rown["tel"];?>"<?PHP if ($rown["tel"]==$c){?>selected="selected"<?PHP } ?>> <?PHP echo $rown["firstname"]."  ".$rown["lastname"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo '<span>Select</span>';
echo '</li>';
}
else if($_SESSION['deploy']=="ops"){
	echo '<li>';
echo form_label('PIC');

$query=mysqli_query($conn,"SELECT * from workers  where department='pilot'");
echo '<select name="pic_instr">';
while ($rown = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $rown["tel"];?>"<?PHP if ($rown["tel"]==$pic_instr){?>selected="selected"<?PHP } ?>> <?PHP echo $rown["firstname"]."  ".$rown["lastname"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo '<span>Select</span>';
echo '</li>';echo '<li>';
echo form_label('copilot');

$query=mysqli_query($conn,"SELECT * from workers  where department='pilot'");
echo '<select name="copilot_instr">';
while ($rown = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $rown["tel"];?>"<?PHP if ($rown["tel"]==$copilot_instr){?>selected="selected"<?PHP } ?>> <?PHP echo $rown["firstname"]."  ".$rown["lastname"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo '<span>Select</span>';
echo '</li>';
	}
echo '<li>';
echo form_label('Charter or flight exercise');
$exercise = array(
'charter' => 'charter',
'ex1' => 'ex1',
'ex2' => 'ex2',
'ex3' => 'ex3',
'ex4' => 'ex4',
'ex5' => 'ex5',
'ex6' => 'ex6',
'ex7' => 'ex7',
'ex8' => 'ex8',
'ex9' => 'ex9',
'ex10' => 'ex10',
'ex11' => 'ex11',
'ex12' => 'ex12',
'ex13' => 'ex13',
'ex14' => 'ex14',
'ex15' => 'ex15',
'ex16' => 'ex16',
'ex17' => 'ex17',
'ex18' => 'ex18',
'ex19' => 'ex19',
'ex20' => 'ex20',
'ex21' => 'ex21',
'ex22' => 'ex22',
'ex23' => 'ex23',
'ex24' => 'ex24',
'ex25' => 'ex25',
'ex26' => 'ex26',
'ex27' => 'ex27',
'ex28' => 'ex28',
'ex29' => 'ex29',
'ex30' => 'ex30',
'ex31' => 'ex31',
'ex32' => 'ex32',
'ex33' => 'ex33',
'ex34' => 'ex34',
);
echo form_dropdown('flight_exercise',$exercise,$flight_exercise,'class="form-control input-sm"');

echo '<span>Select</span>';
echo '</li>';

echo '<li>';
echo form_label('Weight');
$w = array(
'type' => 'number',
'name' => 'weight',
'value'=>$weight,
'step' => 'any',
'placeholder' => 'weight',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($w);
echo '<span>Weight</span>';
echo '</li>';

echo '<li>';
echo form_label('start_time ');
$dep = array(
'type' => 'time',
'required' =>'required',
'value' => $start_time,
'name' => 'start_time',
);
echo form_input($dep);
echo '<span>Departure</span>';
echo '</li>';

echo '<li>';
echo form_label('stop_time Time');
$arr = array(
'type' => 'time',
'required' =>'required',
'value' => $stop_time,
'name' => 'stop_time',
);
echo form_input($arr);
echo '<span>Arrival</span>';
echo '</li>';

echo '<li>';
echo form_label('Landing hours');
$landing = array(
'type' => 'number',
'step' => 'any',
'placeholder' => 'landing hours',
'name' => 'landing_hours',
'value' => $landing_hours,
'class' => 'form-control input-sm',);
echo form_input($landing);
echo '<span>Hobs after Flight</span>';
echo '</li>';

echo '<li>';
echo form_label('Fuel in Main Tank');
$main = array(
'type' => 'text',
'placeholder' => 'main tank',
'name' => 'fuel_main',
'value' => $fuel_main,
'class' => 'form-control input-sm',);
echo form_input($main);
echo '<span>Capacity ,fraction or kg</span>';
echo '</li>';

echo '<li>';
echo form_label('Fuel in Auxilliary Tank');
$aux = array(
'type' => 'text',
'name' => 'fuel_aux',
'placeholder' => 'aux tank',
'value' => $fuel_aux,
'class' => 'form-control input-sm',);
echo form_input($aux);
echo '<span>Capacity ,fraction or kg</span>';
echo '</li>';

echo '<li>';
echo form_label('authorised flight time');
$auth = array(
'type' => 'text',
'value' => $auth_flighttime,
'name' => 'auth_flighttime',
'class' => 'form-control input-sm',);
echo form_input($auth);
echo '<span>Duration</span>';
echo '</li>';

echo '<li>';
echo form_label('Problem Reported');
$pr = array(
'type' => 'text',
'value' => $problem,
'name' => 'problem',
'class' => 'form-control input-sm',);
echo form_input($pr);
echo '<span>Problem encountered in floght</span>';
echo '</li>';

echo '<li>';
echo form_submit('submit','Update','class="btn btn-info btn-block"');
echo '</li>';?></td></ul>
  <td width="30%">
  </td>
  </tr>
  </table>
