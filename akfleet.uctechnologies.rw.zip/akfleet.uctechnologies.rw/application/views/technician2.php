<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Morning Check</title> 
    <style type="text/css">
.input_container ul{
	   width::256px;
	   border:1px solid #eaeaea;
	   position:absolute;
	   z-index:9;
	   background:#f3f3f3;
	   list-style:none;
   }
   .input_container ul li:hover{
	   background:#337ab7;
   }
   #view_search{
	   display:none;
	   
	   }
	   
	    #view_search2{
	   display:none;
	   
	   }
	   
	    #view_cond{
	   display:none;
	   
	   }

</style>   
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Date picker for mozilla-->

<script src="//cdn.jsdelivr.net/webshim/1.14.5/polyfiller.js"></script>
<script>
    webshims.setOptions('forms-ext', {types: 'date'});
webshims.polyfill('forms forms-ext');
</script>

</head>
<body>
<?PHP
require(APPPATH.'include/link_database.php');

 ?>

 <div id="container">
  <div class="page-header">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center>
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="#">Morning Check Data</a></font></center></strong></h2>
<a href="<?PHP echo base_url() ?>index.php/welcome/logout">Logout</a>    
  </div>
<center><a href="<?php echo base_url() ?>index.php/welcome/home" class="btn btn-info btn-lg"><span class="glyphicon glyphicon-home"></span></a></center>
<?PHP if(!empty($res2)){?>
<h3><strong><center><?PHP echo "From: "; echo $_SESSION['from'];echo "  To:  ";echo $_SESSION['to'];echo " on:  ";echo $_SESSION['aircraft']; ?></center></strong></h3>
<?PHP }else{ ?>
<h3><strong><center>From last entries</center></strong></h3>
<?php }?><div class="col-sm-1"></div>
<div class="col-sm-10" align="center" style="overflow-y:scroll; height:350px;" id="print_content">
<table class="table table-condensed table-hover" span="100%">
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Remarks</strong></h5></th>
											<th><h5><strong>Checked By</strong></h5></th>
                                            <th><h5><strong>Approved</strong></h5></th>
                                            <?PHP if(($_SESSION['deploy']!="pilot_ops")&&($_SESSION['deploy']!="technician_ops")){?><th><h5><strong>Edit</strong></h5></th><?php }?>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;
if(!empty($res2))	
$res3=$res2;
else
$res3=$res0;
foreach ($res3 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->check_date;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';



echo '<td>';echo $row->remarks;echo '</td>';

/** the done by column */
$id=$row->done_by;
$query=mysqli_query($conn,"SELECT * from workers  where tel='$id' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';

echo '<td>';echo $row->approved;echo '</td>';

	if(($_SESSION['deploy']!="pilot_ops")&&($_SESSION['deploy']!="technician_ops")){?>
    <td><a href="<?php echo base_url() ?>index.php/welcome/edit_technician/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';}
//$amount=0;$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?>
</tbody>
  </table>
  </div>
  <div class="col-sm-1">
</div>

<br>
<br>
<br>
<div class="col-sm-12">
<div class="row form-inline" align="center"> 
<?PHP echo form_open('welcome/hours_tec2'); 

$from = array(
'type' => 'date',
'name' => 'from',
'required' => 'required',
'class' => 'form-control input-sm',

);
echo form_input($from);

$to = array(
'type' => 'date',
'name' => 'to',
'required' => 'required',
'class' => 'form-control input-sm',

);
echo form_input($to);
$query=mysqli_query($conn,"SELECT * from aircraft ");
?>
 <select name="aircraft" class="form-control input-sm">
 <option>--Select a/c--</option>
<?PHP
while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo form_submit('submit','Check ','class="btn btn-info btn-sm"');
echo '</div>';?>
</div>
<div class="col-sm-1"></div>



