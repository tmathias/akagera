<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Edit Data</title> 
       <style type="text/css">
.form-style-7{
    max-width:80%;
    margin:50px auto;
    background:#fff;
    border-radius:2px;
    padding:20px;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 h1{
    display: block;
    text-align: center;
    padding: 0;
    margin: 0px 0px 20px 0px;
    color: #5C5C5C;
    font-size:x-large;
}
.form-style-7 ul{
    list-style:none;
    padding:0;
    margin:0;   
}
.form-style-7 li{
    display: block;
    padding: 9px;
    border:1px solid #DDDDDD;
	    margin-right: 20px;

    margin-bottom: 30px;
    border-radius: 3px;
}
.form-style-7 li:last-child{
    border:none;
    margin-bottom: 0px;
    text-align: center;
}
.form-style-7 li > label{
    display: block;
    float: left;
    margin-top: -19px;
    background: #FFFFFF;
    height: 14px;
    padding: 2px 5px 2px 5px;
    color: #B9B9B9;
    font-size: 14px;
    overflow: hidden;
    font-family: Arial, Helvetica, sans-serif;
}
.form-style-7 input[type="text"],
.form-style-7 input[type="date"],
.form-style-7 input[type="datetime"],
.form-style-7 input[type="email"],
.form-style-7 input[type="number"],
.form-style-7 input[type="search"],
.form-style-7 input[type="time"],
.form-style-7 input[type="url"],
.form-style-7 input[type="password"],
.form-style-7 textarea,
.form-style-7 select 
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    display: block;
    outline: none;
    border: none;
    height: 25px;
    line-height: 25px;
    font-size: 16px;
    padding: 0;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 input[type="text"]:focus,
.form-style-7 input[type="date"]:focus,
.form-style-7 input[type="datetime"]:focus,
.form-style-7 input[type="email"]:focus,
.form-style-7 input[type="number"]:focus,
.form-style-7 input[type="search"]:focus,
.form-style-7 input[type="time"]:focus,
.form-style-7 input[type="url"]:focus,
.form-style-7 input[type="password"]:focus,
.form-style-7 textarea:focus,
.form-style-7 select:focus 
{
}
.form-style-7 li > span{
    background: #F3F3F3;
    display: block;
    padding: 3px;
    margin: 0 -9px -9px -9px;
    text-align: center;
    color: #C0C0C0;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
}
.form-style-7 textarea{
    resize:none;
}
.form-style-7 input[type="submit"],
.form-style-7 input[type="button"]{
    background: #2471FF;
    border: none;
    padding: 10px 20px 10px 20px;
    border-bottom: 3px solid #5994FF;
    border-radius: 3px;
    color: #D2E2FF;
}
.form-style-7 input[type="submit"]:hover,
.form-style-7 input[type="button"]:hover{
    background: #6B9FFF;
    color:#fff;
}
</style>
    
<!--<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" href="</head>/?php echo base_url('js/jquery.min.js');?>"></script>

<script type="text/javascript" href="<?//php echo base_url('bootstrap/js/bootstrap.min.js');?>"></script>-->


</head>
<body>

 <div id="container">
  <div class="page-header">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center><br/>
  <h2><strong><center><font face="Old English TEXT MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="<?php echo base_url() ?>index.php/welcome/home_inspection">Edit Data</a></font></center></strong></h2>
    
 </div>
 
<?PHP

require(APPPATH.'include/link_database.php');


$form1 = array(
'class' => 'form-style-7'
);

echo form_open('Welcome/update_inspection',$form1);
echo validation_errors();?>
 <table align="center"><tr>
 <td width="30%">
</td>    
<td width="30%">

<?PHP 
echo '<ul>';
echo form_hidden('_id',$_id);

echo '<li>';
echo form_label('Date');
$date1 = array(
'type' => 'date',
'required' =>'required',
'name' =>'date',
'value' =>$date,
);
echo form_input($date1);
echo '<span>Flight Date</span>';
echo '</li>';
echo '<li>';
echo form_label('Call Sign');

$query=mysqli_query($conn,"SELECT * from aircraft ");	
?>
<select name="call_sign" class="form-control input-sm"> 
 <?PHP

 while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"];?>"<?PHP if ($row["call_sign"]==$call_sign){?>selected="selected"<?PHP } ?>> <?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo '<span>Select</span>';
echo '</li>';
echo '<li>';
echo form_label('Next Inspection');
$n = array(
'type' => 'text',
'required' =>'required',
'name' =>'next_inspection',
'value' =>$next_inspection,
);
echo form_input($n);
echo '<span>Next maintenance ,hours or overall</span>';
echo '</li>';
echo '<li>';
echo form_label('At Hours');
$a = array(
'type' => 'number',
'step' => 'any',
'required' =>'required',
'name' =>'athours',
'value' =>$athours,
);
echo form_input($a);
echo '<span>hobs to undergo maintenance</span>';
echo '</li>';

echo '<li>';
echo form_label('On Date');
$o = array(
'type' => 'date',
'required' =>'required',
'name' =>'ondate',
'value' =>$ondate,
);
echo form_input($o);
echo '<span>Date to undergo maintenance</span>';
echo '</li>';


echo '<li>';
echo form_submit('submit','Update','class="btn btn-info btn-block"');
echo '</li>';?></td></ul>
</td>
<td width="30%"></td>
</tr></table>
