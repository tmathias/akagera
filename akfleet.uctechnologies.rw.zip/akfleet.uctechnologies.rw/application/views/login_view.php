<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<link href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
</head>

<nav class="navbar navbar-default" role="navigation">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <script>
function myFunction() {
    window.print();
}</script>
        <a class="navbar-brand" href="#">RAJA</a>
    </div>
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
        <ul class="nav navbar-nav">
            <li ><a href="ahabanza.php">Ahabanza</a></li>
            <li><a href="stock.php">Stock</a></li>
            <li><a href="suppliers.php">Suppliers</a></li>
            <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ibindi</a>
               <ul class="dropdown-menu">
                    <li><a href="depense.php">Depense</a></li>
                    <li><a href="abakiriya.php">Abakiriya</a></li>
                    <li class="divider"></li>
                    <li><a href="abakozi.php">Abakozi</a></li>
                    <li><a href="inguzanyo.php">Inguzanyo</a></li>
                    <!--<li><a href="imisoro.php">imisoro</a></li>-->


                    <li><a href="raporo.php">raporo</a></li>
                                      
                </ul>
            </li>
        </ul>
       <!--  <div class="col-sm-3 col-md-3 pull-right">
            <form class="navbar-form" role="search">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search" name="q">
                    <div class="input-group-btn">
                        <button class="btn btn-default" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                    </div>
                </div>
            </form>
        </div>         -->
    </div>
</nav>

<body>
<div class="navbar">
<div class="navbar-inner">
 <div class="container">
  <ul class="nav">
<li class="dropdown"><a class "dropdown-toggle" data-toggle="dropdown" href="#">link1</a></li>
<li><a href="#">link2</a></li>
<li><a href="#">link3</a></li>
</ul>
</div>
</div>
</div>
<?php

echo form_open('login_controller/insert'); 

echo validation_errors();


echo form_input('username');
echo form_password('password');
echo form_submit('submit','inserer','class="btn btn-primary"');
echo form_close(); ?>

</body>
</html>