<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Insert</title> 
    <style type="text/css">
.form-style-7{
    max-width:80%;
    margin:50px auto;
    background:#fff;
    border-radius:2px;
    padding:20px;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 h1{
    display: block;
    text-align: center;
    padding: 0;
    margin: 0px 0px 20px 0px;
    color: #5C5C5C;
    font-size:x-large;
}
.form-style-7 ul{
    list-style:none;
    padding:0;
    margin:0;   
}
.form-style-7 li{
    display: block;
    padding: 9px;
    border:1px solid #DDDDDD;
	    margin-right: 20px;

    margin-bottom: 30px;
    border-radius: 3px;
}
.form-style-7 li:last-child{
    border:none;
    margin-bottom: 0px;
    text-align: center;
}
.form-style-7 li > label{
    display: block;
    float: left;
    margin-top: -19px;
    background: #FFFFFF;
    height: 14px;
    padding: 2px 5px 2px 5px;
    color: #B9B9B9;
    font-size: 14px;
    overflow: hidden;
    font-family: Arial, Helvetica, sans-serif;
}
.form-style-7 input[type="text"],
.form-style-7 input[type="date"],
.form-style-7 input[type="datetime"],
.form-style-7 input[type="email"],
.form-style-7 input[type="number"],
.form-style-7 input[type="search"],
.form-style-7 input[type="time"],
.form-style-7 input[type="url"],
.form-style-7 input[type="password"],
.form-style-7 textarea,
.form-style-7 select 
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    display: block;
    outline: none;
    border: none;
    height: 25px;
    line-height: 25px;
    font-size: 16px;
    padding: 0;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 input[type="text"]:focus,
.form-style-7 input[type="date"]:focus,
.form-style-7 input[type="datetime"]:focus,
.form-style-7 input[type="email"]:focus,
.form-style-7 input[type="number"]:focus,
.form-style-7 input[type="search"]:focus,
.form-style-7 input[type="time"]:focus,
.form-style-7 input[type="url"]:focus,
.form-style-7 input[type="password"]:focus,
.form-style-7 textarea:focus,
.form-style-7 select:focus 
{
}
.form-style-7 li > span{
    background: #F3F3F3;
    display: block;
    padding: 3px;
    margin: 0 -9px -9px -9px;
    text-align: center;
    color: #C0C0C0;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
}
.form-style-7 textarea{
    resize:none;
}
.form-style-7 input[type="submit"],
.form-style-7 input[type="button"]{
    background: #2471FF;
    border: none;
    padding: 10px 20px 10px 20px;
    border-bottom: 3px solid #5994FF;
    border-radius: 3px;
    color: #D2E2FF;
}
.form-style-7 input[type="submit"]:hover,
.form-style-7 input[type="button"]:hover{
    background: #6B9FFF;
    color:#fff;
}
</style>   
    
<!--<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" href="</head>/?php echo base_url('js/jquery.min.js');?>"></script>

<script type="text/javascript" href="<?//php echo base_url('bootstrap/js/bootstrap.min.js');?>"></script>-->

</head>
<body>

 <div id="container">
  <div class="page-header">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center><br/>
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="index.php/welcome/home">Set Up Initials</a></font></center></strong></h2>
    
  </div>
  <?PHP $form1 = array(
'class' => 'form-style-7'
);

echo form_open_multipart('Welcome/initial',$form1);
echo validation_errors();?>
 <table align="center"><tr>
  <td><?PHP 


echo '<ul>';
echo '<li>';

echo form_label('R44');
$r= array(
'type' => 'number',
'step' => 'any',
'name' => 'R44',
);

echo form_input($r);
echo '<span>Total R44 hours</span>';
echo '</li>';
echo '<li>';
echo form_label('R44 Solo');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'R44_solo',
);

echo form_input($rs);
echo '<span>R44 hours ,solo only</span>';
echo '</li>';
echo '<li>';
echo form_label('R44 instrument');
$ri= array(
'type' => 'number',
'step' => 'any',
'name' => 'R44_instrument',
);

echo form_input($ri);
echo '<span>R44 hours ,instrument only</span>';
echo '</li>';
echo '<li>';
echo form_label('R44 night');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'R44_night',
);

echo form_input($rn);
echo '<span>R44 hours ,night only</span>';
echo '</li>';
echo '<li>';
echo form_label('R22');
$r2= array(
'type' => 'number',
'step' => 'any',
'name' => 'R22',
);

echo form_input($r2);
echo '<span> Total R22 hours</span>';
echo '</li>';
echo '<li>';
echo form_label('R22 Solo');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'R22_solo',
);

echo form_input($rs);
echo '<span>R22 hours ,solo only</span>';
echo '</li>';
echo '<li>';
echo form_label('R22 instrument');
$ri= array(
'type' => 'number',
'step' => 'any',
'name' => 'R22_instrument',
);

echo form_input($ri);
echo '<span>R22 hours ,instrument only</span>';
echo '</li>';
echo '<li>';
echo form_label('R22 night');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'R22_night',
);

echo form_input($rn);
echo '<span>R22 hours ,night only</span>';

echo '</li>';
?></td></ul>
  <td>
<?PHP
echo '<ul>';
echo '<li>';
echo form_label('A109');
$A1= array(
'type' => 'number',
'step' => 'any',
'name' => 'A109',
);

echo form_input($A1);
echo '<span> Total A109 hours</span>';
echo '</li>';
echo '<li>';
echo form_label('A109 Solo');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'A109_solo',
);

echo form_input($rs);
echo '<span>A109 hours ,solo only</span>';
echo '</li>';
echo '<li>';
echo form_label('A109 instrument');
$ri= array(
'type' => 'number',
'step' => 'any',
'name' => 'A109_instrument',
);

echo form_input($ri);
echo '<span>A109 hours ,instrument only</span>';
echo '</li>';
echo '<li>';
echo form_label('A109 night');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'A109_night',
);

echo form_input($rn);
echo '<span>A109 hours ,night only</span>';
echo '</li>';

echo '<li>';
echo form_label(' SIM A109');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'SIM_109',
);

echo form_input($rn);
echo '<span>SIM A109 hours ,night only</span>';

echo '</li>';
echo '<li>';
echo form_label('A139');
$A1= array(
'type' => 'number',
'step' => 'any',
'name' => 'A139',
);

echo form_input($A1);
echo '<span> Total A139 hours</span>';
echo '</li>';
echo '<li>';
echo form_label('A139 Solo');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'A139_solo',
);

echo form_input($rs);
echo '<span>A139 hours ,solo only</span>';
echo '</li>';

echo '<li>';
echo form_submit('submit','Insert','class="btn btn-info btn-block"');
echo '</li>';
?></td></ul>
  <td>
<?PHP
echo '<ul>';
echo '<li>';
echo form_label('A139 instrument');
$ri= array(
'type' => 'number',
'step' => 'any',
'name' => 'A139_instrument',
);

echo form_input($ri);
echo '<span>A139 hours ,instrument only</span>';
echo '</li>';
echo '<li>';
echo form_label('A139 night');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'A139_night',
);

echo form_input($rn);
echo '<span>A139 hours ,night only</span>';
echo '</li>';

echo '<li>';
echo form_label(' SIM A139');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'SIM_139',
);

echo form_input($rn);
echo '<span>SIM A139 hours ,night only</span>';

echo '</li>';
echo '<li>';
echo form_label('others');
$o= array(
'type' => 'number',
'step' => 'any',
'name' => 'others',
);

echo form_input($o);
echo '<span> Total on others</span>';
echo '</li>';
echo '<li>';
echo form_label('Solo on others');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_solo',
);

echo form_input($rs);
echo '<span>others,solo only</span>';
echo '</li>';
echo '<li>';
echo form_label('instrument hours on others');
$ri= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_instrument',
);

echo form_input($ri);
echo '<span>other hours on instrument only</span>';
echo '</li>';
echo '<li>';
echo form_label('night hours on others');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_night',
);

echo form_input($rn);
echo '<span>other hours on night only</span>';
echo '</li>';

echo '<li>';
echo form_label(' SIM on others');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_sim',
);

echo form_input($rn);
echo '<span>SIM on others  ,night only</span>';

echo '</li>';
echo form_close(); 
?>
</ul>
</div>
</td>
  </tr></table>

</html>