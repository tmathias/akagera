<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Technician Page</title> 
    <style type="text/css">
.input_container ul{
	   width::256px;
	   border:1px solid #eaeaea;
	   position:absolute;
	   z-index:9;
	   background:#f3f3f3;
	   list-style:none;
   }
   .input_container ul li:hover{
	   background:#337ab7;
   }
   #view_search{
	   display:none;
	   
	   }
	   
	    #view_search2{
	   display:none;
	   
	   }
	   
	    #view_cond{
	   display:none;
	   
	   }

</style>   
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body>
<?PHP
require(APPPATH.'include/link_database.php');


 ?>

 <div id="container">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center>
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="#">Aircraft Status Form</a></font></center></strong></h2>
<?PHP $tel=$_SESSION['tel']?>
<ul class="nav nav-tabs">
    <?PHP if($_SESSION['deploy']=="technician_ops"){?><li class="active"><a href="<?PHP echo base_url() ?>index.php/welcome/home">Ops</a></li><?PHP }
    else {?><li class="active"><a href="#">Home</a></li><?php }?>
<li><a href="<?PHP echo base_url() ?>index.php/welcome/ci_profile/<?php echo $tel;?>">My profile</a></li>
<li><a href="<?PHP echo base_url() ?>index.php/welcome/reported">Reported</a></li>
<li><a href="<?PHP echo base_url() ?>index.php/welcome/logout">Logout</a></li>
  </ul>   
   

<div class="col-sm-6" align="center" style="overflow-y:scroll; height:350px;" id="print_content">
<div class="row form-inline" align="center"> 
<h3><strong><center>DI Check Form</center></strong></h3>

<?PHP
$today=date("y-m-d");	
echo form_open('Welcome/insert_morning');
echo validation_errors();
echo form_hidden('tel',$_SESSION['user']);

$date = array(
'type' => 'date',
'name' => 'check_date',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($date);

$query=mysqli_query($conn,"SELECT * from aircraft ");
?>
 <select name="aircraft" required class="form-control input-sm">
  <option></option><?PHP
 while ($row = mysqli_fetch_array($query)){
	 $ca=$row["call_sign"];$query2=mysqli_query($conn,"SELECT * from morning_check where check_date='$today' and call_sign='$ca' ");
if(mysqli_num_rows($query2)==0){?>
 <option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP }
else{?> <option disabled><?PHP echo $row["call_sign"]; ?></option>
<?PHP }} ?>
                
        </select>
<?PHP

$rmk = array(
'type' => 'text',
'name' => 'remarks',
'placeholder' => 'remarks',
'class' => 'form-control input-sm',);
echo form_input($rmk);

$app = array(
'yes' => 'yes',
'no' => 'no',

);
echo form_dropdown('approved',$app,'','class="form-control input-sm"');

echo form_submit('submit','Insert','class="btn btn-info"');

echo form_close();?>
<br>

<?PHP 


$sum=0;
if(!empty($res2)){	
$res3=$res2;
}
else{
if(!empty($res0)){
$res3=$res0;
}
}
if(!empty($res3)){

 if(!empty($res2)){?>
<h3><strong><center><?PHP echo " History Checks From: "; echo $_SESSION['from'];echo "  To:  ";echo $_SESSION['to'];echo " on:  ";echo $_SESSION['aircraft']; ?></center></strong></h3>
<?PHP }else{ ?>
<h3><strong><center>Checks Done Today By You</center></strong></h3>
<?PHP } ?>
<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Remarks</strong></h5></th>
											<th><h5><strong>Checked By</strong></h5></th>
                                            <th><h5><strong>Approved</strong></h5></th>
                                            <?PHP if(empty($res2)){?>
                                            <th><h5><strong>Edit</strong></h5></th><?PHP } ?>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;
if(!empty($res2))	
$res3=$res2;
else
$res3=$res0;
foreach ($res3 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->check_date;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';

/*$id=$row->done_by;
$query=mysqli_query($conn,"SELECT * from workers  where _id='$id' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';*/

echo '<td>';echo $row->remarks;echo '</td>';

/** the done by column */
$id=$row->done_by;
$query=mysqli_query($conn,"SELECT * from workers  where tel='$id' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';

echo '<td>';echo $row->approved;echo '</td>';

	
    if(empty($res2)){?><td><a href="<?php echo base_url() ?>index.php/welcome/edit_technician/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';}
//$amount=0;$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}}?>
</tbody>
  </table>
  
  </div>
  <div class="col-sm-1">
</div>

<br>
<br>
<br>
<div class="col-sm-12">
<div class="row form-inline" align="center">
<h4><strong><center>DI History Form</center></strong></h4> 
<?PHP echo form_open('welcome/hours_tec'); 

$from = array(
'type' => 'date',
'name' => 'from',
'class' => 'form-control input-sm',

);
echo form_input($from);

$to = array(
'type' => 'date',
'name' => 'to',
'class' => 'form-control input-sm',

);
echo form_input($to);
$query=mysqli_query($conn,"SELECT * from aircraft ");
?>
 <select name="aircraft" class="form-control input-sm">
 <option>--Select a/c--</option>
<?PHP
while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP
echo form_submit('submit','Check ','class="btn btn-info btn-sm"');
echo form_close();
echo '</div>';?>
</div>
</div>
<div class="col-sm-6" align="center" style="overflow-y:scroll; height:350px;" id="print_content">
<div class="row form-inline" align="center"> 
<?PHP echo form_open('welcome/insert_inspection'); 
$date = array(
'type' => 'date',
'name' => 'maintenance',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($date);

$query=mysqli_query($conn,"SELECT * from aircraft ");
?>
 <select name="call_sign" class="form-control input-sm">
 <?PHP
 while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP

$next = array(
'type' => 'text',
'name' => 'next_inspection',
'placeholder' => 'Next Inspection',
'class' => 'form-control input-sm',);
echo form_input($next);

$at = array(
'type' => 'number',
'step' => 'any',
'name' => 'athours',
'placeholder' => 'on hours',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($at);

$on = array(
'type' => 'date',
'name' => 'ondate',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($on);

echo form_submit('submit','Insert','class="btn btn-info"');

echo form_close();?>

<h3><strong><center>Next-on Maintenance Data</center></strong></h3>

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Next Inspection</strong></h5></th>
                                            <th><h5><strong>At hours</strong></h5></th>
                                            <th><h5><strong>On Date</strong></h5></th>                                            <th><h5><strong>Edit</strong></h5></th>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;

foreach ($res1 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->date;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';
echo '<td>';echo $row->next_inspection;echo '</td>';
echo '<td>';echo $row->athours;echo '</td>';
echo '<td>';echo $row->ondate;echo '</td>';

	
   ?><td><a href="<?php echo base_url() ?>index.php/welcome/edit_inspection/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';
//$amount=0;$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?>
</tbody>
  </table>
  
  <?PHP
$today=date("y-m-d");	
echo form_open('Welcome/aircraft_time');
if($_SESSION['deploy']=="technician_ops"){
?><h4><u>Update of aircraft_time</u></h4><?PHP
$query=mysqli_query($conn,"SELECT * from aircraft ");
?>
 <select name="aircraft" required class="form-control input-sm">
  <option></option><?PHP
 while ($row = mysqli_fetch_array($query)){
 ?><option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP }
 ?>
                
        </select>
<?PHP

$rmk = array(
'type' => 'number',
'name' => 'time',
'placeholder' => 'aircraft time',
'class' => 'form-control input-sm',);
echo form_input($rmk);

echo form_submit('submit','Update','class="btn btn-info"');

echo form_close();} echo '<br>';

echo form_open('Welcome/engine_time');
if($_SESSION['deploy']=="technician_ops"){
?><h4><u>Update of Engine_time</u></h4><?PHP
$query=mysqli_query($conn,"SELECT * from aircraft ");
?>
 <select name="aircraft" required class="form-control input-sm">
  <option></option><?PHP
 while ($row = mysqli_fetch_array($query)){
 ?><option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP }
 ?>
                
        </select>
<?PHP

$rmk = array(
'type' => 'number',
'name' => 'time',
'placeholder' => 'engine time',
'class' => 'form-control input-sm',);
echo form_input($rmk);

echo form_submit('submit','Update','class="btn btn-info"');

echo form_close();}

?>
  
</div>



