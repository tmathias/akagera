<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Log</title> 
    <style type="text/css">
.input_container ul{
	   width::256px;
	   border:1px solid #eaeaea;
	   position:absolute;
	   z-index:9;
	   background:#f3f3f3;
	   list-style:none;
   }
   .input_container ul li:hover{
	   background:#337ab7;
   }
   #view_search{
	   display:none;
	   
	   }
	   
	    #view_search2{
	   display:none;
	   
	   }
	   
	    #view_cond{
	   display:none;
	   
	   }

</style>   
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<!-- Date picker for mozilla -->
<script src="//cdn.jsdelivr.net/webshim/1.14.5/polyfiller.js"></script>
<script>
    webshims.setOptions('forms-ext', {types: 'date'});
webshims.polyfill('forms forms-ext');
</script>

</head>
<body>
<?PHP
require(APPPATH.'include/link_database.php');


 ?>

 <div id="container">
  <div class="page-header">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center>
  
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="#"> Flight Histories</a></font></center></strong></h2>
<a href="<?PHP echo base_url() ?>index.php/welcome/logout">Logout</a>    
  </div>
<center><a href="<?php echo base_url() ?>index.php/welcome/home" class="btn btn-info btn-lg"><span class="glyphicon glyphicon-home"></span></a></center>
<div class="col-sm-12" align="center" style="overflow-y:scroll; height:350px;" id="print_content">
<?PHP 
/*
foreach ($res0 as $row)
{ $rank=$row->rank;$last=$row->lastname;$hours=$row->initial_r44+$row->initial_mi17+$row->initial_mi24+$row->initial_sim24+$row->initial_sim17+$row->MI_24+$row->SIM_24+$row->MI_17+$row->SIM_17; }

echo '<strong><u>';echo $rank;echo "  ";echo $last; echo "  's Session";echo '<br>';
echo "Current Hours  "; echo $hours;echo '</strong></u><br>';*/

if(!empty($res2)){
	$p=$_SESSION['pilot'];
	$query2=mysqli_query($conn,"SELECT * from workers  where tel='$p' ");
while ($row2 = mysqli_fetch_array($query2)){
$pil=$row2["firstname"];}
	 ?>
<h3><strong><center><?PHP if(!empty($pil)){?><a data-toggle="modal" data-target="#myModal"><?PHP echo $pil;echo '</a>';}echo "  ";echo "From: "; echo $_SESSION['from'];echo "  To:  ";echo $_SESSION['to'];echo " On:  ";echo $_SESSION['call_sign']; ?></center></strong></h3>

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Flight From</strong></h5></th> <th><h5><strong>Flight To</strong></h5></th> <th><h5><strong>Aircraft</strong></h5></th> <th><h5><strong>Weight</strong></h5></th> <th><h5><strong>Start Time</strong></h5></th> <th><h5><strong>Stop Time</strong></h5></th><th><h5><strong>Time</strong></h5></th><th><h5><strong>Landing Hours</strong></h5></th><th><h5><strong>Fuel Main</strong></h5></th> <th><h5><strong>Fuel aux</strong></h5></th><th><h5><strong>Flight</strong></h5></th><th><h5><strong>Auth-Flight Time</strong></h5></th>
<th><h5><strong>Pilot</strong></h5></th><th><h5><strong>Co-Pilot</strong></h5></th>
                                            
                                            <?PHP if($_SESSION['deploy']!="pilot_ops"){?><th><h5><strong>Edit</strong></h5></th><?php } ?>
                                            </tr>
                                            </thead>
                                            <tbody>
<?PHP
$index=1;
$sum=0;

foreach ($res2 as $row)
{
echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->flight_date;echo '</td>';
echo '<td>';echo $row->flight_from;echo '</td>';
echo '<td>';echo $row->flight_to;echo '</td>';
$call=$row->call_sign;
$que=mysqli_query($conn,"SELECT * from flights  where call_sign='$call' and status='yes' ");
if (mysqli_num_rows($que)==0) {
echo '<td>';echo $call=$row->call_sign;echo '</td>';	
}else{
 while ($ro = mysqli_fetch_array($que)){

	echo '<td bgcolor="#62CBF7">';?><p data-toggle="popover" title="PROBLEM REPORTED" data-trigger="hover"  data-content=	'<?PHP echo $ro['problem'];}?>'</p><?PHP echo $call=$row->call_sign; 
echo'</td>';}echo '<td>';echo $row->weight;echo '</td>';
echo '<td>';echo $row->start_time;echo '</td>';
echo '<td>';echo $row->stop_time;echo '</td>';
echo '<td>';echo $hobs=$row->engine_hobs;echo '</td>';
echo '<td>';echo $row->landing_hours;echo '</td>';
echo '<td>';echo $row->fuel_main;echo '</td>';
echo '<td>';echo $row->fuel_aux;echo '</td>';
echo '<td>';echo $row->flight_exercise;echo '</td>';//WHEN NEW AIRCRAFT IS USED,LOG SUMMARY PR
echo '<td>';echo $row->auth_flighttime;echo '</td>';

$pilot=$row->pic_instr;
$service_n=$pilot;	
$pilote=$row->copilot_instr;

$sql=mysqli_query($conn,"select * from initial join workers on initial.tel=workers.tel where initial.tel='$p'");

$sql1=mysqli_query($conn,"select sum(engine_hobs) from flights  where (pic_instr='$p' or copilot_instr='$p')");


$query1=mysqli_query($conn,"select sum(engine_hobs) as sum44 from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$p' or copilot_instr='$p') and type='R44'");
$query2=mysqli_query($conn,"select sum(engine_hobs) as instrument from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$p' or copilot_instr='$p') and flight_exercise='instrument'  ");
$query3=mysqli_query($conn,"select sum(engine_hobs) as solo44 from flights join aircraft on flights.call_sign=aircraft.call_sign where copilot_instr='solo' and pic_instr='$p' and type='R44'  ");
$query4=mysqli_query($conn,"select sum(engine_hobs) as night from flights join aircraft on flights.call_sign=aircraft.call_sign where start_time >= '17:00:00' and (pic_instr='$p' or copilot_instr='$p') ");
$query5=mysqli_query($conn,"select sum(engine_hobs) as instructor from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$p' or copilot_instr='$p') and flight_exercise='instructor'  ");

$query1b=mysqli_query($conn,"select sum(engine_hobs) as sum109 from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$p' or copilot_instr='$p') and type='A109'");
$query3b=mysqli_query($conn,"select sum(engine_hobs) as solo109 from flights join aircraft on flights.call_sign=aircraft.call_sign where copilot_instr='solo' and pic_instr='$p' and type='A109'  ");
$query5b=mysqli_query($conn,"select sum(engine_hobs) as sim_109 from flights where call_sign='SIM_109' and (pic_instr='$p' or copilot_instr='$p')");

$query1c=mysqli_query($conn,"select sum(engine_hobs) as sum139 from flights join aircraft on flights.call_sign=aircraft.call_sign where (pic_instr='$p' or copilot_instr='$p') and type='A139'");
$query3c=mysqli_query($conn,"select sum(engine_hobs) as solo139 from flights join aircraft on flights.call_sign=aircraft.call_sign where copilot_instr='solo' and pic_instr='$p' and type='A139'  ");
$query5c=mysqli_query($conn,"select sum(engine_hobs) as sim_139 from flights where call_sign='SIM_139' and (pic_instr='$p' or copilot_instr='$p')");

while ($r1 = mysqli_fetch_array($query1)){$sum44=$r1[0];}while ($r2 = mysqli_fetch_array($query2)){$instrument=$r2[0];}
while ($r3 = mysqli_fetch_array($query3)){$solo44=$r3[0];}	while ($r4 = mysqli_fetch_array($query4)){$night=$r4[0];}while ($r5 = mysqli_fetch_array($query5)){$instructor=$r5[0];}while ($r1b = mysqli_fetch_array($query1b)){$sum109=$r1b[0];}while ($r3b = mysqli_fetch_array($query3b)){$solo109=$r3b[0];}while ($r5b = mysqli_fetch_array($query5b)){$sim109=$r5b[0];}while ($r1c = mysqli_fetch_array($query1c)){$sum139=$r1c[0];}
while ($r3c = mysqli_fetch_array($query3c)){$solo139=$r3c[0];}while ($r5c = mysqli_fetch_array($query5c)){$sim139=$r5c[0];}



while ($row = mysqli_fetch_array($sql)){
$initial_instructor=$row['instructor'];
$initial_night=$row['night'];
$initial_instrument=$row['instrument'];
$R44=$row['R44'];
$R44_solo=$row['R44_solo'];
$A109=$row['A109'];
$A109_solo=$row['A109_solo'];
$SIM_109=$row['SIM_109'];
$A139=$row['A139'];
$A139_solo=$row['A139_solo'];
$SIM_139=$row['SIM_139'];
$others=$row['others'];
$others_solo=$row['others_solo'];
$others_SIM=$row['others_SIM'];
$others_turbine=$row['others_turbine'];
$others_multiengine=$row['others_multiengine'];}
	

	

$query=mysqli_query($conn,"SELECT * from workers  where tel='$pilot' ");
echo '<td>';

while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"];}
echo '</td>'; 
echo '<td>';
if(($pilote=="solo")||(($pilote=="sim"))){
	

}else{
	
$query2=mysqli_query($conn,"SELECT * from workers  where tel='$pilote' ");
while ($row2 = mysqli_fetch_array($query2)){
echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }}echo '</td>';

$sum=$sum+$hobs;
if($_SESSION['deploy']!="pilot_ops"){echo '<td>';
	?>
     <a href="<?php echo base_url() ?>index.php/welcome/edit_hours/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';}
echo '</tr>';
	 $index++;
}
?>
<tr><td><strong>Total</strong></td><td colspan="7"></td><td><?PHP echo $sum; ?></td><td colspan="8"></td></tr>



<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
           Modal content
       
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Log Book Summary</h4>
        </div>
        <div class="modal-body">

<p><strong>R44 : <?PHP echo $sum44+$R44;?></strong>&nbsp;&nbsp;PIC: <?PHP echo $solo44+$R44_solo;?></p>

<p><strong>A109 : <?PHP echo $sum109+$A109;?></strong>&nbsp;&nbsp;Sim: <?PHP echo $sim109+$SIM_109;?> &nbsp;&nbsp;PIC: <?PHP echo $solo109+$A109_solo;?></p> 
           
<p><strong>A139 : <?PHP echo $sum139+$A139;?></strong>&nbsp;&nbsp;Sim: <?PHP  echo $sim139+$SIM_139;?> &nbsp;&nbsp; PIC: <?PHP echo $solo139+$A139_solo;?></p>
            
<p><strong>Others : <?PHP echo $others;?></strong>&nbsp;&nbsp;Sim: <?PHP echo $others_SIM;?>&nbsp;&nbsp; PIC: <?PHP echo $others_solo;?></p>
            
<p><strong>Total : <?PHP echo $sum44+$R44+$sum109+$A109+$sum139+$A139+$others;?></strong>&nbsp;&nbsp;Sim: <?PHP echo $sim139+$SIM_139+$sim109+$SIM_109+$others_SIM;?> &nbsp;&nbsp;PIC: <?PHP echo $solo44+$R44_solo+$solo109+$A109_solo+$solo139+$A139_solo+$others_solo;?></p> <p><strong>Instructor: <?PHP echo $instructor+$initial_instructor;?> &nbsp;&nbsp;Night: <?PHP echo $night+$initial_night;?> &nbsp;&nbsp;Instrument: <?PHP echo $instrument+$initial_instrument;?> &nbsp;&nbsp;Turbine: <?PHP echo $sum109+$A109+$sum139+$A139+$others_turbine;?>&nbsp;&nbsp; Multi_Engine: <?PHP echo $sum109+$A109+$sum139+$A139+$others_multiengine;?></strong></p>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div><?PHP
}
else if(!empty($res0))	
{
 ?>
 <h3><strong><center>logged Flights </center></strong></h3>

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Flight From</strong></h5></th> <th><h5><strong>Flight To</strong></h5></th> <th><h5><strong>Aircraft</strong></h5></th> <th><h5><strong>Weight</strong></h5></th> <th><h5><strong>Start Time</strong></h5></th> <th><h5><strong>Stop Time</strong></h5></th><th><h5><strong>Time</strong></h5></th><th><h5><strong>Landing Hours</strong></h5></th><th><h5><strong>Fuel Main</strong></h5></th> <th><h5><strong>Fuel aux</strong></h5></th><th><h5><strong>Pilot</strong></h5></th>
                                            <th><h5><strong>Co-Pilot</strong></h5></th>
                                            <th><h5><strong>Flight</strong></h5></th><th><h5><strong>Auth-Flight Time</strong></h5></th>
                                            
                                           <?PHP if(($_SESSION['deploy']!="pilot_ops")&&($_SESSION['deploy']!="technician_ops")){?><th><h5><strong>Edit</strong></h5></th><?php } ?>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;

foreach ($res0 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->flight_date;echo '</td>';
echo '<td>';echo $row->flight_from;echo '</td>';
echo '<td>';echo $row->flight_to;echo '</td>';
$call=$row->call_sign;
$que=mysqli_query($conn,"SELECT * from flights  where call_sign='$call' and status='yes' ");
if (mysqli_num_rows($que)==0) {
echo '<td>';echo $call=$row->call_sign;echo '</td>';	
}else{
 while ($ro = mysqli_fetch_array($que)){

	echo '<td bgcolor="#62CBF7">';?><p data-toggle="popover" title="PROBLEM REPORTED" data-trigger="hover"  data-content=	'<?PHP echo $ro['problem'];}?>'</p><?PHP echo $call=$row->call_sign; 
echo'</td>';}echo '<td>';echo $row->weight;echo '</td>';
echo '<td>';echo $row->start_time;echo '</td>';
echo '<td>';echo $row->stop_time;echo '</td>';
echo '<td>';echo $hobs=$row->engine_hobs;echo '</td>';
echo '<td>';echo $row->landing_hours;echo '</td>';
echo '<td>';echo $row->fuel_main;echo '</td>';
echo '<td>';echo $row->fuel_aux;echo '</td>';

$pilot=$row->pic_instr;
$pilote=$row->copilot_instr;
$query=mysqli_query($conn,"SELECT * from workers  where tel='$pilot' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';
echo '<td>';
if(($pilote=="solo")||(($pilote=="sim"))){
	
}else{
	

$query2=mysqli_query($conn,"SELECT * from workers  where tel='$pilote' ");
while ($row2 = mysqli_fetch_array($query2)){
echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }}echo '</td>';

echo '<td>';echo $row->flight_exercise;echo '</td>';
echo '<td>';echo $row->auth_flighttime;echo '</td>';
$sum=$sum+$hobs;
if(($_SESSION['deploy']!="pilot_ops")&&($_SESSION['deploy']!="technician_ops")){
	echo '<td>';
	?>
     <a href="<?php echo base_url() ?>index.php/welcome/edit_hours/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';}
echo '</tr>';
	 $index++;
}?><tr><td><strong>Total Time</td><td colspan="7"></td><td><?PHP echo $sum; ?></strong></td><td colspan="8"></td></tr>
<?PHP }
else{
echo '<center>';echo '<strong>';echo "NO DATA";echo '</center>';echo '</strong>';}
?>

   </tbody>
  </table>
  </div>
  

<br>
<br>
<br>
<div class="col-sm-12">
<div class="row form-inline" align="center"> 
<?PHP echo form_open('welcome/hours_pilot2'); 

$query=mysqli_query($conn,"SELECT * from workers  where department='pilot' or department='pilot_ops' ");
echo '<select name="pilot" class="form-control input-sm">';?>
 <option selected disabled>--select pilot--</option>
<?PHP while ($rown = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $rown["tel"];?>"> <?PHP echo $rown["firstname"]."  ".$rown["lastname"]; ?></option>
<?PHP } ?>
                
</select>

<?PHP
$from = array(
'type' => 'date',
'name' => 'from',
'required' => 'required',
'class' => 'form-control input-sm',

);
echo form_input($from);

$to = array(
'type' => 'date',
'name' => 'to',
'required' => 'required',
'class' => 'form-control input-sm',

);
echo form_input($to);
$query=mysqli_query($conn,"SELECT * from aircraft ");
?>

 <select name="call_sign" class="form-control input-sm">
<option>--Select a/c--</option><?PHP
while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select> 
        <?PHP
echo form_submit('submit','Check ','class="btn btn-info btn-sm"');
echo '</div>';?>
</div>
 <script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

</script>

