<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Print</title>
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<br><br>
<div id="print_content" style="overflow-y:scroll; height:400px;" align="center">
<style>
table {
    border-collapse: collapse;
}

table, th,tr, td {
    border: 1px solid black;
}</style>
<center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center>
<b><center><p id="demo"></p></center></b><br>
<?PHP $servername = "localhost";
$username = "root";
$password = "";
$dbname = "ak_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
if(!empty($res)){ ?><table  align="center" border="1">
 
    <thead><tr>
                                            <th><h5><strong>&nbsp;Index&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Date&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;A/C Type&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Call Sign&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Pilot&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Co-Pilot&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Flight nature&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Departure&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Arrival&nbsp;</strong></h5></th>
                                            <th><h5><strong>&nbsp;Duration&nbsp;</strong></h5></th>
                                            </tr></thead>
                                            <tbody>
                                            
 <?PHP
$index=1;
$sum=0;

foreach ($res as $row)
{

echo '<tr>';
echo '<td>';echo'&nbsp;';echo $index;echo'&nbsp;';echo '</td>';
echo '<td>';echo'&nbsp;';echo $row->flight_date;echo'&nbsp;';echo '</td>';
echo '<td>';echo'&nbsp;';echo $row->aircraft_type;echo'&nbsp;';echo '</td>';
echo '<td>';echo'&nbsp;';echo $row->call_sign;echo'&nbsp;';echo '</td>';
$copilot=$row->co_pilot;
$pilote=$row->pilot;
$query=mysqli_query($conn,"SELECT * from status_tb  where service_n='$pilote' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo'&nbsp;';echo $rown["rank"];echo "  ";echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo'&nbsp;';echo '</td>';
$query2=mysqli_query($conn,"SELECT * from status_tb  where service_n='$copilot' ");
echo '<td>';
while ($row2 = mysqli_fetch_array($query2)){
echo'&nbsp;';echo $row2["rank"];echo "  ";echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }echo'&nbsp;';echo '</td>';

echo '<td>';echo'&nbsp;';echo $row->flight_nature;echo'&nbsp;';echo '</td>';
echo '<td>';echo'&nbsp;';echo $row->departure;echo'&nbsp;';echo '</td>';
echo '<td>';echo'&nbsp;';echo $row->arrival;echo'&nbsp;';echo '</td>';
echo '<td>';echo'&nbsp;';echo $row->amount;echo'&nbsp;';echo '</td>';
echo '<td>';
	?>
     <?PHP echo '</td>';
//$amount=0;$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?>

<!--<tr><td><strong>Total</strong></td><td colspan="4"><center><?PHP echo $sum; ?></center></td></tr>-->
  
  </tbody></table>
<?PHP } $year=date("y");
	 $year1="20".$year;
     if(!empty($res2)){ ?>
    
<center><table border="1" >
 <thead><tr><th><h5><strong>&nbsp;Index</strong></h5></th><th><h5><strong>&nbsp;Names</strong></h5></th><?PHP if($_SESSION['term']=="term1"){$date1=$year1."-01-01";$date11=$year1."-01-31";$date2=$year1."-02-01";$date22=$year1."-02-28";$date3=$year1."-03-01";$date33=$year1."-03-31"; ?><th><h5><strong>&nbsp;JAN</strong></h5></th><th><h5><strong>&nbsp;FEB</strong></h5></th><th><h5><strong>&nbsp;MAR</strong></h5></th><?PHP }if($_SESSION['term']=="term2"){ $date1=$year1."-04-01";$date11=$year1."-04-30";$date2=$year1."-05-01";$date22=$year1."-05-31";$date3=$year1."-06-01";$date33=$year1."-06-30";?><th><h5><strong>&nbsp;APR</strong></h5></th><th><h5><strong>&nbsp;MAY</strong></h5></th><th><h5><strong>&nbsp;JUN</strong></h5></th><?PHP }if($_SESSION['term']=="term3"){ $date1=$year1."-07-01";$date11=$year1."-07-31";$date2=$year1."-08-01";$date22=$year1."-08-31";$date3=$year1."-09-01";$date33=$year1."-09-30"; ?><th><h5><strong>&nbsp;JUL</strong></h5></th><th><h5><strong>&nbsp;AUG</strong></h5></th><th><h5><strong>&nbsp;SEP</strong></h5></th><?PHP }if($_SESSION['term']=="term4"){ $date1=$year1."-10-01";$date11=$year1."-10-31";$date2=$year1."-11-01";$date22=$year1."-11-30";$date3=$year1."-12-01";$date33=$year1."-12-31";?><th><h5><strong>&nbsp;OCT</strong></h5></th><th><h5><strong>&nbsp;NOV</strong></h5></th><th><h5><strong>&nbsp;DEC</strong></h5></th><?PHP }if($_SESSION['term']=="annual"){ $date1=$year1."-01-01";$date11=$year1."-03-31";$date2=$year1."-04-01";$date22=$year1."-06-30";$date3=$year1."-07-01";$date33=$year1."-09-30";$date4=$year1."-10-01";$date44=$year1."-12-31"?><th><h5><strong>&nbsp;TERM1</strong></h5></th><th><h5><strong>&nbsp;TERM2</strong></h5></th><th><h5><strong>&nbsp;TERM3</strong></h5></th><th><h5><strong>&nbsp;TERM4</strong></h5></th><?PHP } ?><th><h5><strong>&nbsp;Total</strong></h5></th><th><h5><strong>&nbsp;GENERAL HOURS</strong></h5></th></tr></thead><tbody>
  
 <?PHP

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ak_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
$index=1;
$sum=0;

foreach ($res2 as $row){

$co_pilot=$row->co_pilot;
$query1=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot' and flight_date between '$date1' and '$date11'");
$query2=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot'  and flight_date between '$date2' and '$date22'");
$query3=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot' and flight_date between '$date3' and '$date33'");

if($_SESSION["term"]=="annual"){$query4=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot' and flight_date between '$date4' and '$date44'");}
$query5=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot'");
$query11=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date1' and '$date11'");
$query22=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date2' and '$date22'");
$query33=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date3' and '$date33'");

if($_SESSION["term"]=="annual"){$query44=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date4' and '$date44'");}
$query55=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot'");
$query6=mysqli_query($conn,"SELECT initial_r44,initial_mi17,initial_mi24,initial_sim17,initial_sim24 from status_tb where status_tb.service_n='$co_pilot' limit 1");

$names2=mysqli_query($conn,"SELECT rank,firstname,lastname,ranking FROM  status_tb  where status_tb.service_n='$co_pilot'");
echo '<tr>';
echo '<td>';echo $index;echo '</td>';
while ($rown = mysqli_fetch_array($names2)){
echo '<td>'; echo $rown["rank"];echo ' ';echo $first=$rown["firstname"];echo ' ';echo $names=$rown["lastname"];echo '</a>';echo '</td>';}
while ($row1 = mysqli_fetch_array($query1)){
$t1=$row1[0];}
while ($row11 = mysqli_fetch_array($query11)){
$t11=$row11[0];}
while ($row2 = mysqli_fetch_array($query2)){
$t2=$row2[0];}
while ($row22 = mysqli_fetch_array($query22)){
$t22=$row22[0];}
while ($row3 = mysqli_fetch_array($query3)){
$t3=$row3[0];}
while ($row33 = mysqli_fetch_array($query33)){
$t33=$row33[0];}
echo '<td>';echo $s1=$t1+$t11;echo '</td>';
echo '<td>';echo $s2=$t2+$t22;echo '</td>';
echo '<td>';echo $s3=$t3+$t33;echo '</td>';

	

if($_SESSION["term"]=="annual"){while ($row4 = mysqli_fetch_array($query4)){
$t4=$row4[0];}
while ($row44 = mysqli_fetch_array($query44)){
$t44=$row44[0];}
echo '<td>';echo $s4=$t4+$t44;echo '</td>';}
if($_SESSION["term"]=="annual"){
echo '<td>';echo $sum=$s1+$s2+$s3+$s4;echo '</td>';}
else{echo '<td>';echo $sum=$s1+$s2+$s3;echo '</td>';}
while ($row5 = mysqli_fetch_array($query5)){$s5=$row5[0];}
while ($row55 = mysqli_fetch_array($query55)){$s55=$row55[0];}
$th=$s5+$s55;while ($row6 = mysqli_fetch_array($query6)){
echo '<td>';echo $th+$row6["initial_r44"]+$row6["initial_mi17"]+$row6["initial_mi24"]+$row6["initial_sim24"]+$row6["initial_sim17"];echo '</td>';}echo '</tr>';


	 $index++;
}?> </tbody>
  </table></center>
    
  <?PHP }?>
</div>
<br>
<center><a href="<?php echo base_url() ?>index.php/welcome/hours" class="btn btn-info btn-lg">
          <span class="glyphicon glyphicon-home"></span>
        </a>&nbsp;&nbsp;<input type="submit" name="save2" value="Click here to Print" class="btn btn-info btn-md" style="width:30%" onclick="printDiv(print_content)" /></center>
</body>
<script type="text/javascript">
myFunction();
function myFunction() {
    var person = prompt("Enter the title of the list", "");
    
    if (person != null) {
        document.getElementById("demo").innerHTML = person;
    }
}
function printDiv(print_content){
 
 var printContents = document.getElementById("print_content").innerHTML;
 w=window.open();
 w.document.write(printContents);
 w.print();
 w.close();
}

 </script> 
</html>