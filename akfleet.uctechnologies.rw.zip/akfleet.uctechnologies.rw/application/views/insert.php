<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Insert Pilot Infor and Initials</title> 
    <style type="text/css">
.form-style-7{
    max-width:100%;
    margin:50px auto;
    background:#fff;
    border-radius:2px;
    padding:20px;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 h1{
    display: block;
    text-align: center;
    padding: 0;
    margin: 0px 0px 20px 0px;
    color: #5C5C5C;
    font-size:x-large;
}
.form-style-7 ul{
    list-style:none;
    padding:0;
    margin:0;   
}
.form-style-7 li{
    display: block;
    padding: 9px;
    border:1px solid #DDDDDD;
	    margin-right: 20px;

    margin-bottom: 30px;
    border-radius: 3px;
}
.form-style-7 li:last-child{
    border:none;
    margin-bottom: 0px;
    text-align: center;
}
.form-style-7 li > label{
    display: block;
    float: left;
    margin-top: -19px;
    background: #FFFFFF;
    height: 14px;
    padding: 2px 5px 2px 5px;
    color: #B9B9B9;
    font-size: 14px;
    overflow: hidden;
    font-family: Arial, Helvetica, sans-serif;
}
.form-style-7 input[type="text"],
.form-style-7 input[type="date"],
.form-style-7 input[type="datetime"],
.form-style-7 input[type="email"],
.form-style-7 input[type="number"],
.form-style-7 input[type="search"],
.form-style-7 input[type="time"],
.form-style-7 input[type="url"],
.form-style-7 input[type="password"],
.form-style-7 textarea,
.form-style-7 select 
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    display: block;
    outline: none;
    border: none;
    height: 25px;
    line-height: 25px;
    font-size: 16px;
    padding: 0;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 input[type="text"]:focus,
.form-style-7 input[type="date"]:focus,
.form-style-7 input[type="datetime"]:focus,
.form-style-7 input[type="email"]:focus,
.form-style-7 input[type="number"]:focus,
.form-style-7 input[type="search"]:focus,
.form-style-7 input[type="time"]:focus,
.form-style-7 input[type="url"]:focus,
.form-style-7 input[type="password"]:focus,
.form-style-7 textarea:focus,
.form-style-7 select:focus 
{
}
.form-style-7 li > span{
    background: #F3F3F3;
    display: block;
    padding: 3px;
    margin: 0 -9px -9px -9px;
    text-align: center;
    color: #C0C0C0;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
}
.form-style-7 textarea{
    resize:none;
}
.form-style-7 input[type="submit"],
.form-style-7 input[type="button"]{
    background: #2471FF;
    border: none;
    padding: 10px 20px 10px 20px;
    border-bottom: 3px solid #5994FF;
    border-radius: 3px;
    color: #D2E2FF;
}
.form-style-7 input[type="submit"]:hover,
.form-style-7 input[type="button"]:hover{
    background: #6B9FFF;
    color:#fff;
}
</style>   
    
<!--<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<!--<script type="text/javascript" href="</head>/?php echo base_url('js/jquery.min.js');?>"></script>

<script type="text/javascript" href="<?//php echo base_url('bootstrap/js/bootstrap.min.js');?>"></script>-->
<script>
function myFunction() {
    var x = document.getElementById("lname");
    x.value = x.value.toUpperCase();
}

function ucwords(str,force){
  str=force ? str.toLowerCase() : str;  
  return str.replace(/(\b)([a-zA-Z])/g,
           function(firstLetter){
              return   firstLetter.toUpperCase();
           });
}
function capitalize(fname, str) {
      // string with alteast one character
      if (str && str.length >= 1)
      {       
          var firstChar = str.charAt(0);
          var remainingStr = str.slice(1);
          str = firstChar.toUpperCase() + remainingStr;
      }
      document.getElementById(fname).value = str;
  }
  function capitalize2(add, str) {
      // string with alteast one character
      if (str && str.length >= 1)
      {       
          var firstChar = str.charAt(0);
          var remainingStr = str.slice(1);
          str = firstChar.toUpperCase() + remainingStr;
      }
      document.getElementById(add).value = str;
  }
</script>

</head>
<body>

 <div id="container">
  <div class="page-header">
  <center><img height="100px" src="images/base.JPG"></center><br/>
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="<?php echo base_url() ?>index.php/welcome/logout">Insert Crew Info</a></font></center></strong></h2>
    
  </div>
  <?PHP $form1 = array(
'class' => 'form-style-7'
);

echo form_open_multipart('Welcome/insert',$form1);
echo validation_errors();?>
 <table align="center"><tr>
  <td width="25%"><?PHP 


echo '<ul>';
echo '<li>';
echo form_label('Profile Pic');
$pic = array(
'type' => 'file',
'name' =>'userfile',

);
echo form_input($pic);
echo '<span>must be jpg|png|gif</span>';
echo '</li>';
echo '<li>';
echo form_label('Tel');
$t= array(
'type' => 'text',
'required' =>'required',
'name' => 'tel',
);

echo form_input($t);
echo '<span>Phone Number</span>';
echo '</li>';
echo '<li>';
echo form_label('License Number');
$lic= array(
'type' => 'text',
'name' => 'license_number',
);

echo form_input($lic);
echo '<span>License Number</span>';
echo '</li>';
echo '<li>';
echo form_label('Firstname');
$fname = array(
'type' => 'text',
'id' =>'fname',
'name' =>'firstname',
'onkeyup'=>'javascript:capitalize(this.id, this.value)'

);
echo form_input($fname);
echo '<span>1 st Letter in Caps</span>';
echo '</li>';
echo '<li>';
echo form_label('Latname');
$lname = array(

'type' => 'text',
'id' => 'lname',
'name' => 'lastname',
'required' => 'required',
'onkeyup'=>'myFunction()',
);
echo form_input($lname);
echo '<span>All letters in Caps</span>';
echo '</li>';
echo '<li>';
echo form_label('Department');
$crew = array(
'pilot' => 'pilot',
'pilot_ops' => 'pilot_ops',
);

echo form_dropdown('department',$crew,'');
echo '<span>Select</span>';
echo '</li>';

echo '<li>';
echo form_label('choose password');
$p= array(
'type' => 'password',
'name' => 'password',
'required' => 'required',

);
echo form_input($p);
echo '<span>it is used while login</span>';
echo '</li>';

echo '<li>';
echo form_label('Medical Expiration Date');
$me = array(
'type' => 'date',
'name' => 'medical',
);
echo form_input($me);
echo '<span>dd-mm-yyyy</span>';

echo '</li>';
echo '<li>';
echo form_label('Instructor License Expiring Date');
$instr = array(
'type' => 'date',
'name' => 'instructor',

);
echo form_input($instr);
echo '<span>Select Date </span>';
echo '</li>';

echo '<li>';
echo form_label('Recurrency Expiring Date');
$rec = array(
'type' => 'date',
'name' => 'recurence',
);
echo form_input($rec);
echo '<span>Select Date </span>';
echo '</li>';

echo '<li>';
echo form_label('Proficiency Expiring Date');
$pro = array(
'type' => 'date',
'name' => 'proficiency',
);
echo form_input($pro);
echo '<span>Select Date </span>';
echo '</li>';
echo '<li>';
echo form_label('License Expiring Date');
$lic = array(
'type' => 'date',
'name' => 'license',
);
echo form_input($lic);
echo '<span>CPL or ATPL Expiring Date </span>';
echo '</li>';
?> 

</ul></td>
<td width="25%"><?PHP echo '<ul>';




echo '<li>';
echo form_label('CRM Expiring Date');
$cr = array(
'type' => 'date',
'name' => 'crm',

);
echo form_input($cr);
echo '<span>select date</span>';
echo '</li>';

echo '<li>';
echo form_label('DGs Expiring Date');
$dg = array(
'type' => 'date',
'name' => 'dgs',

);
echo form_input($dg);
echo '<span>select date</span>';
echo '</li>';
echo '<li>';

echo form_label('AW109 Recurrency Expiring Date');
$sim0 = array(
'type' => 'date',
'name' => 'sim109',

);
echo form_input($sim0);
echo '<span>select date</span>';
echo '</li>';
echo '<li>';
echo form_label('AW139 Recurrency Expiring Date');
$sim1 = array(
'type' => 'date',
'name' => 'sim139',

);
echo form_input($sim1);
echo '<span>select date</span>';
echo '</li>';

?><strong><u><center>Initial Hours</center></u></strong><?PHP

echo '<li>';
echo form_label('Instructor');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'instructor_hour',
);

echo form_input($rn);
echo '<span>Instructor Total hours</span>';
echo '</li>';
echo '<li>';
echo form_label('Night');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'night',
);

echo form_input($rn);
echo '<span>Night Total hours</span>';
echo '</li>';

echo '<li>';
echo form_label('Instrument');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'instrument',
);

echo form_input($rn);
echo '<span>Instrument Total hours</span>';
echo '</li>';

echo '<li>';

echo form_label('Flight Hours');
$r= array(
'type' => 'number',
'step' => 'any',
'name' => 'R44',
);

echo form_input($r);
echo '<span>Total Flight experience hours</span>';
echo '</li>';
echo '<li>';
echo form_label('PIC Time');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'R44_solo',
);

echo form_input($rs);
echo '<span>PIC only</span>';
echo '</li>';
echo '<li>';
echo form_submit('submit','Insert','class="btn btn-info btn-block"');
echo '</li>';
?>

</ul></td>
<td width="25%"><?PHP /*echo '<ul>'; 
echo '<li>';

echo form_label('A109');
$r= array(
'type' => 'number',
'step' => 'any',
'name' => 'a109',
);

echo form_input($r);
echo '<span>Total A109 hours</span>';
echo '</li>';
echo '<li>';
echo form_label('PIC A109');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'a109_solo',
);

echo form_input($rs);
echo '<span>A109 hours ,PIC only</span>';
echo '</li>';

echo '<li>';
echo form_label(' SIM A109');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'SIM_109',
);

echo form_input($rn);
echo '<span>Only SIM A109 hours</span>';

echo '</li>';

echo '<li>';

echo form_label('A139');
$r= array(
'type' => 'number',
'step' => 'any',
'name' => 'a139',
);

echo form_input($r);
echo '<span>Total A139 hours</span>';
echo '</li>';
echo '<li>';
echo form_label('PIC A139');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'a139_solo',
);

echo form_input($rs);
echo '<span>A139 hours ,PIC only</span>';
echo '</li>';
echo '<li>';
echo form_label(' SIM A139');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'SIM_139',
);

echo form_input($rn);
echo '<span>Only SIM A139 hours</span>';

echo '</li>';

echo '<li>';

echo form_label('others');
$r= array(
'type' => 'number',
'step' => 'any',
'name' => 'others',
);

echo form_input($r);
echo '<span>Total hours on others</span>';
echo '</li>';
echo '<li>';
echo form_label('PIC others');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_solo',
);

echo form_input($rs);
echo '<span>PIC hours on other A/C </span>';
echo '</li>';
echo '<li>';
echo form_label(' SIM Others');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'SIM_others',
);

echo form_input($rn);
echo '<span>SIM hours on other A/C </span>';

echo '</li>';

echo '<li>';
echo form_label('A/C With Turbine Eng flown before');
$rs= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_turbine',
);

echo form_input($rs);
echo '<span>Total hours of Turbine A/C flown </span>';
echo '</li>';

echo '<li>';
echo form_label('A/C With multi engine flown before');
$rn= array(
'type' => 'number',
'step' => 'any',
'name' => 'others_multiengine',
);

echo form_input($rn);
echo '<span>Total hours of Multi engine A/C flown </span>';

echo '</li>'; */

?> </ul></td>

<?php  

echo form_close(); 
?>
</ul>
</div>
</td>
  </tr></table>

</html>