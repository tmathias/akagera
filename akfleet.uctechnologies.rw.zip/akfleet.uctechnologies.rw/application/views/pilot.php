<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Pilot Log</title> 
    <style type="text/css">
.input_container ul{
	   width::256px;
	   border:1px solid #eaeaea;
	   position:absolute;
	   z-index:9;
	   background:#f3f3f3;
	   list-style:none;
   }
   .input_container ul li:hover{
	   background:#337ab7;
   }
   #view_search{
	   display:none;
	   
	   }
	   
	    #view_search2{
	   display:none;
	   
	   }
	   
	    #view_cond{
	   display:none;
	   
	   }

</style>   
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<script src="//cdn.jsdelivr.net/webshim/1.14.5/polyfiller.js"></script>

<script>
    webshims.setOptions('forms-ext', {types: 'date'});
webshims.polyfill('forms forms-ext');
</script>




</head>
<body>
<?php $d1=date("y-m-d");
    $d="20".$d1;
	
	if(!empty($data)){
	foreach ($data as $row)
{
$_id=$row->_id;
$firstname=$row->firstname;
$lastname=$row->lastname;	
$department=$row->department;
$tel=$row->tel;	
$medical=$row->medical;
$instructor=$row->instructor;	
$proficiency=$row->proficiency;
$crm=$row->crm;	
$dgs=$row->dgs;	
$sim109=$row->sim109;	
$picture=$row->picture;	
$license_number=$row->license_number;
$proficiency=$row->proficiency;	
$sim139=$row->sim139;	
$recurency=$row->recurency;	
$license=$row->license;	

}

	
	$date1=date_create($medical);
	$date2=date_create($d);
	$diff=date_diff($date2,$date1);
	$diff2=$diff->format("%R%a");
	
	$date1x=date_create($crm);
	$diffx=date_diff($date2,$date1x);
	$diff2x=$diffx->format("%R%a");
	
	$date1y=date_create($dgs);
	$diffy=date_diff($date2,$date1y);
	$diff2y=$diffy->format("%R%a");
	
	$date1a=date_create($sim109);
	$diffa=date_diff($date2,$date1a);
	$diff2a=$diffa->format("%R%a");
	
	$date1z=date_create($sim139);
	$diffz=date_diff($date2,$date1z);
	$diff2z=$diffz->format("%R%a");
	
	$dater=date_create($recurency);
	$diffr=date_diff($date2,$dater);
	$diff2r=$diffr->format("%R%a");
	
	$datei=date_create($instructor);
	$diffi=date_diff($date2,$datei);
	$diff2i=$diffi->format("%R%a");
	
	$datep=date_create($proficiency);
	$diffp=date_diff($date2,$datep);
	$diff2p=$diffp->format("%R%a");
	
	$datel=date_create($license);
	$diffl=date_diff($date2,$datel);
	$diff2l=$diffl->format("%R%a");if(($date1<=$date2)or($date1x<=$date2)or($date1y<=$date2)or($date1a<=$date2)or($date1z<=$date2)or($dater<=$date2)or($datei<=$date2)or($datep<=$date2)or($datel<=$date2)or(($diff2<=60)&&($diff2>0))or(($diff2x<=60)&&($diff2x>0))or(($diff2y<=60)&&($diff2y>0))or(($diff2z<=60)&&($diff2z>0))or(($diff2a<=60)&&($diff2a>0))or(($diff2r<=60)&&($diff2r>0))or(($diff2i<=60)&&($diff2i>0))or(($diff2p<=60)&&($diff2p>0))){ ?>
<div class="modal fade" id="myModal2" role="dialog">
    <div class="modal-dialog">       
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><center><Strong>You have expired certificates or about to expire</Strong></center></h4>
        </div>
        <div class="modal-body">

    
    <center><table class="table table-condensed table-hover">
      <tr><td>Medical Expiration Date</td>
	  <?PHP if(($date1<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2<=60)&&($diff2>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $medical; echo '</td>';?>

<td>CRM Expiration Date</td>
 <?PHP if(($date1x<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2x<=60)&&($diff2x>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2x>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $crm; echo '</td>';

?></tr><tr><td>DGs Expiration Date</td> <?PHP 
if(($date1y<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2y<=60)&&($diff2y>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2y>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $dgs; echo '</td>';

?><td>109 recurrency Expiration Date</td> <?PHP
if(($date1a<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2a<=60)&&($diff2a>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2a>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $sim109; echo '</td>';

?></tr><tr><td>139 Recurrency Expiration Date</td> <?PHP 
if(($date1z<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2z<=60)&&($diff2z>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2z>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $sim139; echo '</td>';

?><td>License Expiration Date</td> <?PHP
if(($datel<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2l<=60)&&($diff2l>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2l>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $license; echo '</td>';

?></tr><tr><td>Medical Expiration Date</td> <?PHP
if(($date1<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2<=60)&&($diff2>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $medical; echo '</td>';	

?><td>Recurency Expiration Date</td> <?PHP
if(($dater<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2r<=60)&&($diff2r>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2r>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $recurency; echo '</td>';

?></tr><tr><td>Instructor Expiration Date</td> <?PHP 
if(($datei<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2i<=60)&&($diff2i>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2i>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $instructor; echo '</td>';

?><td>Proficiency Expiration Date</td> <?PHP 
if(($datep<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2p<=60)&&($diff2p>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2p>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $proficiency; echo '</td>';echo '</tr>';	
?></table></center>
           
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

<?PHP }}
require(APPPATH.'include/link_database.php');

 ?>

 <div id="container">
  
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center>
  
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="#" target="new">Log Flight Hours</a></font></center></strong></h2>
<?PHP $tel=$_SESSION['tel']?>
  <ul class="nav nav-tabs">
    <?PHP if($_SESSION['deploy']=="pilot_ops"){?><li class="active"><a href="<?PHP echo base_url() ?>index.php/welcome/home">Operation Overview</a></li><?PHP }
    else {?><li class="active"><a href="#">Home</a></li><?php }?>
   <li><a href="<?PHP echo base_url() ?>index.php/welcome/ci_profile/<?php echo $tel;?>">My profile</a></li>
    <li><a href="<?PHP echo base_url() ?>index.php/welcome/logout">Logout</a></li>
  </ul>   
 
<div class="row form-inline" align="center"> 

<?PHP
echo form_open('Welcome/insert_hours');
echo validation_errors();
$today=date("y-m-d");
$flight = array(
'type' => 'date',
'name' => 'flight_date',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($flight);

$from = array(
'type' => 'text',
'name' => 'from',
'placeholder' => 'flight from',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($from);

$to = array(
'type' => 'text',
'name' => 'to',
'required' => 'required',
'placeholder' => 'flight to',
'class' => 'form-control input-sm',
);
echo form_input($to);

$query=mysqli_query($conn,"SELECT * from morning_check where approved='yes' and check_date='$today' ");
?>
 <select name="call_sign" class="form-control input-sm">
<?PHP
while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select>        
<?PHP

$weight = array(
'type' => 'number',
'name' => 'weight',
'step' => 'any',
'placeholder' => 'weight',
'required' => 'required',
'class' => 'form-control input-sm',
);
echo form_input($weight);
echo form_label("Start Time");
$dep = array(
'type' => 'time',
'name' => 'start_time',
'required' => 'required',
'placeholder' => 'start_time Time',

'class' => 'form-control input-sm',);
echo form_input($dep);


echo form_label("Stop Time");
$arr = array(
'type' => 'time',
'name' => 'stop_time',
'required' => 'required',
'class' => 'form-control input-sm',);
echo form_input($arr);

$landing = array(
'type' => 'number',
'step' => 'any',
'placeholder' => 'landing hours',
'name' => 'landing_hours',
'required' => 'required',
'class' => 'form-control input-sm',);
echo form_input($landing);

$main = array(
'type' => 'text',
'placeholder' => 'main tank',
'name' => 'fuel_main',
'class' => 'form-control input-sm',);
echo form_input($main);

$aux = array(
'type' => 'text',
'name' => 'fuel_aux',
'placeholder' => 'aux tank',
'class' => 'form-control input-sm',);
echo form_input($aux);

$type = array(
'PIC/INSTR' => 'PIC/INSTR',
'copilot/student' => 'copilot/student',
'solo' => 'solo');
echo form_dropdown('type',$type,'','class="form-control input-sm"');

$query=mysqli_query($conn,"SELECT * from workers  where department='pilot' or department='pilot_ops' or department='Student'");
?>
 <select name="pilot" class="form-control input-sm">
 <?PHP
 while ($row = mysqli_fetch_array($query)){?>
	                 <option value="<?PHP echo $row["tel"]; ?>"><?PHP echo $row["firstname"];echo "  ";echo $row["lastname"]; ?></option>

<?PHP } ?>
        <option>Trainee</option>         
        </select>
        
        <?PHP


$exercise = array(
'charter' => 'charter',
'photography' => 'photography',
'medevac' => 'medevac',
'casevac' => 'casevac',
'instrument' => 'instrument',
'night' => 'night',
'instructor' => 'instructor',
'test_flight' => 'test_flight',
'search_rescue' => 'search_rescue',
'aerial_work' => 'aerial_work',
'recurrence' => 'recurrence',
'positioning' => 'positioning',
'others' => 'others',

);
echo form_dropdown('flight_nature',$exercise,'','class="form-control input-sm"');

$auth = array(
'type' => 'text',
'placeholder' =>'authorised flight time',
'name' => 'auth_flighttime',
'class' => 'form-control input-sm',);
echo form_input($auth);

$pro = array(
'type' => 'text',
'placeholder' =>'report problem encountered',
'name' => 'problem',
'class' => 'form-control input-sm',);
echo form_input($pro);

echo form_submit('submit','Insert','class="btn btn-info"');

echo form_close();?>
<br>

<div class="col-sm-12" align="center" style="overflow-y:scroll; height:350px;" id="print_content">
<?PHP 

$re=$res1['initial'];foreach ($re as $row){$last=$row->lastname;$first=$row->firstname;
$initial_instructor=$row->instructor;
$initial_night=$row->night;
$initial_instrument=$row->instrument;
$R44=$row->R44;
$R44_solo=$row->R44_solo;
$A109=$row->A109;
$A109_solo=$row->A109_solo;
$SIM_109=$row->SIM_109;
$A139=$row->A139;
$A139_solo=$row->A139_solo;
$SIM_139=$row->SIM_139;
$others=$row->others;
$others_solo=$row->others_solo;
$others_SIM=$row->others_SIM;
$others_turbine=$row->others_turbine;
$others_multiengine=$row->others_multiengine;} 

foreach ($res1['instructor'] as $row){$instructor=$row->instructor;}foreach ($res1['instrument'] as $row){$instrument=$row->instrument;}foreach ($res1['night'] as $row){$night=$row->night;}foreach ($res1['R44'] as $row){$sum44=$row->sum44;}foreach ($res1['A109'] as $row){$sum109=$row->sum109;}foreach ($res1['A139'] as $row){$sum139=$row->sum139;}foreach ($res1['solo_44'] as $row){$solo44=$row->solo44;}foreach ($res1['solo_109'] as $row){$solo109=$row->solo109;}foreach ($res1['solo_139'] as $row){$solo139=$row->solo139;}foreach ($res1['sim_109'] as $row){$sim109=$row->sim_109;}foreach($res1['sim_139'] as $row){$sim139=$row->sim_139;}

$hours=$R44+$A109+$A139+$others+$sum44+$sum109+$sum139;?>

<strong><u><a data-toggle="modal" data-target="#myModal"><?PHP echo "  ";echo $last; echo "  's Session";echo '<br>';
echo "Current Hours  "; echo $hours;echo '</strong></u><br></a>';?>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">  
         
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Log Book Summary</h4>
        </div>
        <div class="modal-body">

<p><strong>R44 : <?PHP echo $sum44+$R44;?></strong>&nbsp;&nbsp;PIC: <?PHP echo $solo44+$R44_solo;?></p>

<p><strong>A109 : <?PHP echo $sum109+$A109;?></strong>&nbsp;&nbsp;Sim: <?PHP echo $sim109+$SIM_109;?> &nbsp;&nbsp;PIC: <?PHP echo $solo109+$A109_solo;?></p> 
           
<p><strong>A139 : <?PHP echo $sum139+$A139;?></strong>&nbsp;&nbsp;Sim: <?PHP  echo $sim139+$SIM_139;?> &nbsp;&nbsp; PIC: <?PHP echo $solo139+$A139_solo;?></p>
            
<p><strong>Others : <?PHP echo $others;?></strong>&nbsp;&nbsp;Sim: <?PHP echo $others_SIM;?>&nbsp;&nbsp; PIC: <?PHP echo $others_solo;?></p>
            
<p><strong>Total : <?PHP echo $sum44+$R44+$sum109+$A109+$sum139+$A139+$others;?></strong>&nbsp;&nbsp;Sim: <?PHP echo $sim139+$SIM_139+$sim109+$SIM_109+$others_SIM;?> &nbsp;&nbsp;PIC: <?PHP echo $solo44+$R44_solo+$solo109+$A109_solo+$solo139+$A139_solo+$others_solo;?></p> <p><strong>Instructor: <?PHP echo $instructor+$initial_instructor;?> &nbsp;&nbsp;Night: <?PHP echo $night+$initial_night;?> &nbsp;&nbsp;Instrument: <?PHP echo $instrument+$initial_instrument;?> &nbsp;&nbsp;Turbine: <?PHP echo $sum109+$A109+$sum139+$A139+$others_turbine;?>&nbsp;&nbsp; Multi_Engine: <?PHP echo $sum109+$A109+$sum139+$A139+$others_multiengine;?></strong></p>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>
<?PHP
if(!empty($res2)){
	 
	 ?>
<h3><strong><center><?PHP echo "From: "; echo $_SESSION['from'];echo "  To:  ";echo $_SESSION['to'];echo " in:  ";echo $_SESSION['call_sign']; ?></center></strong></h3>

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Flight From</strong></h5></th> <th><h5><strong>Flight To</strong></h5></th> <th><h5><strong>Aircraft</strong></h5></th> <th><h5><strong>Weight</strong></h5></th> <th><h5><strong>Start Time</strong></h5></th> <th><h5><strong>Stop Time</strong></h5></th><th><h5><strong>Time</strong></h5></th><th><h5><strong>Landing hours</strong></h5></th><th><h5><strong>Fuel Main</strong></h5></th> <th><h5><strong>Fuel aux</strong></h5></th><th><h5><strong>Pilot</strong></h5></th>
                                            <th><h5><strong>Co-Pilot</strong></h5></th>
                                            <th><h5><strong>Flight</strong></h5></th><th><h5><strong>Auth-Flight Time</strong></h5></th>
                                                                                        </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;

foreach ($res2 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->flight_date;echo '</td>';
echo '<td>';echo $row->flight_from;echo '</td>';
echo '<td>';echo $row->flight_to;echo '</td>';
$call=$row->call_sign;
$que=mysqli_query($conn,"SELECT * from flights  where call_sign='$call' and status='yes' ");
if (mysqli_num_rows($que)==0) {
echo '<td>';echo $call=$row->call_sign;echo '</td>';	
}else{
 while ($ro = mysqli_fetch_array($que)){

	echo '<td bgcolor="#62CBF7">';?><p data-toggle="popover" title="PROBLEM REPORTED" data-trigger="hover"  data-content=	'<?PHP echo $ro['problem'];?>'</p><?PHP echo $ro['call_sign']; }
echo'</td>';}echo '<td>';echo $row->weight;echo '</td>';
echo '<td>';echo $row->start_time;echo '</td>';
echo '<td>';echo $row->stop_time;echo '</td>';
echo '<td>';echo $hobs=$row->engine_hobs;echo '</td>';
echo '<td>';echo $row->landing_hours;echo '</td>';
echo '<td>';echo $row->fuel_main;echo '</td>';
echo '<td>';echo $row->fuel_aux;echo '</td>';

$pilot=$row->pic_instr;
$pilote=$row->copilot_instr;
$query=mysqli_query($conn,"SELECT * from workers  where tel='$pilot' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';
echo '<td>';
if(($pilote="solo")||(($pilote=="sim"))){
	
echo $pilote;
}else{
$query2=mysqli_query($conn,"SELECT * from workers  where tel='$pilote' ");
while ($row2 = mysqli_fetch_array($query2)){
echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }}echo '</td>';

echo '<td>';echo $row->flight_exercise;echo '</td>';
echo '<td>';echo $row->auth_flighttime;echo '</td>';
$sum=$sum+$hobs;

echo '</tr>';
	 $index++;
}
?>
<tr><td><strong>Total Time</td><td colspan="7"></td><td><?PHP echo $sum; ?></strong></td><td colspan="7"></td></tr></tbody>
  </table>

<?PHP
 }

else if(!empty($res0))	
{
 ?>
 <h3><strong><center>logged Flights Today</center></strong></h3>

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Flight From</strong></h5></th> <th><h5><strong>Flight To</strong></h5></th> <th><h5><strong>Aircraft</strong></h5></th> <th><h5><strong>Weight</strong></h5></th> <th><h5><strong>Start Time</strong></h5></th> <th><h5><strong>Stop Time</strong></h5></th><th><h5><strong>Time</strong></h5></th><th><h5><strong>Landing Hours</strong></h5></th><th><h5><strong>Fuel Main</strong></h5></th> <th><h5><strong>Fuel aux</strong></h5></th><th><h5><strong>Pilot</strong></h5></th>
                                            <th><h5><strong>Co-Pilot</strong></h5></th>
                                            <th><h5><strong>Flight</strong></h5></th><th><h5><strong>Auth-Flight Time</strong></h5></th>
                                            
                                            <th><h5><strong>Edit</strong></h5></th>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;

foreach ($res0 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->flight_date;echo '</td>';
echo '<td>';echo $row->flight_from;echo '</td>';
echo '<td>';echo $row->flight_to;echo '</td>';
$call=$row->call_sign;
$que=mysqli_query($conn,"SELECT * from flights  where call_sign='$call' and status='yes' ");
if (mysqli_num_rows($que)==0) {
echo '<td>';echo $call=$row->call_sign;echo '</td>';	
}else{
 while ($ro = mysqli_fetch_array($que)){

echo '<td bgcolor="#62CBF7">';?><p data-toggle="popover" title="PROBLEM REPORTED" data-trigger="hover"  data-content=	'<?PHP echo $ro['problem'];}?>'</p><?PHP echo $call=$row->call_sign; 
echo'</td>';}
echo '<td>';echo $row->weight;echo '</td>';
echo '<td>';echo $row->start_time;echo '</td>';
echo '<td>';echo $row->stop_time;echo '</td>';
echo '<td>';echo $hobs=$row->engine_hobs;echo '</td>';
echo '<td>';echo $row->landing_hours;echo '</td>';
echo '<td>';echo $row->fuel_main;echo '</td>';
echo '<td>';echo $row->fuel_aux;echo '</td>';

$pilot=$row->pic_instr;
$pilote=$row->copilot_instr;
$query=mysqli_query($conn,"SELECT * from workers  where tel='$pilot' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';
echo '<td>';
if(($pilote=="solo")||(($pilote=="sim"))){
	
echo $pilote;
}else{
$query2=mysqli_query($conn,"SELECT * from workers  where tel='$pilote' ");
while ($row2 = mysqli_fetch_array($query2)){
echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }}echo '</td>';
echo '<td>';echo $row->flight_exercise;echo '</td>';//WHEN NEW AIRCRAFT IS USED,LOG SUMMARY PR
echo '<td>';echo $row->auth_flighttime;echo '</td>';
$sum=$sum+$hobs;
echo '<td>';
	?>
     <a href="<?php echo base_url() ?>index.php/welcome/edit_hours/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a> <?PHP echo '</td>';
//$amount=0;$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?><tr><td><strong>Total Time</td><td colspan="7"></td><td><?PHP echo $sum; ?></strong></td><td colspan="8"></td></tr>

   </tbody>
  </table><?PHP }
else{
echo '<center>';echo '<strong>';echo "NO DATA";echo '</center>';echo '</strong>';}
?>

  </div>
  
<br>
<br>
<br>
<div class="col-sm-12">
<div class="row form-inline" align="center"> 
<?PHP echo form_open('welcome/hours_pilot'); 

$from = array(
'type' => 'date',
'name' => 'from',
'required' => 'required',
'class' => 'form-control input-sm',

);
echo form_input($from);

$to = array(
'type' => 'date',
'name' => 'to',
'required' => 'required',
'class' => 'form-control input-sm',

);
echo form_input($to);
$query=mysqli_query($conn,"SELECT * from aircraft ");
?>

 <select name="call_sign" class="form-control input-sm">
<option>--Select a/c--</option><?PHP
while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["call_sign"]; ?>"><?PHP echo $row["call_sign"]; ?></option>
<?PHP } ?>
                
        </select> 
        <?PHP
echo form_submit('submit','Check ','class="btn btn-info btn-sm"');
echo '</div>';?>
</div>
<script type="text/javascript">
myFunction();
function myFunction() {
    $("#myModal2").modal();
}
</script> 
 <script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

</script>

