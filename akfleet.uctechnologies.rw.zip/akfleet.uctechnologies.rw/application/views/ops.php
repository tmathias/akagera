<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Ops</title>    
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">

function printDiv(print_content){
 
 var printContents = document.getElementById("print_content").innerHTML;
 w=window.open();
 w.document.write(printContents);
 w.print();
 w.close();
}

 </script>
<style>
ul.nav li a, ul.nav li a:visited {
    color: #ffffff !important;
}

ul.nav li a:hover, ul.nav li a:active {
    color: #00ff00 !important;
}

ul.nav li.active a {
    color: #0000ff !important;
	background:inherit;
}
</style>

</head>
<body>
 <div id="container">
 
 <center><img height="100px" border="5px" src="<?php echo base_url('images/base.JPG');?>">
 <h2><strong><font face="comic sans MT" color="#06748B"   size="+6">Crew Currency Status</font></center></strong></h2>

  
<div class="col-sm-12">

<ul class="nav nav-tabs"> <?PHP if($_SESSION['deploy']=="pilot_ops"){?><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/home_ops" class="btn btn-danger btn-lg">Home</a></li><?php }else if($_SESSION['deploy']=="technician_ops"){?><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/home_technician" class="btn btn-danger btn-lg">Home</a></li><?php }?><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/pilots" class="btn btn-warning btn-lg">Flights</a></li><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/technicians" class="btn btn-success btn-lg">A/C Checks</a></li><li><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/logout" class="btn btn-info btn-lg">Logout</a></li></ul></div>
<br></br></br>
<!---<div class="col-sm-2"></div>
 <div class="col-sm-8" align="center" style="overflow-y:scroll; height:350px;" id="print_content">

 <table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Status</strong></h5></th>
                                            <th><h5><strong>Engine Time</strong></h5></th>
                                             <th><h5><strong>Aircraft Time</strong></h5></th>
                                            <th><h5><strong>Maintenance Hobs</strong></h5></th> 
                                            <th><h5><strong>Maintenance Date</strong></h5></th> 
                                            
                                                                                        </tr>
                                            </thead>
                                            <tbody>
 <?PHP 
/*
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ak_db";

$today=date("y-m-d");

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

 $index=1;
 foreach ($res as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
$call=$row->call_sign;
$que=mysqli_query($conn,"SELECT * from flights  where call_sign='$call' and status='yes' ");
if (mysqli_num_rows($que)==0) {
echo '<td>';echo $call=$row->call_sign;echo '</td>';	
}else{
 while ($ro = mysqli_fetch_array($que)){

	echo '<td bgcolor="#62CBF7">';?><p data-toggle="popover" title="PROBLEM REPORTED" data-trigger="hover"  data-content=	'<?PHP echo $ro['problem'];}?>'</p><?PHP echo $call=$row->call_sign; 
echo'</td>';}

$quer=mysqli_query($conn,"SELECT * from morning_check  where call_sign='$call' and check_date='$today' ");
if (mysqli_num_rows($quer)==0) {
echo '<td class="btn btn-danger btn-lg">';echo "Not cheked this morning"; echo '</td>';	
}else{
while ($ro = mysqli_fetch_array($quer)){
$status=$ro['approved'];
if($status=="no"){echo '<td class="btn btn-danger btn-lg">';}
else if ($status=="yes") echo '<td class="btn btn-success btn-lg">';
echo $ro['remarks'];echo '</td>'; }


}

$query2=mysqli_query($conn,"SELECT SUM(engine_hobs) from flights  where call_sign='$call' ");
while ($row2 = mysqli_fetch_array($query2)){
$hours2=$row2[0]; }

$query3=mysqli_query($conn,"SELECT * from aircraft  where call_sign='$call' ");
while ($row3 = mysqli_fetch_array($query3)){
$hours3=$row3['engine_time']; 
$hours4=$row3['aircraft_time']; }

$engine_time=$hours2+$hours3;
echo '<td>';echo $engine_time;echo '</td>';

$query=mysqli_query($conn,"SELECT MAX(landing_hours) from flights  where call_sign='$call' ");

while ($rown = mysqli_fetch_array($query)){
	if(empty($rown[0])){$hours=$hours4;}else{
$hours=$rown[0]; }}

$athours=$row->athours;
$dif=$athours-$hours;
if($dif<=0)
	 echo '<td class="btn btn-danger btn-lg">';
if(($dif<=10)&&($dif>0))
	 echo '<td class="btn btn-warning btn-lg">';
if($dif>10)
echo '<td class="btn btn-success btn-lg">';
echo $hours;echo '</td>';
echo '<td>';echo $athours;echo '</td>';



$d1=date("y-m-d");
$d="20".$d1;
$ondate=$row->ondate;
   	$date1=date_create($ondate);
	$date2=date_create($d);
	$diff=date_diff($date2,$date1);
	$diff2=$diff->format("%R%a");
	
	if($diff2<=0)
	 echo '<td class="btn btn-danger btn-lg">';

    if(($diff2<=60)&&($diff2>0))
	 {
	 echo '<td class="btn btn-warning btn-lg">';
	 }
	if($diff2>60)
	 {
		echo '<td class="btn btn-success btn-lg">';
 
	 }
echo $ondate;echo '</td>';
$index++;
}*/?>
</tbody>
</table>
</div>
 <div class="col-sm-2">
 </div>
 <script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

</script>--->

 <div class="col-sm-12" align="center" style="overflow-y:scroll; height:350px;" id="print_content">

 <table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>INDEX</strong></h5></th>
                                            <th><h5><strong>NAMES</strong></h5></th>
                                            <th><h5><strong>EXP-CRM</strong></h5></th>
                                            <th><h5><strong>EXP-DGS</strong></h5></th>
                                            <th><h5><strong>EXP-SIM109</strong></h5></th> 
                                            <th><h5><strong>EXP-SIM139</strong></h5></th>
                                            <th><h5><strong>EXP-LICENSE</strong></h5></th>
											<th><h5><strong>EXP-MEDICAL</strong></h5></th>
                                            <th><h5><strong>EXP-INSTRUCTOR</strong></h5></th> 
                                            <th><h5><strong>EXP-PROFICIENCY</strong></h5></th> 
                                             
                                            
                                                                                        </tr>
                                            </thead>
                                            <tbody>
            <?PHP
$index=1;
foreach ($res as $row)
{
	$d1=date("y-m-d");
    $d="20".$d1;
	$date1=date_create($row->medical);
	$date2=date_create($d);
	$diff=date_diff($date2,$date1);
	$diff2=$diff->format("%R%a");
	
	$date1x=date_create($row->crm);
	$diffx=date_diff($date2,$date1x);
	$diff2x=$diffx->format("%R%a");
	
	$date1y=date_create($row->dgs);
	$diffy=date_diff($date2,$date1y);
	$diff2y=$diffy->format("%R%a");
	
	$date1a=date_create($row->sim109);
	$diffa=date_diff($date2,$date1a);
	$diff2a=$diffa->format("%R%a");
	
	$date1z=date_create($row->sim139);
	$diffz=date_diff($date2,$date1z);
	$diff2z=$diffz->format("%R%a");
	
	$dater=date_create($row->recurency);
	$diffr=date_diff($date2,$dater);
	$diff2r=$diffr->format("%R%a");
	
	$datei=date_create($row->instructor);
	$diffi=date_diff($date2,$datei);
	$diff2i=$diffi->format("%R%a");
	
	$datep=date_create($row->proficiency);
	$diffp=date_diff($date2,$datep);
	$diff2p=$diffp->format("%R%a");
	
	$datel=date_create($row->license);
	$diffl=date_diff($date2,$datel);
	$diff2l=$diffl->format("%R%a");
	
echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';?><p data-toggle="popover" title="Crucial Info" data-trigger="hover"  data-content='<?PHP echo $row->department;echo "  ";echo "license number: ";echo $row->license_number;echo "    ";echo "Tel: ";echo $row->tel;?>' </p><a href="<?php echo base_url() ?>index.php/welcome/ci_profile/<?php echo $_id=$row->tel ;?>"><?PHP echo ' ';echo $row->firstname;echo ' ';echo $names=$row->lastname;echo '</a>';
echo '</td>';

if(($date1x<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2x<=60)&&($diff2x>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2x>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->crm; echo '</td>';

if(($date1y<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2y<=60)&&($diff2y>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2y>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->dgs; echo '</td>';

if(($date1a<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2a<=60)&&($diff2a>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2a>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->sim109; echo '</td>';

if(($date1z<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2z<=60)&&($diff2z>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2z>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->sim139; echo '</td>';

if(($datel<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2l<=60)&&($diff2l>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2l>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->license; echo '</td>';

if(($date1<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2<=60)&&($diff2>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->medical; echo '</td>';	



if(($datei<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2i<=60)&&($diff2i>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2i>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->instructor; echo '</td>';

if(($datep<=$date2)){	echo '<td bgcolor="#F57D7F">';}else if(($diff2p<=60)&&($diff2p>0)){ 
echo '<td bgcolor="#FBDD86">';}else if($diff2p>60){echo '<td bgcolor="#4CFB91">';}
else{echo '<td bgcolor="#000000">';}echo $row->proficiency; echo '</td>';echo '</tr>';	

$index++;   
}
	?>                                
                                            </tbody>
                                            </table>
                                            <script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

</script>