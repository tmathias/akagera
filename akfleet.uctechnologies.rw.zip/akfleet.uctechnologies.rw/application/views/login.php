<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="refresh" content="600">
    <title>Index Ops</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">
function validateForm() {
    var x = document.forms["form1"]["user"].value;
    var y = document.forms["form1"]["pass"].value;
    if (x==null || x=="" || y==null || y=="") {
        alert("Username name and Password must be filled out");
        return false;
    }
}
</script>
    <style>
.btn-rmk {
    min-width: 300px;
    line-height: 50px;
	text-align:center
}
.main-text {
    position: absolute;
    top: 50px;
    width: 96.66666666666666%;
    color: #FFF;
}

.btn-min-block {
    min-width: 170px;
    line-height: 26px;
}

.btn-clear {
    color: #FFF;
    border-color: #FFF;
    border-width: 2px;
    margin-right: 15px;
}

.btn-clear:hover {
    color: #000;
    background-color: #6699CC;
}

.arrowalign {
    top: 50%;
}

.arrowalign:hover {
    vertical-align: middle;
}

.carousel-control {
    color: #fff;
    top: 50%;
    bottom: auto;
    padding-top: 0px;
    width: 30px;
    height: 30px;
    text-shadow: none;
    opacity: 0.9;
}
</style>
</head>
<body>
<div class="page-header">
 <center><img height="120px" border="5px" src="<?php echo base_url('images/base.JPG');?>">
 <h2><strong><font face="comic sans MT" color="#06748B">Aircraft Status</font></center></strong></h2>
 </div>
<nav class="navbar navbar-default">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Akagera Aviation</a>
    </div>
    <!---<ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>
    </ul>--->
    
      <?PHP echo form_open('welcome/login','class="navbar-form navbar-left"'); ?>
                            <div class="form-group">
                                <label for="text" >Login ID</label>
                                <input type="text" class="form-control" id="username" name="user" placeholder="Telephone" required="required"/>
                            </div>
                            <div class="form-group">
                                <label for="pass">Password </label>
                                <input type="password" name="pass" class="form-control" id="pass" placeholder="Password" required="required"/></div>
                                <ul class="nav navbar-nav navbar-right">
            <li><button type="submit"  class="btn btn-inverse btn-md"> <span class="glyphicon glyphicon-log-in"></span> Login</button></li>                          
<!-- <li><a href="<?php echo base_url() ?>index.php/welcome/insert_f"><span class="glyphicon glyphicon-user"></span> Crew Registration</a></li>-->
      
      <li><strong><u><a data-toggle="modal" data-target="#myModal"><span class="glyphicon glyphicon-user"></span> New User</a></li>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">       
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"><center>User Type</center></h4>
        </div>
        <div class="modal-body">
        

<center><a href="<?php echo base_url() ?>index.php/welcome/insert_f"><span class="glyphicon glyphicon-user"></span> Pilot</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="<?php echo base_url() ?>index.php/welcome/insert_others"><span class="glyphicon glyphicon-user"></span>others</a></center>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>

    </ul>
    </form>
  </div>
</nav>

<div class="container">
    <div class="row">
        <div class="col-sm-2"></div>
 <div class="col-sm-8" align="center" style="overflow-y:scroll; height:350px; width:100%;" id="print_content">

 <table class="table table-condensed table-hover table-bordered table-inverted" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong><center>DI Status</center></strong></h5></th>
                                            <th><h5><strong>Engine Time</strong></h5></th>
                                             <th><h5><strong>Aircraft Time</strong></h5></th>
                                            <th><h5><strong>Maintenance Hobs</strong></h5></th> 
                                            <th><h5><strong>Maintenance Date</strong></h5></th> 
											<th><h5><strong>Remaining Hours</strong></h5></th>
                                            
                                                                                        </tr>
                                            </thead>
                                            <tbody>
<?PHP 


$today=date("y-m-d");

// Create connection
require(APPPATH.'include/link_database.php');

 $index=1;
 foreach ($res as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
$call=$row->call_sign;
$que=mysqli_query($conn,"SELECT * from flights  where call_sign='$call' and status='yes' ");
if (mysqli_num_rows($que)==0) {
echo '<td>';echo $call=$row->call_sign;echo '</td>';	
}else{
 while ($ro = mysqli_fetch_array($que)){

	echo '<td bgcolor="#62CBF7">';?><p data-toggle="popover" title="PROBLEM REPORTED" data-trigger="hover"  data-content=	'<?PHP echo $ro['problem'];}?>'</p><?PHP echo $call=$row->call_sign; 
echo'</td>';}

$quer=mysqli_query($conn,"SELECT * from morning_check  where call_sign='$call' and check_date='$today' ");
if (mysqli_num_rows($quer)==0) {
echo '<td class="btn btn-danger btn-lg btn-rmk">';echo "Not checked this morning"; echo '</td>';	
}else{
while ($ro = mysqli_fetch_array($quer)){
$status=$ro['approved'];
if($status=="no"){echo '<td class="btn btn-danger btn-lg btn-rmk">';}
else if ($status=="yes") echo '<td class="btn btn-success btn-lg btn-rmk">';
echo $ro['remarks'];echo '</td>'; }


}


$query3=mysqli_query($conn,"SELECT * from aircraft  where call_sign='$call' ");
while ($row3 = mysqli_fetch_array($query3)){
$hours3=$row3['engine_time']; 
$hours4=$row3['aircraft_time']; }

echo '<td>';echo $hours3;echo '</td>';

$query=mysqli_query($conn,"SELECT aircraft_time from aircraft  where call_sign='$call'");

while ($rown = mysqli_fetch_array($query)){
	if(empty($rown[0])){$hours=$hours4;}else{
$hours=$rown[0]; }}

$athours=$row->athours;
$dif=$athours-$hours;
if($dif<=0)
	 echo '<td class="btn btn-danger btn-lg">';
if(($dif<=10)&&($dif>0))
	 echo '<td class="btn btn-warning btn-lg">';
if($dif>10)
echo '<td class="btn btn-success btn-lg">';
echo $hours4;echo '</td>';
echo '<td>';echo $athours;echo '</td>';



$d1=date("y-m-d");
$d="20".$d1;
$ondate=$row->ondate;
   	$date1=date_create($ondate);
	$date2=date_create($d);
	$diff=date_diff($date2,$date1);
	$diff2=$diff->format("%R%a");
	
	if($diff2<=0)
	 echo '<td class="btn btn-danger btn-lg">';

    if(($diff2<=60)&&($diff2>0))
	 {
	 echo '<td class="btn btn-warning btn-lg">';
	 }
	if($diff2>60)
	 {
		echo '<td class="btn btn-success btn-lg">';
 
	 }
echo $ondate;echo '</td>';

 /**hour difference*/
 
$query=mysqli_query($conn,"SELECT aircraft_time from aircraft  where call_sign='$call' ");

while ($rown = mysqli_fetch_array($query)){
	if(empty($rown['aircraft_time'])){$hours=$hours4;}else{
$hours=$rown['aircraft_time']; }}

$athours=$row->athours;
$dif=$athours-$hours;


echo'<td>';echo $dif;'</td>';

$index++;
}?>
</tbody>
</table>
</div>
 <div class="col-sm-2">
 </div>
 <script>
$(document).ready(function(){
    $('[data-toggle="popover"]').popover();
});

</script>

        <div class="col-md-2">
        </div>
  
   
                        </div>
                    </div>
    
        </div>
    </div>
</div>

<style>
.main-text {
    position: absolute;
    top: 50px;
    width: 96.66666666666666%;
    color: #FFF;
}

.btn-min-block {
    min-width: 170px;
    line-height: 26px;
}

.btn-clear {
    color: #FFF;
    border-color: #FFF;
    border-width: 2px;
    margin-right: 15px;
}

.btn-clear:hover {
    color: #000;
    background-color: #6699CC;
}

.arrowalign {
    top: 50%;
}

.arrowalign:hover {
    vertical-align: middle;
}

.carousel-control {
    color: #fff;
    top: 50%;
    bottom: auto;
    padding-top: 0px;
    width: 30px;
    height: 30px;
    text-shadow: none;
    opacity: 0.9;
}
</style>

<!-- Static Headline - END -->

</div>

</body>
</html>