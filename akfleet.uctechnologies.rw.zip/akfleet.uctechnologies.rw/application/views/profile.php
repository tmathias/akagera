<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Profile</title> 
    <style type="text/css">
.form-style-7{
    max-width:400px;
    margin:50px auto;
    background:#fff;
    border-radius:2px;
    padding:20px;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 h1{
    display: block;
    text-align: center;
    padding: 0;
    margin: 0px 0px 20px 0px;
    color: #5C5C5C;
    font-size:x-large;
}
.form-style-7 ul{
    list-style:none;
    padding:0;
    margin:0;   
}
.form-style-7 li{
    display: block;
    padding: 9px;
    border:1px solid #DDDDDD;
    margin-bottom: 30px;
    border-radius: 3px;
}
.form-style-7 li:last-child{
    border:none;
    margin-bottom: 0px;
    text-align: center;
}
.form-style-7 li > label{
    display: block;
    float: left;
    margin-top: -19px;
    background: #FFFFFF;
    height: 14px;
    padding: 2px 5px 2px 5px;
    color: #B9B9B9;
    font-size: 14px;
    overflow: hidden;
    font-family: Arial, Helvetica, sans-serif;
}
.form-style-7 input[type="text"],
.form-style-7 input[type="date"],
.form-style-7 input[type="datetime"],
.form-style-7 input[type="email"],
.form-style-7 input[type="number"],
.form-style-7 input[type="search"],
.form-style-7 input[type="time"],
.form-style-7 input[type="url"],
.form-style-7 input[type="password"],
.form-style-7 textarea,
.form-style-7 select 
{
    box-sizing: border-box;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    width: 100%;
    display: block;
    outline: none;
    border: none;
    height: 25px;
    line-height: 25px;
    font-size: 16px;
    padding: 0;
    font-family: Georgia, "Times New Roman", Times, serif;
}
.form-style-7 input[type="text"]:focus,
.form-style-7 input[type="date"]:focus,
.form-style-7 input[type="datetime"]:focus,
.form-style-7 input[type="email"]:focus,
.form-style-7 input[type="number"]:focus,
.form-style-7 input[type="search"]:focus,
.form-style-7 input[type="time"]:focus,
.form-style-7 input[type="url"]:focus,
.form-style-7 input[type="password"]:focus,
.form-style-7 textarea:focus,
.form-style-7 select:focus 
{
}
.form-style-7 li > span{
    background: #F3F3F3;
    display: block;
    padding: 3px;
    margin: 0 -9px -9px -9px;
    text-align: center;
    color: #C0C0C0;
    font-family: Arial, Helvetica, sans-serif;
    font-size: 11px;
}
.form-style-7 textarea{
    resize:none;
}
.form-style-7 input[type="submit"],
.form-style-7 input[type="button"]{
    background: #2471FF;
    border: none;
    padding: 10px 20px 10px 20px;
    border-bottom: 3px solid #5994FF;
    border-radius: 3px;
    color: #D2E2FF;
}
.form-style-7 input[type="submit"]:hover,
.form-style-7 input[type="button"]:hover{
    background: #6B9FFF;
    color:#fff;
}
</style>   
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<body>

 <div id="container">
  
  <center><a href="index.php"><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></a></center><br/>
  <h2><strong><center><font face="comic sans MT"  size="+6"> 
  <?PHP  if(($_SESSION['deploy']=="pilot")||($_SESSION['deploy']=="pilot_ops")){$link= base_url()."index.php/welcome/home_ops";}else if(($_SESSION['deploy']=="technician")||($_SESSION['deploy']=="technician_ops")){$link= base_url()."index.php/welcome/home_technician";}else $link= base_url()."index.php/welcome/home";?><a style="text-decoration:none;color:#06748B" href="<?php echo $link;?>">User Profile </a></center></strong></h2></font>
  
  
<ul class="nav nav-tabs">
    <li class="active"><a href=<?PHP echo $link;?>>Home</a></li>
    <?PHP if(($_SESSION['deploy']=="pilot")||($_SESSION['deploy']=="pilot_ops")||($_SESSION['deploy']=="technician")||($_SESSION['deploy']=="technician_ops")){?><li><a href="<?PHP echo base_url() ?>index.php/welcome/edit_f2/<?php echo $tel;?>">Edit</a></li><?PHP } ?>
    <li><a href="<?PHP echo base_url() ?>index.php/welcome/logout">Logout</a></li>
  </ul>
  <div class="col-sm-12">
      <div class="col-sm-2 " >
</div>
    <div class="col-sm-8 " >
    <div class="col-sm-6" >
    <?PHP 
	
	
	if(empty($picture)){
		
		$pic="default.png";
	}
	else{
	$pic=$picture; 
	}
	
  $path='uploads/'.$pic;?>
  <img src="<?php echo base_url($path); ?>" height="19%" width="30%">
    </div>

      <div class="col-sm-6" >
      <table class="table table-condensed table-hover">
      <tr><td>First Name</td><td>: <?PHP echo $firstname; ?></td></tr>
      <tr><td>Last Name</td><td>: <?PHP echo $lastname; ?></td></tr>
      <tr><td>Department</td><td>: <?PHP echo $department; ?></td></tr>
      

<?PHP if($department=="pilot" or $department=="pilot_ops"){




$initial=0;
$flights=0;
// Create connection
require(APPPATH.'include/link_database.php');

$query=mysqli_query($conn,"select sum(engine_hobs) from flights where (pic_instr='$tel' or copilot_instr='$tel')");
$query2=mysqli_query($conn,"select * from initial where tel ='$tel'");

while ($row = mysqli_fetch_array($query)){$flights=$row[0];}

while ($row6 = mysqli_fetch_array($query2)){$initial=$row6["others"]+$row6["R44"]+$row6["A109"]+$row6["A139"];}
?>
      <tr><td>General Hours</td><td>: <?PHP echo $hours=$flights+$initial; ?></td></tr><?php } ?>
            </table>
            
</div> 

<div class="col-sm-12">
<div class="col-sm-6" >
<table class="table table-condensed table-hover"><tr><td>License Number</td><td>: <?PHP echo $license_number; ?></td></tr>
      <tr><td>Tel</td><td>: <?PHP echo $tel; ?></td></tr>
      
       </table>
       </div>

    <div class="col-sm-6" >
    
    <table class="table table-condensed table-hover">
    
    </table>
    </div>
    </div>
    <div class="col-sm-12" >
    <?PHP 
	$d1=date("y-m-d");
    $d="20".$d1;
	$date1=date_create($medical);
	$date2=date_create($d);
	$diff=date_diff($date2,$date1);
	$diff2=$diff->format("%R%a");
	
	$date1x=date_create($crm);
	$diffx=date_diff($date2,$date1x);
	$diff2x=$diffx->format("%R%a");
	
	$date1y=date_create($dgs);
	$diffy=date_diff($date2,$date1y);
	$diff2y=$diffy->format("%R%a");
	
	$date1a=date_create($sim109);
	$diffa=date_diff($date2,$date1a);
	$diff2a=$diffa->format("%R%a");
	
	$date1z=date_create($sim139);
	$diffz=date_diff($date2,$date1z);
	$diff2z=$diffz->format("%R%a");
	
	$dater=date_create($recurency);
	$diffr=date_diff($date2,$dater);
	$diff2r=$diffr->format("%R%a");
	
	$datei=date_create($instructor);
	$diffi=date_diff($date2,$datei);
	$diff2i=$diffi->format("%R%a");
	
	$datep=date_create($proficiency);
	$diffp=date_diff($date2,$datep);
	$diff2p=$diffp->format("%R%a");
	
	$datel=date_create($license);
	$diffl=date_diff($date2,$datel);
	$diff2l=$diffl->format("%R%a");
	
?>
    
    <center><table class="table table-condensed table-hover">
      <tr><td>Medical Expiration Date</td>
	  <?PHP if(($date1<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2<=60)&&($diff2>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $medical; echo '</td>';?>

<td>CRM Expiration Date</td>
 <?PHP if(($date1x<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2x<=60)&&($diff2x>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2x>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $crm; echo '</td>';

?></tr><tr><td>DGs Expiration Date</td> <?PHP 
if(($date1y<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2y<=60)&&($diff2y>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2y>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $dgs; echo '</td>';

?><td>SIM109 Expiration Date</td> <?PHP
if(($date1a<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2a<=60)&&($diff2a>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2a>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $sim109; echo '</td>';

?></tr><tr><td>SIM139 Expiration Date</td> <?PHP 
if(($date1z<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2z<=60)&&($diff2z>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2z>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $sim139; echo '</td>';

?><td>License Expiration Date</td> <?PHP
if(($datel<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2l<=60)&&($diff2l>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2l>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $license; echo '</td>';

?></tr><tr><td>Medical Expiration Date</td> <?PHP
if(($date1<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2<=60)&&($diff2>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $medical; echo '</td>';	

?><td>Recurency Expiration Date</td> <?PHP
if(($dater<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2r<=60)&&($diff2r>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2r>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $recurency; echo '</td>';

?></tr><tr><td>Instructor Expiration Date</td> <?PHP 
if(($datei<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2i<=60)&&($diff2i>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2i>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $instructor; echo '</td>';

?><td>Proficiency Expiration Date</td> <?PHP 
if(($datep<=$date2)){	echo '<td colspan="2" class="btn btn-danger btn-lg">';}else if(($diff2p<=60)&&($diff2p>0)){ 
echo '<td colspan="2" class="btn btn-warning btn-lg">';}else if($diff2p>60){echo '<td colspan="2" class="btn btn-success btn-lg">';}
else{echo '<td bgcolor="#000000">';}echo $proficiency; echo '</td>';echo '</tr>';	
?></table></center>
           
            </div>
            </div>
       

            <div class="col-sm-2" style="overflow-y:scroll; height:380px;">
            
         
</div>
</div>


</div>

</html>