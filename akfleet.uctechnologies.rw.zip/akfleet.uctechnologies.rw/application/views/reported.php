<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Reported Defects Page</title> 
    <style type="text/css">
.input_container ul{
	   width::256px;
	   border:1px solid #eaeaea;
	   position:absolute;
	   z-index:9;
	   background:#f3f3f3;
	   list-style:none;
   }
   .input_container ul li:hover{
	   background:#337ab7;
   }
   #view_search{
	   display:none;
	   
	   }
	   
	    #view_search2{
	   display:none;
	   
	   }
	   
	    #view_cond{
	   display:none;
	   
	   }

</style>   
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


</head>
<body>
<?PHP
require(APPPATH.'include/link_database.php');


 ?>

 <div id="container">
  <center><img height="100px" src="<?php echo base_url('images/base.JPG');?>"></center>
  <h2><strong><center><font face="comic sans MT"  size="+6"> <a style="text-decoration:none;color:#06748B" href="#">Aircraft Status Form</a></font></center></strong></h2>
<?PHP $tel=$_SESSION['tel']?>
<ul class="nav nav-tabs">
    <?PHP if($_SESSION['deploy']=="technician_ops"){?><li class="active"><a href="<?PHP echo base_url() ?>index.php/welcome/home">Ops</a></li><?PHP }
    else {?><li class="active"><a href="#">Reported</a></li><?php }?>
<li><a href="<?PHP echo base_url() ?>index.php/welcome/ci_profile/<?php echo $tel;?>">My profile</a></li>
<li><a href="#">Home</a></li>
<li><a href="<?PHP echo base_url() ?>index.php/welcome/logout">Logout</a></li>
  </ul>   
   

<div class="col-sm-6" align="center" style="overflow-y:scroll; height:350px;" id="print_content">

  <table class="table table-condensed table-hover" >
                                    <thead>
                                        </thead>
<h5><strong><center>Pilot Reported Problems</center></strong></h5>
                                        
<?PHP $index=1; foreach ($res4 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';
echo '<td>';echo $row->problem;echo '</td>';
?><td><a href="<?php echo base_url() ?>index.php/welcome/corrected/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-ok-circle"></span></a> <?PHP echo '</td>';echo '</tr>'; $index++;}?>
                                        </table>

</div>
<div class="col-sm-6" align="center" style="overflow-y:scroll; height:350px;" id="print_content">

<h3><strong><center>Rectified problems History</center></strong></h3>

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Engineer</strong></h5></th>
                                            <!--<th><h5><strong>Edit</strong></h5></th>-->
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;

foreach ($res3 as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->date_time;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';
echo '<td>';echo $row->rectifier;echo '</td>';

	
   ?><!--<td><a href="<?php echo base_url() ?>index.php/welcome/edit_inspection/<?php echo $_id=$row->_id ;?>"><span class="glyphicon glyphicon-pencil"></span></a>--> <?PHP echo '</td>';
//$amount=0;$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?>
</tbody>
  </table>
  
  
</div>



