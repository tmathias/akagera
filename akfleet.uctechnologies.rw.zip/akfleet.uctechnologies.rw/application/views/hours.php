<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Ops</title>    
    
<link  type="text/css" href="<?php echo base_url('bootstrap/css/bootstrap.css');?>" rel="stylesheet">
<link  type="text/css"href="<?php echo base_url('bootstrap/css/cssbootstrap.min.css'); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script type="text/javascript">

function printDiv(print_content){
 
 var printContents = document.getElementById("print_content").innerHTML;
 w=window.open();
 w.document.write(printContents);
 w.print();
 w.close();
}

 </script>
<style>
ul.nav li a, ul.nav li a:visited {
    color: #ffffff !important;
}

ul.nav li a:hover, ul.nav li a:active {
    color: #00ff00 !important;
}

ul.nav li.active a {
    color: #0000ff !important;
	background:inherit;
}
</style>

</head>
<body>
 <div id="container">
 <div class="page-header">
 <center><img height="100px" border="5px" src="<?php echo base_url('images/base.JPG');?>">
 <h2><strong><font face="comic sans MT" color="#06748B">15 Wing Pilots' hours management System</font></center></strong></h2>
<?PHP $para=$this->uri->segment(3);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "ak_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 
$index=1;
$sum=0;?>

<ul class="nav nav-pills nav-justified">
   
  <li <?PHP if($para=="term1"){?>class="active" <?PHP } ?>style="background:#535050"><a style="color:#ffffff" href="<?php echo base_url() ?>index.php/welcome/hours_f2/term1">TERM I</a></li>
  <li <?PHP if($para=="term2"){?>class="active" <?PHP } ?>><a style="color:#ffffff;background:#F93D60"  href="<?php echo base_url() ?>index.php/welcome/hours_f2/term2">TERM II</a></li>
  <li <?PHP if($para=="term3"){?>class="active" <?PHP } ?> style="background:#0390C3"><a style="color:#ffffff" href="<?php echo base_url() ?>index.php/welcome/hours_f2/term3">TERM III</a></li>
  <li <?PHP if($para=="term4"){?>class="active" <?PHP } ?> style="background:#F57D7F"><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/hours_f2/term4">TERM IV</a></li>
  <li <?PHP if($para=="annual"){?>class="active" <?PHP } ?> style="background:#FBDD86"><a style="color:#000000" href="<?php echo base_url() ?>index.php/welcome/hours_f2/annual">ANNUAL</a></li></ul>
<br><div class="row form-inline" align="center"> 
<a href="<?php echo base_url() ?>index.php/welcome/home" class="btn btn-info btn-lg"><span class="glyphicon glyphicon-home"></span></a><a class="btn btn-success btn-lg" href="<?php echo base_url() ?>index.php/welcome/print_hours/<?PHP if(empty($para)){$para=0;} echo $para; ?>">
<span class="glyphicon glyphicon-print"></span></a>
</div>
<br><div class="row form-inline" align="center"> 

<?PHP echo form_open('welcome/hours_f'); 
$query=mysqli_query($conn,"SELECT * from status_tb  where crew_type='15_Wing_Pilot' order by ranking,service_n asc");
?>
 <select name="service_n" class="form-control input-md">
 <option></option>
 <?PHP
 while ($row = mysqli_fetch_array($query)){?>
	                 <option value="<?PHP echo $row["service_n"]; ?>"><?PHP echo $row["rank"];echo "  ";echo $row["firstname"];echo "  ";echo $row["lastname"]; ?></option>

<?PHP } ?>
                
        </select>
<?PHP
$from = array(
'type' => 'date',
'name' => 'from',
'required' => 'required',
'class' => 'form-control input-md',

);
echo form_input($from);
$to = array(
'type' => 'date',
'name' => 'to',
'required' => 'required',
'class' => 'form-control input-md',

);
echo form_input($to);


$query=mysqli_query($conn,"SELECT * from flight ");
?>
 <select name="flight_nature" class="form-control input-md">
 <option>all</option>
 <?PHP
 while ($row = mysqli_fetch_array($query)){?>
<option value="<?PHP echo $row["flight_nature"]; ?>"><?PHP echo $row["flight_nature"]; ?></option>
<?PHP } ?>
                
        </select>
<?PHP $craft = array(
'all' => 'all',
'MI_17' => 'MI_17',
'MI_24' => 'MI_24',
'SIM_17' => 'SIM_17',
'SIM_24' => 'SIM_24',
);
echo form_dropdown('aircraft_type',$craft,'','class="form-control input-md"');
echo form_submit('submit','Display ','class="btn btn-info btn-md"');
echo '</div>';

if(!empty($res)){?>
<br><br></div>
<?PHP $pilo=$_SESSION['service_n2'];
$query=mysqli_query($conn,"SELECT * from status_tb  where service_n='$pilo' ");
echo '<td>';?><h4><strong><center>
<?PHP while ($rown = mysqli_fetch_array($query)){
$pil=$rown["rank"]."  ". $rown["firstname"]."  ". $rown["lastname"]; }
if(!empty($pilo)){?><a data-toggle="modal" data-target="#myModal"><?PHP echo $pil;echo '</a>';}echo "  ";echo "From: "; echo $_SESSION['from'];echo "  To:  ";echo $_SESSION['to'];echo "  ";echo $_SESSION['flight_nature'];echo "  ";echo " in:  ";echo $_SESSION['aircraft_type']; ?></center></strong></h4>
<div class="col-sm-12" style="overflow-y:scroll; height:350px;" id="print_content">

<table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>A/C Type</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Pilot</strong></h5></th>
                                            <th><h5><strong>Co-Pilot</strong></h5></th>
                                            <th><h5><strong>Flight nature</strong></h5></th>
                                            <th><h5><strong>Departure</strong></h5></th>
                                            <th><h5><strong>Arrival</strong></h5></th>
                                            <th><h5><strong>Duration</strong></h5></th>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;

foreach ($res as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->flight_date;echo '</td>';
echo '<td>';echo $row->aircraft_type;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';
$copilot=$row->co_pilot;
$pilote=$row->pilot;
$query=mysqli_query($conn,"SELECT * from status_tb  where service_n='$pilote' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["rank"];echo "  ";echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';
$query2=mysqli_query($conn,"SELECT * from status_tb  where service_n='$copilot' ");
echo '<td>';
while ($row2 = mysqli_fetch_array($query2)){
echo $row2["rank"];echo "  ";echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }echo '</td>';

echo '<td>';echo $row->flight_nature;echo '</td>';
echo '<td>';echo $row->departure;echo '</td>';
echo '<td>';echo $row->arrival;echo '</td>';
echo '<td>';echo $amount=$row->amount;echo '</td>';
echo '<td>';
	?>
     <?PHP echo '</td>';
$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?>

<tr><td><strong>Total</strong></td><td colspan="8"></td><td><?PHP echo $sum; ?></td></tr>
   </tbody>
  </table>

<?PHP }
     else if(!empty($res2)){  
	 $year=date("y");
	 $year1="20".$year;?>
	<div class="col-sm-12" style="overflow-y:scroll; height:350px;" id="print_content">

<table class="table table-condensed table-hover" >
 <thead><tr class="info"><th><h5><strong>Index</strong></h5></th><th><h5><strong>Names</strong></h5></th><?PHP if($para=="term1"){$date1=$year1."-01-01";$date11=$year1."-01-31";$date2=$year1."-02-01";$date22=$year1."-02-28";$date3=$year1."-03-01";$date33=$year1."-03-31"; ?><th><h5><strong>JAN</strong></h5></th><th><h5><strong>FEB</strong></h5></th><th><h5><strong>MAR</strong></h5></th><?PHP }if($para=="term2"){ $date1=$year1."-04-01";$date11=$year1."-04-30";$date2=$year1."-05-01";$date22=$year1."-05-31";$date3=$year1."-06-01";$date33=$year1."-06-30";?><th><h5><strong>APR</strong></h5></th><th><h5><strong>MAY</strong></h5></th><th><h5><strong>JUN</strong></h5></th><?PHP }if($para=="term3"){ $date1=$year1."-07-01";$date11=$year1."-07-31";$date2=$year1."-08-01";$date22=$year1."-08-31";$date3=$year1."-09-01";$date33=$year1."-09-30"; ?><th><h5><strong>JUL</strong></h5></th><th><h5><strong>AUG</strong></h5></th><th><h5><strong>SEP</strong></h5></th><?PHP }if($para=="term4"){ $date1=$year1."-10-01";$date11=$year1."-10-31";$date2=$year1."-11-01";$date22=$year1."-11-30";$date3=$year1."-12-01";$date33=$year1."-12-31";?><th><h5><strong>OCT</strong></h5></th><th><h5><strong>NOV</strong></h5></th><th><h5><strong>DEC</strong></h5></th><?PHP }if($para=="annual"){ $date1=$year1."-01-01";$date11=$year1."-03-31";$date2=$year1."-04-01";$date22=$year1."-06-30";$date3=$year1."-07-01";$date33=$year1."-09-30";$date4=$year1."-10-01";$date44=$year1."-12-31"?><th><h5><strong>TERM1</strong></h5></th><th><h5><strong>TERM2</strong></h5></th><th><h5><strong>TERM3</strong></h5></th><th><h5><strong>TERM4</strong></h5></th><?PHP } ?><th><h5><strong>Total</strong></h5></th><th><h5><strong>GENERAL HOURS</strong></h5></th></tr></thead><tbody>
  
 <?PHP
	 
	 /*$trim=date_create($res2->flight_date);
	 $year=date("y");
	 $year1="20".$year;
	 $trim4=date_create($year1."-12-31");
     $trim3=date_create($year1."-09-30");
	 $trim2=date_create($year1."-06-30");
	 $trim1=date_create($year1."-03-31");
	 $trim0=date_create($year1."-01-01");
	 if(($trim>=$trim0)&&($trim<=$trim1)){	 $n=1;$date1=$year1."-01-01";$date11=$year1."-01-31";$date2=$year1."-02-01";$date22=$year1."-02-28";$date3=$year1."-03-01";$date33=$year1."-03-31";}*/
	


foreach ($res2 as $row){
$co_pilot=$row->co_pilot;
$query1=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot' and flight_date between '$date1' and '$date11'");
$query2=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot'  and flight_date between '$date2' and '$date22'");
$query3=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot' and flight_date between '$date3' and '$date33'");

if($para=="annual"){$query4=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot' and flight_date between '$date4' and '$date44'");}
$query5=mysqli_query($conn,"select sum(amount) from hours where pilot='$co_pilot'");
$query11=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date1' and '$date11'");
$query22=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date2' and '$date22'");
$query33=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date3' and '$date33'");

if($para=="annual"){$query44=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot' and flight_date between '$date4' and '$date44'");}
$query55=mysqli_query($conn,"select sum(amount) from hours where co_pilot='$co_pilot'");
$query6=mysqli_query($conn,"SELECT initial_r44,initial_mi17,initial_mi24,initial_sim17,initial_sim24 from status_tb where status_tb.service_n='$co_pilot' limit 1");

$names2=mysqli_query($conn,"SELECT rank,firstname,lastname,ranking FROM  status_tb  where status_tb.service_n='$co_pilot'");
echo '<tr>';
echo '<td>';echo $index;echo '</td>';
while ($rown = mysqli_fetch_array($names2)){
echo '<td>'; echo $rown["rank"];echo ' ';echo $first=$rown["firstname"];echo ' ';echo $names=$rown["lastname"];echo '</a>';echo '</td>';}
while ($row1 = mysqli_fetch_array($query1)){
$t1=$row1[0];}
while ($row11 = mysqli_fetch_array($query11)){
$t11=$row11[0];}
while ($row2 = mysqli_fetch_array($query2)){
$t2=$row2[0];}
while ($row22 = mysqli_fetch_array($query22)){
$t22=$row22[0];}
while ($row3 = mysqli_fetch_array($query3)){
$t3=$row3[0];}
while ($row33 = mysqli_fetch_array($query33)){
$t33=$row33[0];}

echo '<td>';echo $s1=$t1+$t11;echo '</td>';
echo '<td>';echo $s2=$t2+$t22;echo '</td>';
echo '<td>';echo $s3=$t3+$t33;echo '</td>';

	

if($para=="annual"){while ($row4 = mysqli_fetch_array($query4)){
$t4=$row4[0];}
while ($row44 = mysqli_fetch_array($query44)){
$t44=$row44[0];}
echo '<td>';echo $s4=$t4+$t44;echo '</td>';}
if($para=="annual"){
echo '<td>';echo $sum=$s1+$s2+$s3+$s4;echo '</td>';}
else{echo '<td>';echo $sum=$s1+$s2+$s3;echo '</td>';}
while ($row5 = mysqli_fetch_array($query5)){$s5=$row5[0];}
while ($row55 = mysqli_fetch_array($query55)){$s55=$row55[0];}
$th=$s5+$s55;while ($row6 = mysqli_fetch_array($query6)){
echo '<td>';echo $th+$row6["initial_r44"]+$row6["initial_mi17"]+$row6["initial_mi24"]+$row6["initial_sim24"]+$row6["initial_sim17"];echo '</td>';}echo '</tr>';


	 $index++;
}?> </tbody>
  </table>
  
    
  <?PHP } /* else{ ?> <center><h3><strong><u>TODAY</u></strong></h3></center>
  <table class="table table-condensed table-hover" >
                                    <thead>
                                        <tr class="info">
                                            <th><h5><strong>Index</strong></h5></th>
                                            <th><h5><strong>Date</strong></h5></th>
                                            <th><h5><strong>A/C Type</strong></h5></th>
                                            <th><h5><strong>Call Sign</strong></h5></th>
                                            <th><h5><strong>Pilot</strong></h5></th>
                                            <th><h5><strong>Co-Pilot</strong></h5></th>
                                            <th><h5><strong>Flight nature</strong></h5></th>
                                            <th><h5><strong>Departure</strong></h5></th>
                                            <th><h5><strong>Arrival</strong></h5></th>
                                            <th><h5><strong>Duration</strong></h5></th>
                                            </tr>
                                            </thead>
                                            <tbody>
 <?PHP
$index=1;
$sum=0;

foreach ($re as $row)
{

echo '<tr>';
echo '<td>';echo $index;echo '</td>';
echo '<td>';echo $row->flight_date;echo '</td>';
echo '<td>';echo $row->aircraft_type;echo '</td>';
echo '<td>';echo $row->call_sign;echo '</td>';
$copilot=$row->co_pilot;
$pilote=$row->pilot;
$query=mysqli_query($conn,"SELECT * from status_tb  where service_n='$pilote' ");
echo '<td>';
while ($rown = mysqli_fetch_array($query)){
echo $rown["rank"];echo "  ";echo $rown["firstname"];echo "  ";echo $rown["lastname"]; }
echo '</td>';
$query2=mysqli_query($conn,"SELECT * from status_tb  where service_n='$copilot' ");
echo '<td>';
while ($row2 = mysqli_fetch_array($query2)){
echo $row2["rank"];echo "  ";echo $row2["firstname"];echo "  ";echo $row2["lastname"]; }echo '</td>';

echo '<td>';echo $row->flight_nature;echo '</td>';
echo '<td>';echo $row->departure;echo '</td>';
echo '<td>';echo $row->arrival;echo '</td>';
echo '<td>';echo $amount=$row->amount;echo '</td>';
echo '<td>';
	?>
     <?PHP echo '</td>';
$sum=$sum+$amount;
echo '</tr>';
	 $index++;
}?>

<tr><td><strong>Total</strong></td><td colspan="8"></td><td><?PHP echo $sum; ?></td></tr>
   </tbody>
  </table><?PHP } */?>