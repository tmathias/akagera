<? //mysql_connect('mysql14.000webhost.com','a4019960_mukunzi','Desire.100') or die('impossible to connect');mysql_select_db('a4019960_high') or die('database not found'); ?>
<? //mysql_connect('localhost','root','123456') or die('impossible to connect');mysql_select_db('highland_db') or die('database not found'); ?>
<? //mysql_connect('localhost','root','') or die('impossible to connect');mysql_select_db('highland_db') or die('database not found'); ?>
<?PHP 
$servername = "akfleet.uctechnologies.rw";
$username = "uctechno_uctechn";
$password = "akagera@2018";
$dbname = "uctechno_ak_db";
/*
$servername = "fdb17.awardspace.net";
$username = "2449408_akdb";
$password = "Fleet.100";
$dbname = "2449408_akdb";*/



// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);?>