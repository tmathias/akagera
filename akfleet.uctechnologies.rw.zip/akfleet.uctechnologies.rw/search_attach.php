<?php
include_once("include/link_highland.php");

if(isset($_POST["q"])) {
    $q=$_POST["q"];   

    $sql_user = mysql_query("SELECT *
FROM driver WHERE fname LIKE '%$q%' OR lname LIKE '%$q%'") or die(mysql_error());
      $count = mysql_num_rows($sql_user);

      if($count > 0){
        
        echo '<ul class="list-group">';
        while ($row=mysql_fetch_array($sql_user)){          
         // $ACCOUNT_ID= $row['fname'];    
          $student_id= $row['lname'].' '.$row['fname'];
            $student_id = str_replace($_POST['q'], '<b>'.$_POST['q'].'</b>',  $row['lname'].'  '.$row['fname']);

            echo '
            <li  class="list-group-item" onclick="set_item(\''.str_replace("'", "\'", $row['lname'].'  '.$row['fname']).'\')">
            <strong><span class=" badge  btn-success btn-sm active">'
                .$student_id.'</span></strong>
            </li>';

        } 
        echo '</ul>';
      } 
      else {

        echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="false">
                    ×</button>
                <span class="glyphicon glyphicon-hand-up"></span> <strong>Company name doesn\'t  exisist  in database. </strong>
                <hr class="message-inner-separator">
                <p>
                    <span class="glyphicon glyphicon-thumbs-down"></span> is not available  (<font style="color:red;"></font>)</p>
            </div>';
      }
      mysql_close();
  }
  else if(isset($_POST["pla2"])){
	  
	  $pla2=$_POST["pla2"];   
  
    $sql_user = mysql_query("SELECT *
FROM workers WHERE worker_id LIKE '%$pla2%'") 

 or die(mysql_error());
      $count = mysql_num_rows($sql_user);

      if($count > 0){
        
        echo '<ul class="list-group">';
        while ($row=mysql_fetch_array($sql_user)){                      
          $group_name= $row['worker_id'];
            $group_name = str_replace($_POST['pla2'], '<b>'.$_POST['pla2'].'</b>', $row['worker_id']);
//            echo '<li class="list-group-item">
//            <strong><span class=" badge  btn-success btn-sm active"> ' . $student_id . '</span></strong>
//            </li>';
            echo '
            <li  class="list-group-item" onclick="set_item(\''.str_replace("'", "\'",$row['worker_id']).'\')">
            <strong><span class=" badge  btn-success btn-sm active">'
                .$group_name.'</span></strong>
            </li>';

            // echo"<hr>"; <a href="mrc.php?show=' . $row["ACCOUNT_ID"] . '"></a>' . $ACCOUNT_ID . ' :
        } 
        echo '</ul>';
	  
	    } 
      else {

        echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="false">
                    ×</button>
                <span class="glyphicon glyphicon-hand-up"></span> <strong>this worker is not yet registered </strong>
                <hr class="message-inner-separator">
                <p>
                    <span class="glyphicon glyphicon-thumbs-down"></span> is not available  (<font style="color:red;">'.$pla2.'</font>)</p>
            </div>';
      }
      mysql_close();
	  }
	  
	   else if(isset($_POST["supp"])){
	  
	  $supp=$_POST["supp"];   
  
    $sql_user = mysql_query("SELECT *
FROM supplier_pay2 WHERE asigaye !=0 and izina LIKE '%$supp%'") 

 or die(mysql_error());
      $count = mysql_num_rows($sql_user);

      if($count > 0){
        
        echo '<ul class="list-group">';
        while ($row=mysql_fetch_array($sql_user)){                      
          $group_name= $row['izina'];
            $group_name = str_replace($_POST['supp'], '<b>'.$_POST['supp'].'</b>', $row['izina']);
//            echo '<li class="list-group-item">
//            <strong><span class=" badge  btn-success btn-sm active"> ' . $student_id . '</span></strong>
//            </li>';
            echo '
            <li  class="list-group-item" onclick="set_item(\''.str_replace("'", "\'",$row['izina']).'\')">
            <strong><span class=" badge  btn-success btn-sm active">'
                .$group_name.'</span></strong>
            </li>';

            // echo"<hr>"; <a href="mrc.php?show=' . $row["ACCOUNT_ID"] . '"></a>' . $ACCOUNT_ID . ' :
        } 
        echo '</ul>';
	  
	    } 
      else {

        echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="false">
                    ×</button>
                <span class="glyphicon glyphicon-hand-up"></span> <strong>uyu mukiliya nta mwenda adufitiye cg wanditse nabi izina ye </strong>
                <hr class="message-inner-separator">
                <p>
                    <span class="glyphicon glyphicon-thumbs-down"></span> is not available  (<font style="color:red;">'.$supp.'</font>)</p>
            </div>';
      }
      mysql_close();
	  }
  
  
  else if(isset($_POST["pla"])){
	  
	  $pla=$_POST["pla"];   
  
    $sql_user = mysql_query("SELECT * FROM status_tb WHERE lastname LIKE '%$pla%'") 

 or die(mysql_error());
      $count = mysql_num_rows($sql_user);

      if($count > 0){
        
        echo '<ul class="list-group">';
        while ($row=mysql_fetch_array($sql_user)){                      
          $group_name= $row['service_n'];
            $group_name = str_replace($_POST['pla'], '<b>'.$_POST['pla'].'</b>', $row['service_n']);
//            echo '<li class="list-group-item">
//            <strong><span class=" badge  btn-success btn-sm active"> ' . $student_id . '</span></strong>
//            </li>';
            echo '
            <li  class="list-group-item" onclick="set_item(\''.str_replace("'", "\'",$row['service_n']).'\')">
            <strong><span class=" badge  btn-success btn-sm active">'
                .$row['lastname']."  ".$row['firstname'].'</span></strong>
            </li>';

            // echo"<hr>"; <a href="mrc.php?show=' . $row["ACCOUNT_ID"] . '"></a>' . $ACCOUNT_ID . ' :
        } 
        echo '</ul>';
      } 
      else {

        echo '<div class="alert alert-danger">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="false">
                    ×</button>
                <span class="glyphicon glyphicon-hand-up"></span> <strong>student  not found into database. </strong>
                <hr class="message-inner-separator">
                <p>
                    <span class="glyphicon glyphicon-thumbs-down"></span> is not available  (<font style="color:red;">'.$pla.'</font>)</p>
            </div>';
      }
      mysql_close();
	  }else{}


?>